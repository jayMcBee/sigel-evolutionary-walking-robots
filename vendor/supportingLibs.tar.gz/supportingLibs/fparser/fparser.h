/***************************************************************************\
|* Function parser v2.1 by Warp                                            *|
|* ----------------------------                                            *|
|* Parses and evaluates the given funtion with the given variable values.  *|
|*                                                                         *|
\***************************************************************************/

#ifndef ONCE_FPARSER_H_
#define ONCE_FPARSER_H_

#include <string>

class FunctionParser
{
public:
    int Parse(const std::string& Function, const std::string& Vars);
    const char* ErrorMsg(void);
    double Eval(double* Vars);
    inline int EvalError(void) { return EvalErrorType; }



    FunctionParser();
    ~FunctionParser();



private:
    int VarAmnt,ParseErrorType,EvalErrorType;
    std::string Variable;
    struct Comp
    {  Comp();
        ~Comp();
        unsigned char* ByteCode;
        unsigned ByteCodeSize;
        double* Immed;
        unsigned ImmedSize;
        double* Stack;
        unsigned StackSize, StackPtr;
    } Comp;
    int CheckSyntax(const char*);
    bool Compile(const char*);
    bool IsVariable(int);
    void AddCompiledByte(unsigned char);
    int CompileElement(const char*, int);
    int CompilePow(const char*, int);
    int CompileMult(const char*, int);
    int CompileExpression(const char*, int);
};

#endif
