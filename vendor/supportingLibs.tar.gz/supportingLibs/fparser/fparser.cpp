//==============================
// Function parser v2.1 by Warp
//==============================

// Comment out the following line if your compiler supports the (non-standard)
// asinh, acosh and atanh functions and you want them to be supported. If
// you are not sure, just leave it (those function will then not be supported).
#define NO_ASINH



#include "fparser.h"

#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cmath>
#include <new>

using namespace std;

static const char* const Funcs[]=
{
    "abs","exp","ceil","floor","log","sqrt","int",
    "sinh","cosh","tanh",
    "sin","cos","tan",
#ifndef NO_ASINH
    "asinh","acosh","atanh",
#endif
    "asin","acos","atan",
    0
};

static const unsigned char
    cImmed= 1,
    cNeg  = 2,
    cAdd  = 3,
    cSub  = 4,
    cMul  = 5,
    cDiv  = 6,
    cMod  = 7,
    cPow  = 8,
    cAbs  = 9,
    cExp  = 10,
    cCeil = 11,
    cFloor= 12,
    cLog  = 13,
    cSqrt = 14,
    cInt  = 15,
    cSinh = 16,
    cCosh = 17,
    cTanh = 18,
    cSin  = 19,
    cCos  = 20,
    cTan  = 21,
#ifndef NO_ASINH
    cAsinh= 22,
    cAcosh= 23,
    cAtanh= 24,
    cAsin = 25,
    cAcos = 26,
    cAtan = 27,
#else
    cAsin = 22,
    cAcos = 23,
    cAtan = 24,
#endif
    VarBegin=28;

// check if s1 is equal to s2 up to strlen(s1)
static inline bool IsEqual(const char* s1,const char* s2)
{ 
    for(int i=0;s1[i];i++) if(s1[i]!=s2[i]) return false;
    return true;
}

// Return math function number
static inline unsigned char MathFunctionNumber(const char* f)
{
    for(int i=0;Funcs[i];i++)
        if(IsEqual(Funcs[i],f))
            return i+cAbs;
    return 0;
}


//---------------------------------------------------------------------------
// Constructors and destructors
//---------------------------------------------------------------------------
//===========================================================================
FunctionParser::FunctionParser():
    VarAmnt(0), ParseErrorType(-1), EvalErrorType(0)
{}

FunctionParser::~FunctionParser() {}

FunctionParser::Comp::Comp():
    ByteCode(0), ByteCodeSize(0),
    Immed(0), ImmedSize(0),
    Stack(0), StackSize(0)
{}

FunctionParser::Comp::~Comp()
{
    if(ByteCode) { delete[] ByteCode; ByteCode=0; }
    if(Immed) { delete[] Immed; Immed=0; }
    if(Stack) { delete[] Stack; Stack=0; }
}


//---------------------------------------------------------------------------
// Function parsing
//---------------------------------------------------------------------------
//===========================================================================
static const char* ParseErrorMessage[]=
{
    "Syntax error",                        // 0
    "Mismatched parenthesis",              // 1
    "Missing ')'",                         // 2
    "Empty parentheses",                   // 3
    "Syntax error. Operator expected",     // 4
    "Not enough memory",                   // 5
    "An unexpected error ocurred. Please make a full bug report to warp@iki.fi"
};

// Return index to original string when the index is to the stripped version
static inline int RealIndexPos(const char* s,int Pos)
{
    int i,Ind=0;
    for(i=0;i<Pos;i++,Ind++)
        while(s[Ind]==' ') Ind++;
    while(s[Ind]==' ') Ind++;
    return Ind;
}

// Main parsing function
int FunctionParser::Parse(const std::string& Function,
                          const std::string& Vars)
{
    Variable = Vars;
    VarAmnt = Vars.size();

    string tmp;
    tmp.reserve(Function.size());
    for(unsigned i=0; i<Function.size(); ++i)
        if(!isspace(Function[i])) tmp += Function[i];
    const char* Func = tmp.c_str();

    ParseErrorType=-1;

    int Result = CheckSyntax(Func);
    if(Result>=0)
    {
        return RealIndexPos(Function.c_str(), Result);
    }

    if(!Compile(Func)) return Function.length()+1;

    ParseErrorType=-1;
    return -1;
}

// Is given char an operator?
inline static bool IsOperator(int c)
{
    return strchr("+-*/%^",c)!=NULL;
}

// Is given char a valid variable?
inline bool FunctionParser::IsVariable(int c)
{
    int i;
    for(i=0;i<VarAmnt;i++)
        if(c==Variable[i]) break;
    return i!=VarAmnt;
}

//---------------------------------------------------------------------------
// Check function string syntax
// ----------------------------
int FunctionParser::CheckSyntax(const char* Function)
{
    int Ind=0,ParenthCnt=0,c,i;
    char* Ptr;

    while(true)
    {
        c=Function[Ind];

// Check for valid operand (must appear)

        // Check for leading -
        if(c=='-') c=Function[++Ind];
        if(c==0) { ParseErrorType=0; return Ind; }
        // Check for math function
        for(i=0;Funcs[i];i++)
        {
            if(IsEqual(Funcs[i],&Function[Ind]))
            {
                Ind+=strlen(Funcs[i]);
                c=Function[Ind];
                if(c!='(') { ParseErrorType=0; return Ind; }
                break;
            }
        }
        // Check for opening parenthesis
        if(c=='(') { ParenthCnt++; Ind++; continue; }
        // Check for number
        if(isdigit(c) || (c=='.' && isdigit(Function[Ind+1])))
        {
            strtod(&Function[Ind],&Ptr);
            Ind+=int(Ptr-&Function[Ind]);
            c=Function[Ind];
        }
        else
        { // Check for variable
            if(!IsVariable(c)) { ParseErrorType=0; return Ind; }
            c=Function[++Ind];
        }
        // Check for closing parenthesis
        while(c==')')
        {
            ParenthCnt--;
            if(ParenthCnt<0) { ParseErrorType=1; return Ind; }
            if(Function[Ind-1]=='(') { ParseErrorType=3; return Ind; }
            c=Function[++Ind];
        }

// If we get here, we have a legal operand and now a legal operator or
// end of string must follow

        // Check for EOS
        if(c==0) break; // The only way to end the checking loop without error
        // Check for operator
        if(!IsOperator(c)) { ParseErrorType=4; return Ind; }

// If we get here, we have an operand and an operator; the next loop will
// check for another operand (must appear)
        Ind++;
    } // while

    // Check that all opened parentheses are also closed
    if(ParenthCnt>0) { ParseErrorType=2; return Ind; }

// The string is ok
    ParseErrorType=-1;
    return -1;
}

// Compile function string to bytecode
// -----------------------------------
bool FunctionParser::Compile(const char* Function)
{
    if(Comp.ByteCode) { delete[] Comp.ByteCode; Comp.ByteCode=0; }
    if(Comp.Immed) { delete[] Comp.Immed; Comp.Immed=0; }
    if(Comp.Stack) { delete[] Comp.Stack; Comp.Stack=0; }

// Compile to nowhere to get the size of the bytecode
    Comp.ByteCodeSize=Comp.ImmedSize=Comp.StackSize=Comp.StackPtr=0;
    CompileExpression(Function, 0);
    if(ParseErrorType >= 0) return false;

    try
    {
        if(Comp.ByteCodeSize)
            Comp.ByteCode = new unsigned char[Comp.ByteCodeSize];
        if(Comp.ImmedSize)
            Comp.Immed = new double[Comp.ImmedSize];
        if(Comp.StackSize)
            Comp.Stack = new double[Comp.StackSize];
    }
    catch(std::bad_alloc)
    {
        ParseErrorType=5; return false;
        // Already allocated memory blocks are freed in the destructor or when
        // Parse() is called again, so no need to free them here
    }

// Compile
    Comp.ByteCodeSize=Comp.ImmedSize=Comp.StackSize=Comp.StackPtr=0;
    CompileExpression(Function, 0);

    return ParseErrorType < 0;
}

inline void FunctionParser::AddCompiledByte(unsigned char c)
{
    if(Comp.ByteCode)
        Comp.ByteCode[Comp.ByteCodeSize] = c;
    Comp.ByteCodeSize++;
}

// Compiles element
int FunctionParser::CompileElement(const char* F, int ind)
{
    char c = F[ind];

    if(c == '(')
    {
        return CompileExpression(F, ind+1) + 1;
    }
    else if(c == '-')
    {
        int ind2 = CompileElement(F, ind+1);
        AddCompiledByte(cNeg);
        return ind2;
    }

    if(isalpha(c))
    {
        char fn = MathFunctionNumber(&F[ind]);
        if(fn)
        {
            int ind2 = ind+3;
            while(F[ind2++] != '(');
            ind2 = CompileExpression(F, ind2);
            AddCompiledByte(fn);
            return ind2+1;
        }
    }

    if(isdigit(c) || c=='.') // Number
    {
        const char* startPtr = &F[ind];
        char* endPtr;
        double val = strtod(startPtr, &endPtr);
        if(Comp.Immed)
            Comp.Immed[Comp.ImmedSize] = val;
        ++Comp.ImmedSize;
        AddCompiledByte(cImmed);
        ++Comp.StackPtr; if(Comp.StackPtr>Comp.StackSize) Comp.StackSize++;
        return ind+(endPtr-startPtr);
    }

    for(int i=0; i<VarAmnt; i++) // Variable
        if(c == Variable[i])
        {
            AddCompiledByte(VarBegin+i);
            ++Comp.StackPtr; if(Comp.StackPtr>Comp.StackSize) Comp.StackSize++;
            return ind+1;
        }

    ParseErrorType = 6;
    return ind;
}

// Compiles '^'
int FunctionParser::CompilePow(const char* F, int ind)
{
    int ind2 = CompileElement(F, ind);

    while(F[ind2] == '^')
    {
        ind2 = CompileElement(F, ind2+1);
        AddCompiledByte(cPow);
        --Comp.StackPtr;
    }

    return ind2;
}

// Compiles '*', '/' and '%'
int FunctionParser::CompileMult(const char* F, int ind)
{
    int ind2 = CompilePow(F, ind);
    char op;

    while((op = F[ind2]) == '*' || op == '/' || op == '%')
    {
        ind2 = CompilePow(F, ind2+1);
        switch(op)
        {
          case '*': AddCompiledByte(cMul); break;
          case '/': AddCompiledByte(cDiv); break;
          case '%': AddCompiledByte(cMod); break;
        }
        --Comp.StackPtr;
    }

    return ind2;
}

// Compiles '+' and '-'
int FunctionParser::CompileExpression(const char* F, int ind)
{
    int ind2 = CompileMult(F, ind);
    char op;

    while((op = F[ind2]) == '+' || op == '-')
    {
        ind2 = CompileMult(F, ind2+1);
        AddCompiledByte(op=='+' ? cAdd : cSub);
        --Comp.StackPtr;
    }

    return ind2;
}

// Return parse error message
// --------------------------
const char* FunctionParser::ErrorMsg(void)
{
    if(ParseErrorType>=0) return ParseErrorMessage[ParseErrorType];
    return 0;
}

//---------------------------------------------------------------------------
// Function evaluation
//---------------------------------------------------------------------------
//===========================================================================
static inline int doubleToInt(double d)
{
    return d<0 ? -int((-d)+.5) : int(d+.5);
}

double FunctionParser::Eval(double* Vars)
{
    unsigned IP, DP=0;
    int SP=-1;

    for(IP=0; IP<Comp.ByteCodeSize; IP++)
    {
        switch(Comp.ByteCode[IP])
        {
          case cImmed: Comp.Stack[++SP]=Comp.Immed[DP++]; break;
          case   cNeg: Comp.Stack[SP]=-Comp.Stack[SP]; break;
          case   cAdd: Comp.Stack[SP-1]+=Comp.Stack[SP]; SP--; break;
          case   cSub: Comp.Stack[SP-1]-=Comp.Stack[SP]; SP--; break;
          case   cMul: Comp.Stack[SP-1]*=Comp.Stack[SP]; SP--; break;
          case   cDiv: if(Comp.Stack[SP]==0) { EvalErrorType=1; return 0; }
                       Comp.Stack[SP-1]/=Comp.Stack[SP]; SP--; break;
          case   cMod: if(Comp.Stack[SP]==0) { EvalErrorType=1; return 0; }
                       Comp.Stack[SP-1]=fmod(Comp.Stack[SP-1],Comp.Stack[SP]);
                       SP--; break;
          case   cPow: Comp.Stack[SP-1]=pow(Comp.Stack[SP-1],Comp.Stack[SP]);
                       SP--; break;
          case   cAbs: Comp.Stack[SP]=fabs(Comp.Stack[SP]); break;
          case   cExp: Comp.Stack[SP]=exp(Comp.Stack[SP]); break;
          case  cCeil: Comp.Stack[SP]=ceil(Comp.Stack[SP]); break;
          case cFloor: Comp.Stack[SP]=floor(Comp.Stack[SP]); break;
          case   cLog: if(Comp.Stack[SP]<=0) { EvalErrorType=3; return 0; }
                       Comp.Stack[SP]=log(Comp.Stack[SP]); break;
          case  cSqrt: if(Comp.Stack[SP]<0) { EvalErrorType=2; return 0; }
                       Comp.Stack[SP]=sqrt(Comp.Stack[SP]); break;
          case   cInt: Comp.Stack[SP]=doubleToInt(Comp.Stack[SP]); break;
          case  cSinh: Comp.Stack[SP]=sinh(Comp.Stack[SP]); break;
          case  cCosh: Comp.Stack[SP]=cosh(Comp.Stack[SP]); break;
          case  cTanh: Comp.Stack[SP]=tanh(Comp.Stack[SP]); break;
          case   cSin: Comp.Stack[SP]=sin(Comp.Stack[SP]); break;
          case   cCos: Comp.Stack[SP]=cos(Comp.Stack[SP]); break;
          case   cTan: Comp.Stack[SP]=tan(Comp.Stack[SP]); break;
#ifndef NO_ASINH
          case cAsinh: Comp.Stack[SP]=asinh(Comp.Stack[SP]); break;
          case cAcosh: Comp.Stack[SP]=acosh(Comp.Stack[SP]); break;
          case cAtanh: Comp.Stack[SP]=atanh(Comp.Stack[SP]); break;
#endif
          case  cAsin: if(Comp.Stack[SP]<-1 || Comp.Stack[SP]>1)
                       { EvalErrorType=4; return 0; }
                       Comp.Stack[SP]=asin(Comp.Stack[SP]); break;
          case  cAcos: if(Comp.Stack[SP]<-1 || Comp.Stack[SP]>1)
                       { EvalErrorType=4; return 0; }
                       Comp.Stack[SP]=acos(Comp.Stack[SP]); break;
          case  cAtan: Comp.Stack[SP]=atan(Comp.Stack[SP]); break;

          default:
              Comp.Stack[++SP]=Vars[Comp.ByteCode[IP]-VarBegin];
        }
    }

    EvalErrorType=0;
    return Comp.Stack[0];
}
