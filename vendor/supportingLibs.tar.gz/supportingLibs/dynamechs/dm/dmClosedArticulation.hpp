/*****************************************************************************
 * DynaMechs: A Multibody Dynamic Simulation Library
 *
 * Copyright (C) 1994-2001  Scott McMillan   All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************
 *     File: dmClosedArticulation.hpp
 *   Author: Duane Marhefka
 *  Created: 1999
 *  Summary: Class declaration for articulations with closed loops.
 *****************************************************************************/

#ifndef _DM_CLOSED_ARTICULATION_HPP
#define _DM_CLOSED_ARTICULATION_HPP

#include <dm.h>
#include <dmSecondaryJoint.hpp>
#include <dmArticulation.hpp>

/** Documentation pending
 */

class DM_DLL_API dmClosedArticulation : public dmArticulation
{
public:
   ///
   dmClosedArticulation();
   ///
   ~dmClosedArticulation();

   ///
   void ABForwardKinematics(Float q[], Float qd[], dmABForKinStruct *ref_val);
   ///
   void ABBackwardDynamics();
   ///
   void ABForwardAccelerations(SpatialVector a_ref, Float qd[], Float qdd[]);

   ///
   bool addHardSecondaryJoint(dmSecondaryJoint *joint);
   ///
   bool addSoftSecondaryJoint(dmSecondaryJoint *joint);
   ///
   void initKinematicLoopVars();
   ///
   void eliminateLoops(unsigned int i);
   ///
   void propagateConstraints(unsigned int i);
   ///
   void computeConstraintForces(unsigned int i);

   ///
   unsigned int getNumHardSecondaryJoints() const { return m_num_sec_joints; }
   ///
   unsigned int getNumSoftSecondaryJoints() const { return m_num_soft_joints; }
   ///
   dmSecondaryJoint *getHardSecondaryJoint(unsigned int index) const;
   ///
   dmSecondaryJoint *getSoftSecondaryJoint(unsigned int index) const;

private:   // not implemented
   dmClosedArticulation(const dmClosedArticulation &);
   dmClosedArticulation &operator=(const dmClosedArticulation &);

protected:
   unsigned int *m_num_elements_LB;
   unsigned int **m_LB;

   unsigned int *m_num_elements_LR;
   unsigned int **m_LR;

   unsigned int *m_num_elements_LC;
   unsigned int **m_LC;

   unsigned int *m_num_elements_LJ_star;
   unsigned int **m_LJ_star;

   Float ****m_Xik;
   Float ****m_Bmn;
   Float **m_zetak;

   Float **m_Binv_zetai;
   Float ***m_Binv_Xi;
   Float ****m_Binv_Bim;
   unsigned int *m_constraints_at_root;

   Float **m_lambda_c;

   unsigned int  m_num_sec_joints;  // Number of 'Hard' secondary joints.
   dmSecondaryJoint **m_sec_joint;  // dmSecJoint ptr. array for 'Hard' joints.

   unsigned int m_num_soft_joints;  // Number of 'Soft' secondary joints.
   dmSecondaryJoint **m_soft_joint; // dmSecJoint ptr. array for 'Soft' joints.

   unsigned int *m_loop_root_index; // HACK - must put in root link req.
   unsigned int *m_num_constraints;
};

#endif
