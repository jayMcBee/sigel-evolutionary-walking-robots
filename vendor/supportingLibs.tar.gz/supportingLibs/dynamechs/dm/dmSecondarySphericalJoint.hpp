/*****************************************************************************
 * DynaMechs: A Multibody Dynamic Simulation Library
 *
 * Copyright (C) 1994-2001  Scott McMillan   All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************
 *     File: dmSecondarySphericalJoint.hpp
 *   Author: Duane Marhefka
 *  Created: 1999
 *  Summary: Class definitions for spherical secondary joints.
 * ***************************************************************************/

#ifndef _DM_SECONDARY_SPHERICAL_JOINT_HPP
#define _DM_SECONDARY_SPHERICAL_JOINT_HPP

#include <dm.h>
#include <dmObject.hpp>
#include <dmSecondaryJoint.hpp>

//======================================================================

/** Documentation for this class pending.
 */

class DM_DLL_API dmSecondarySphericalJoint :  public dmSecondaryJoint
{
public:
   enum {NUM_DOFS = 3};

public:
   ///
   dmSecondarySphericalJoint();
   ///
   ~dmSecondarySphericalJoint() {};

   ///
   int getNumDOFs() const {return NUM_DOFS;}
   ///
   void initXik(Float **Xik, int link_index, int root_index) const;
   ///
   void getZeta(Float *zeta) const;

   ///
   void getFreeState(Float q[], Float qd[]) const;
   ///
   void getConstrainedState(Float q[], Float qd[]) const;
   ///
   inline void setJointInput(Float joint_input[])
      {
         for (int i=0; i<NUM_DOFS; i++)
         {
            m_joint_input[i] = joint_input[i];
         }
      }

   ///
   void computeState();
   ///
   void computeEtas();
   ///
   void computeAppliedForce();
   ///
   void applyPenaltyForce();
   ///
   void computeStabilizationForce(Float force[]);

   ///
   void setConstraintParams(Float linear_spring, Float linear_damper);

private:   // not implemented
   dmSecondarySphericalJoint(const dmSecondarySphericalJoint &);
   dmSecondarySphericalJoint &operator=(const dmSecondarySphericalJoint &);

protected:
   Float m_pos_spring;
   Float m_pos_damper;

   Float m_joint_input[NUM_DOFS];
};

#endif
