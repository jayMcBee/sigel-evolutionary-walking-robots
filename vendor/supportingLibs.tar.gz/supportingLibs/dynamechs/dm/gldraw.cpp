/*****************************************************************************
 * DynaMechs: A Multibody Dynamic Simulation Library
 *
 * Copyright (C) 1994-2001  Scott McMillan   All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************
 *     File: gldraw.cpp
 *   Author: Scott McMillan
 *  Created: 24 March 1997
 *  Summary:
 *****************************************************************************/

#include <dm.h>
#include <dmArticulation.hpp>
#include <dmLink.hpp>
#include <dmZScrewTxLink.hpp>
#include <dmStaticRootLink.hpp>
#include <dmMobileBaseLink.hpp>
#include <dmSphericalLink.hpp>
#include <dmQuaternionLink.hpp>
#include <dmMDHLink.hpp>
#include <dmRevoluteLink.hpp>
#include <dmPrismaticLink.hpp>
#include <dmContactModel.hpp>
#include <dmEnvironment.hpp>

#include <GL/gl.h>

// yeah I know this is in other places but I really want to limit its scope
const float RADTODEG = (float)(180.0/M_PI);    // M_PI is defined in math.h

// ---------------------------------------------------------------------
inline void cross(float a[3], float b[3], float c[3])
{
   c[0] = a[1]*b[2] - a[2]*b[1];
   c[1] = a[2]*b[0] - a[0]*b[2];
   c[2] = a[0]*b[1] - a[1]*b[0];
}

//----------------------------------------------------------------------------
inline float normalize(float v[3])
{
    float norm = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);

    if (norm > 0.0)
    {
       v[0] /= norm;
       v[1] /= norm;
       v[2] /= norm;
    }

    return norm;
}

//----------------------------------------------------------------------------
inline void compute_face_normal(float v0[3], float v1[3], float v2[3],
                                float normal[3])
{
    float a[3], b[3];
    register int i;

    for (i=0; i<3; i++)
    {
        a[i] = v1[i] - v0[i];
        b[i] = v2[i] - v0[i];
    }

    cross(a, b, normal);
    normalize(normal);

}

//============================================================================
// Initialize DynaMechs/OpenGL drawing routines
//============================================================================

//----------------------------------------------------------------------------
void dmEnvironment::drawInit()
{
   register int i, j;

   GLfloat vertex[3][3], normal[3];

   glRotated(180,1,0,0);

   for (j=0; j<y_dim-1; j++)
   {
       glBegin(GL_TRIANGLE_STRIP);
       {
	   for (i=0; i<x_dim; i++)
	   {
               vertex[0][0] = ((GLfloat) i)*grid_resolution;
               vertex[0][2] = ((GLfloat) j + 1.0)*grid_resolution;
               vertex[0][1] = -depth[i][j+1];
	       
               if (i > 0)
               {
		   vertex[1][0] = ((GLfloat) i - 1.0)*grid_resolution;
		   vertex[1][2] = ((GLfloat) j + 1.0)*grid_resolution;
		   vertex[1][1] = -depth[i-1][j+1];
		   
		   vertex[2][0] = ((GLfloat) i - 1.0)*grid_resolution;
		   vertex[2][2] = ((GLfloat) j)*grid_resolution;
		   vertex[2][1] = -depth[i-1][j];
		   
		   compute_face_normal(vertex[1], vertex[2], vertex[0], normal);
		   glNormal3fv(normal);
               }
               glVertex3fv(vertex[0]);
	       
               vertex[1][0] = ((GLfloat) i)*grid_resolution;
               vertex[1][2] = ((GLfloat) j)*grid_resolution;
               vertex[1][1] = -depth[i][j];
	       
               if (i > 0)
               {
		   compute_face_normal(vertex[1], vertex[0], vertex[2], normal);
		   glNormal3fv(normal);
               }
               glVertex3fv(vertex[1]);
	   } // for-loop (y)
       } // glBegin(GL_TRIANGLE_STRIP)
       glEnd();
   } // for-loop (x)
}


//============================================================================
// draw environment and robot
//============================================================================

//----------------------------------------------------------------------------
void dmArticulation::draw()
{
   glPushMatrix();

   glTranslatef(m_p_ICS[XC], m_p_ICS[YC], m_p_ICS[ZC]);

   float len = sqrt(m_quat_ICS[0]*m_quat_ICS[0] +
                    m_quat_ICS[1]*m_quat_ICS[1] +
                    m_quat_ICS[2]*m_quat_ICS[2]);
   if (len > 1.0e-6)
   {
      float angle = 2.0*atan2(len, m_quat_ICS[3]);
      glRotatef(angle*RADTODEG,
                m_quat_ICS[0]/len, m_quat_ICS[1]/len, m_quat_ICS[2]/len);
   }

   // render some sort of base element
   if (getUserData())
      glCallList(*((GLuint *) getUserData()));

   for (unsigned int j=0; j<m_link_list.size(); j++)
   {
      if (m_link_list[j]->parent == NULL)
      {
         glPushMatrix();

         // draw base link
         m_link_list[j]->link->draw();

         // recurse through the children
         for (unsigned int i=0; i<m_link_list[j]->child_list.size(); i++)
         {
            glPushMatrix();
            drawTraversal(m_link_list[j]->child_list[i]);
            glPopMatrix();
         }

         glPopMatrix();
      }
   }

   glPopMatrix();
}

//----------------------------------------------------------------------------
void dmArticulation::drawTraversal(LinkInfoStruct *node)
{
   if (node && node->parent)
   {
      node->link->draw();

      for (unsigned int i=0; i<node->child_list.size(); i++)
      {
         if (node->child_list.size() > 1)
         {
            glPushMatrix();
            drawTraversal(node->child_list[i]);
            glPopMatrix();
         }
         else
         {
            drawTraversal(node->child_list[i]);
         }
      }
   }
}


//----------------------------------------------------------------------------
void dmZScrewTxLink::draw()
{
   glTranslatef(0.0, 0.0, m_dMDH);
   glRotatef(m_thetaMDH*RADTODEG, 0.0, 0.0, 1.0);
}

//----------------------------------------------------------------------------
void dmStaticRootLink::draw()
{
   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmRevoluteLink::draw()
{
   // set static portion of the MDH transformation.
   if (m_alphaMDH != 0.0)
   {
      glRotatef(m_alphaMDH*RADTODEG, 1.0, 0.0, 0.0);
   }

   if ((m_aMDH != 0.0) || (m_dMDH != 0.0))
   {
      glTranslatef(m_aMDH, 0.0, m_dMDH);
   }

   // set dynamic z-axis transformation.
   glRotatef(m_thetaMDH*RADTODEG, 0.0, 0.0, 1.0);

   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmPrismaticLink::draw()
{
   // set static portion of the MDH transformation.
   if (m_alphaMDH != 0.0)
   {
      glRotatef(m_alphaMDH*RADTODEG, 1.0, 0.0, 0.0);
   }

   if ((m_aMDH != 0.0) || (m_dMDH != 0.0))
   {
      glTranslatef(m_aMDH, 0.0, m_dMDH);
   }

   if (m_thetaMDH != 0.0)
   {
      glRotatef(m_thetaMDH*RADTODEG, 0.0, 0.0, 1.0);
   }

   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmSphericalLink::draw()
{
   glTranslatef(m_p[0], m_p[1], m_p[2]);
   glRotatef(m_q[2]*RADTODEG, 0.0, 0.0, 1.0);
   glRotatef(m_q[1]*RADTODEG, 0.0, 1.0, 0.0);
   glRotatef(m_q[0]*RADTODEG, 1.0, 0.0, 0.0);

   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmQuaternionLink::draw()
{
   glTranslatef(m_p[0], m_p[1], m_p[2]);

   float len = sqrt(m_q[0]*m_q[0] + m_q[1]*m_q[1] + m_q[2]*m_q[2]);
   if (len > 1.0e-6)
   {
      float angle = 2.0*atan2(len, m_q[3]);
      glRotatef(angle*RADTODEG, m_q[0]/len, m_q[1]/len, m_q[2]/len);
   }

   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmMobileBaseLink::draw()
{
   glTranslatef(m_p[XC], m_p[YC], m_p[ZC]);

   float len = sqrt(m_quat[0]*m_quat[0] +
                    m_quat[1]*m_quat[1] +
                    m_quat[2]*m_quat[2]);
   if (len > 1.0e-6)
   {
      float angle = 2.0*atan2(len, m_quat[3]);
      glRotatef(angle*RADTODEG, m_quat[0]/len, m_quat[1]/len, m_quat[2]/len);
   }

   glCallList(*((GLuint *) getUserData()));
}

//----------------------------------------------------------------------------
void dmContactModel::draw()
{
}

//----------------------------------------------------------------------------
void dmEnvironment::draw()
{
   glCallList(m_terrain_model_index);
}
