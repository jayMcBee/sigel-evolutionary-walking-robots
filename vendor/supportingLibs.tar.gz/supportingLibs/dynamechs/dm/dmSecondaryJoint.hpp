/*****************************************************************************
 * DynaMechs: A Multibody Dynamic Simulation Library
 *
 * Copyright (C) 1994-2001  Scott McMillan   All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************
 *     File: dmSecondaryJoint.hpp
 *   Author: Scott McMillan
 *  Created: 1999
 *  Summary: Abstract base class declaration for secondary joints.
 *****************************************************************************/

#ifndef _DM_SECONDARY_JOINT_HPP
#define _DM_SECONDARY_JOINT_HPP

#include <dm.h>
#include <dmObject.hpp>
#include <dmArticulation.hpp>
#include <dmLink.hpp>


/** Documentation pending
 */

class DM_DLL_API dmSecondaryJoint : public dmObject
{
public:
   enum StabilizationEnum
   {
      NONE,
      BAUMGARTE,
      SPRING_DAMPER
   };  // Hard constraint stabilization methods.

public:
   ///
   dmSecondaryJoint();
   ///
   ~dmSecondaryJoint() {};
   ///
   void setArticulation(dmArticulation *art);
   ///
   void setLinkA(dmArticulation *art, dmLink *link);
   ///
   void setLinkB(dmArticulation *art, dmLink *link);
   ///
   int getLinkAIndex() {return m_link_A_index;}
   ///
   int getLinkBIndex() {return m_link_B_index;}
   ///
   void setKinematics(const CartesianVector pos_a,
                      const CartesianVector pos_b,
                      const RotationMatrix rot_a,
                      const RotationMatrix rot_b);
   ///
   void setStabilizationType(StabilizationEnum stab) {m_stabilization = stab;}
   ///
   inline StabilizationEnum getStabilizationType() { return m_stabilization; }

   ///
   virtual int getNumDOFs() const = 0;
   ///
   virtual void initXik(Float **Xik, int link_index,
                        int root_index) const = 0;
   ///
   virtual void getZeta(Float *zeta) const = 0;

   ///
   virtual void getFreeState(Float q[], Float qd[]) const = 0;
   ///
   virtual void getConstrainedState(Float q[], Float qd[]) const = 0;
   ///
   virtual void setJointInput(Float joint_input[]) = 0;

   ///
   Float getJointFriction() const {return m_joint_friction;}
   ///
   void setJointFriction(Float u_c) {m_joint_friction = u_c;}

   ///
   virtual void computeStabilizationForce(Float force[]) = 0;

   ///
   virtual void computeState();
   ///
   virtual void computeEtas() = 0;

   ///
   virtual void computeAppliedForce() = 0;
   ///
   virtual void applyPenaltyForce() = 0;
   ///
   void getAppliedAForce(SpatialVector force);
   ///
   void getAppliedBForce(SpatialVector force);

private:   // not implemented
   dmSecondaryJoint(const dmSecondaryJoint &);
   dmSecondaryJoint &operator=(const dmSecondaryJoint &);

protected:
   int               m_link_A_index;
   int               m_link_B_index;
   dmArticulation   *m_articulation;
   CartesianVector   m_a_p_oa;         // fixed
   RotationMatrix    m_a_R_oa;         // fixed
   CartesianVector   m_b_p_k;          // fixed
   RotationMatrix    m_b_R_k;          // fixed

   StabilizationEnum m_stabilization;  // only used for hard constraints

   RotationMatrix    m_a_R_k;          // function of state
   CartesianVector   m_a_p_k;          // function of state

   RotationMatrix    m_oa_R_k;         // function of state
   CartesianVector   m_k_w_rel;        // function of state
   CartesianVector   m_d;              // function of state
   CartesianVector   m_d_dot;          // function of state

   CartesianVector   m_oa_w_oa;
   CartesianVector   m_k_w_oa;

   SpatialVector     m_Eta_k1;         // used in sub classes
   SpatialVector     m_Eta_k2;         // used in sub classes

   SpatialVector     m_k_f_k;

   Float             m_joint_friction; // Coulomb(?) friction coefficient.
};

#endif
