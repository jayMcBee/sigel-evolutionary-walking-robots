/*****************************************************************************
 * DynaMechs: A Multibody Dynamic Simulation Library
 *
 * Copyright (C) 1994-2001  Scott McMillan   All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************
 *     File: dmIntegEuler.cpp
 *   Author: Scott McMillan
 *  Summary: 1st order fixed stepsize numerical integrator
 *****************************************************************************/

#include <dm.h>
#include <dmIntegEuler.hpp>

//----------------------------------------------------------------------------
dmIntegEuler::dmIntegEuler()
      : dmIntegrator(),
        m_qy(NULL),
        m_qdy(NULL)
{
}

//----------------------------------------------------------------------------
dmIntegEuler::~dmIntegEuler()
{
   if (m_system)
   {
      // deallocate any state variables.
      if (m_qy)
      {
         delete m_qy;
         delete m_qdy;
      }
   }
}

//----------------------------------------------------------------------------
bool dmIntegEuler::allocateStateVariables()
{
   // delete any preexisting simulation variables
   m_num_state_vars = 0;
   if (m_qy)   delete [] m_qy;
   if (m_qdy)  delete [] m_qdy;

   if (m_system)
   {
      // allocate new ones
      m_num_state_vars = m_system->makeStateVariable(&m_qy);
      m_num_state_vars = m_system->makeStateVariable(&m_qdy);

      m_system->initSimVars(m_qy, m_qdy);

      if (m_num_state_vars == 0)
      {
         return true;
      }

      if (m_num_state_vars && m_qy && m_qdy)
      {
         return true;
      }
   }

   return false;
}

// ---------------------------------------------------------------------------
// Function : simulateEuler
// Purpose  : Perform dynamic sim and numerical integration to obtain new
//              system state
// Inputs   : fixed integration stepsize.
// Outputs  : none
// ---------------------------------------------------------------------------
void dmIntegEuler::simulate(Float &delta_t)
{
   // It is left to the user to make sure isReadyToSim returns true
   //if (!m_ready_to_sim) initSimVars();

   // assume m_ry, m_qy state vectors are consistent with internally stored
   // information.

// Step 1. update the state based previously computed information
   for (unsigned int j = 0; j < m_num_state_vars; j++)
   {
      m_qy[j] += delta_t*m_qdy[j];
   }

// Step 1a. update the derivative based on the new state (and push the new
   // state to the internal variables while I am at it.
   m_system->ABDynamics(m_qy, m_qdy);
}
