/*****************************************************************************
 * DynaMechs: A Multibody Dynamic Simulation Library
 *
 * Copyright (C) 1994-2001  Scott McMillan   All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************
 *     File: dmSecondaryForce.hpp
 *   Author: Duane Marhefka
 *  Created: 1999
 *  Summary: Abstract base class for joint compliant forces
 *****************************************************************************/

#ifndef _DM_SECONDARY_FORCE_HPP
#define _DM_SECONDARY_FORCE_HPP

#include <dm.h>
#include <dmForce.hpp>
#include <dmSecondaryJoint.hpp>

/** Documentation pending.
 */

class dmSecondaryForce : public dmForce
{
public:
   enum JointSideEnum { LINK_A = 0, LINK_B = 1 };
public:
   ///
   dmSecondaryForce();
   ///
   dmSecondaryForce(JointSideEnum side, dmSecondaryJoint *joint);
   ///
   ~dmSecondaryForce();

   ///
   void reset();
   ///
   void computeForce(dmABForKinStruct *val, SpatialVector force);

   ///
   void drawInit() {};
   ///
   void draw() {};

private:
   JointSideEnum     m_joint_side;    // 0 = linkA, 1 = linkB
   dmSecondaryJoint *m_sec_joint;
};

#endif
