/*****************************************************************************
 * DynaMechs: A Multibody Dynamic Simulation Library
 *
 * Copyright (C) 1994-2001  Scott McMillan   All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************
 *     File: dmClosedArticulation.cpp
 *   Author: Duane Marhefka
 *  Created: 1999
 *  Summary: Class definition for articulations with closed loops.
 *****************************************************************************/

typedef long int integer;
typedef float real;
typedef double doublereal;

extern "C" int ssvdc_(real *x, integer *ldx, integer *n, integer *p,
                      real *s, real *e, real *u, integer *ldu,
                      real *v, integer *ldv, real *work, integer *job,
                      integer *info);

extern "C" int dsvdc_(doublereal *x, integer *ldx, integer *n, integer *p,
                      doublereal *s, doublereal *e, doublereal *u,
                      integer *ldu,
                      doublereal *v, integer *ldv, doublereal *work,
                      integer *job,
                      integer *info);

#include <dmClosedArticulation.hpp>

//============================================================================
// class dmClosedArticulation : public dmArticulation
//============================================================================

//----------------------------------------------------------------------------
//    Summary: default constructor for dmClosedArticulation objects
// Parameters: none
//    Returns: none
//----------------------------------------------------------------------------
dmClosedArticulation::dmClosedArticulation() :
      dmArticulation(),
      m_num_sec_joints(0),
      m_sec_joint(NULL),
      m_num_soft_joints(0),
      m_soft_joint(NULL)
{

#ifdef DEBUG
   cout << "dmClosedArticulation constructor: enter\n" << flush;
#endif

#ifdef DEBUG
   cout << "dmClosedArticulation constructor: exit\n" << flush;
#endif
}

//----------------------------------------------------------------------------
//    Summary: destructor for dmClosedArticulation instances which
//           : also frees any simulation variables that were allocated as
//           : links were added.
// Parameters: none.
//    Returns: none.
//----------------------------------------------------------------------------
dmClosedArticulation::~dmClosedArticulation()
{
#ifdef DEBUG
   cout << "dmClosedArticulation destructor:  \n" << flush;
#endif
}

//----------------------------------------------------------------------------
//    Summary: get a ptr to a hard secondary joint given its index
// Parameters: index - secondary joint's index
//    Returns: ptr to corresponding secondary joint,or NULL if out of range.
//----------------------------------------------------------------------------
dmSecondaryJoint *dmClosedArticulation::getHardSecondaryJoint(
   unsigned int index) const
{
   dmSecondaryJoint *secJoint = NULL;
   if (index < m_num_sec_joints)
   {
      secJoint = m_sec_joint[index];
   }

   return secJoint;
}

//----------------------------------------------------------------------------
//    Summary: get a ptr to a soft secondary joint given its index
// Parameters: index - secondary joint's index
//    Returns: ptr to corresponding secondary joint,or NULL if out of range.
//----------------------------------------------------------------------------
dmSecondaryJoint *dmClosedArticulation::getSoftSecondaryJoint(
   unsigned int index) const
{
   dmSecondaryJoint *secJoint = NULL;
   if (index < m_num_soft_joints)
   {
      secJoint = m_soft_joint[index];
   }

   return secJoint;
}

//----------------------------------------------------------------------------
//    Summary: Perform first outward recursion of AB algorithm.
// Parameters: joint_{pos,vel} - packed array of joint pos/vel for the entire
//                 articulation as computed by the numerical integration
//                 algorithms (usually).  This is a way to set the state of the
//                 system without incurring the extra function call overhead by
//                 separately calling setState and then this function.
//             ref_val - pointer to struct filled with the kinematic parameters
//                 of the reference member.
//    Returns:
//----------------------------------------------------------------------------
void dmClosedArticulation::ABForwardKinematics(Float joint_pos[],
                                               Float joint_vel[],
                                               dmABForKinStruct *ref_val)
{
#ifdef DEBUG
   cout << "dmClosedArticulation::ABForwardKinematics\n" << flush;
#endif

   dmArticulation::ABForwardKinematics(joint_pos, joint_vel, ref_val);

   unsigned int i,k;

   for (k = 0; k < m_num_sec_joints; k++)
   {
      m_sec_joint[k]->computeState();
      m_sec_joint[k]->computeAppliedForce();
   }

   for (k = 0; k < m_num_soft_joints; k++)
   {
      m_soft_joint[k]->computeState();
      m_soft_joint[k]->computeAppliedForce();
      m_soft_joint[k]->applyPenaltyForce();
   }

   // ********************************************************
   // Save some time if all secondary joints are 'soft'.
   // This just eliminates empty loop executions.
   if (m_num_sec_joints == 0)
      return;
   // ********************************************************


   // Initialize Xik's of p1(k) and p2(k) links.
   // Clear Xik's of loop roots for accumulation.
   for (i = 0; i < m_link_list.size(); i++)
      for (k = 0; k < m_num_sec_joints; k++)
         if (m_Xik[i][k] != NULL)
            m_sec_joint[k]->initXik(m_Xik[i][k], i, m_loop_root_index[k]);

   for (k = 0; k < m_num_sec_joints; k++)
   {
      m_sec_joint[k]->computeEtas();
      m_sec_joint[k]->getZeta(m_zetak[k]);
   }

   // Clear Bmn's.
   unsigned int m, n, r, c;
   for (m = 0; m < m_num_sec_joints; m++)
      for (n = 0; n < m_num_sec_joints; n++)
         if (m_Bmn[m][n] != NULL)
         {
            for (r = 0; r < m_num_constraints[m]; r++)
               for (c = 0; c < m_num_constraints[n]; c++)
                  m_Bmn[m][n][r][c] = 0.0;
         }
}


//----------------------------------------------------------------------------
//    Summary: 2nd (inward) iteration of AB dynamics algorithm.
// Parameters: none
//    Returns:
//----------------------------------------------------------------------------
void dmClosedArticulation::ABBackwardDynamics()
{
   // ********************************************************
   // Save some time if all secondary joints are 'soft'.
   // This just eliminates empty loop executions.
   if (m_num_sec_joints == 0)
   {
      dmArticulation::ABBackwardDynamics();
      return;
   }
   // ********************************************************

   SpatialVector f_star_tmp;
   SpatialTensor I_refl_tmp;
   SpatialVector f_star_ref;
   SpatialTensor I_refl_ref;

   // =================================================================
   // clear variables at branch points in preparation for accumulation
   for (unsigned int k=0; k<m_link_list.size(); k++)
   {
      if (m_link_list[k]->child_list.size() > 1)
      {
         for (unsigned int i=0; i<6; i++)
         {
            m_link_list[k]->f_star[i] = 0;
            for (unsigned int j=i; j<6; j++)
            {
               m_link_list[k]->I_refl[i][j] =
                  m_link_list[k]->I_refl[j][i] = 0.0;
            }
         }
      }
   }


   // backward recursion through all links except the first.
   for (unsigned int i=m_link_list.size()-1; i>=1; i--)
   {
      // Eliminate loops at root.
      if (m_num_elements_LR[i] > 0)
         eliminateLoops(i);

      // non-first links with siblings
      if (m_link_list[i]->parent->child_list.size() > 1)
      {
         if (m_link_list[i]->child_list.size() == 0)
         {
            m_link_list[i]->link->ABBackwardDynamicsN(
               &m_link_list[i]->link_val,
               f_star_tmp,
               I_refl_tmp);
         }
         else
         {
            m_link_list[i]->link->ABBackwardDynamics(
               &m_link_list[i]->link_val,
               m_link_list[i]->f_star,
               m_link_list[i]->I_refl,
               f_star_tmp,
               I_refl_tmp);
         }

         // accumulate result
         for (unsigned int j=0; j<6; j++)
         {
            m_link_list[i]->parent->f_star[j] += f_star_tmp[j];
            for (unsigned int k=j; k<6; k++)
            {
               m_link_list[i]->parent->I_refl[j][k] =
                  m_link_list[i]->parent->I_refl[k][j] += I_refl_tmp[j][k];
            }
         }
      }

      // for non-first links with no siblings
      else
      {
         if (m_link_list[i]->child_list.size() == 0)
         {
            m_link_list[i]->link->ABBackwardDynamicsN(
               &m_link_list[i]->link_val,
               m_link_list[i]->parent->f_star,
               m_link_list[i]->parent->I_refl);
         }
         else
         {
            m_link_list[i]->link->ABBackwardDynamics(
               &m_link_list[i]->link_val,
               m_link_list[i]->f_star,
               m_link_list[i]->I_refl,
               m_link_list[i]->parent->f_star,
               m_link_list[i]->parent->I_refl);
         }
      }

      // Propagate secondary joint constraints to previous link.
      propagateConstraints(i);
   }


   // Do the first link - always attached to the reference member.

   // Eliminate loops at first link.
   if (m_num_elements_LR[0] > 0)
      eliminateLoops(0);

   if (m_link_list[0]->child_list.size() == 0)
   {
      m_link_list[0]->link->ABBackwardDynamicsN(
         &m_link_list[0]->link_val,
         f_star_ref,
         I_refl_ref);
   }
   else
   {
      m_link_list[0]->link->ABBackwardDynamics(
         &m_link_list[0]->link_val,
         m_link_list[0]->f_star,
         m_link_list[0]->I_refl,
         f_star_ref,
         I_refl_ref);
   }

   // No propagateConstraints(0), since all loops in articulation closed
   // at or before first link, or LB(0) = Null Set.
}

//----------------------------------------------------------------------------
//    Summary: 3rd (outward) recursion of AB alg. to compute joint accels.
// Parameters: a_ref - spatial acceleration of reference member expressed in
//                     body coordinate systems
//    Returns: the derivative of state:
//             joint_vel - packed array of joint velocities which correspond
//                         to the time derivatives of position vectors.
//                         This distinction is especially important when
//                         having to transform ang. vel to Euler angle rates
//             joint_acc - packed array, accelerations (time derivative of
//                         state vector velocities)
//----------------------------------------------------------------------------
void dmClosedArticulation::ABForwardAccelerations(SpatialVector a_ref,
                                                  Float joint_vel[],
                                                  Float joint_acc[])
{
   // ********************************************************
   // Save some time if all secondary joints are 'soft'.
   // This just eliminates empty loop executions.
   if (m_num_sec_joints == 0)
   {
      dmArticulation::ABForwardAccelerations(a_ref, joint_vel, joint_acc);
      return;
   }
   // ********************************************************


   m_link_list[0]->link->ABForwardAccelerations(a_ref,
                                                m_link_list[0]->accel,
                                                &joint_vel[0],
                                                &joint_acc[0]);

   // Compute constraint forces of loops whose root is first link.
   if (m_num_elements_LR[0] > 0)
      computeConstraintForces(0);

   unsigned int joint_index_offset = m_link_list[0]->link->getNumDOFs();

   for (unsigned int i = 1; i < m_link_list.size(); i++)
   {
      m_link_list[i]->link->ABForwardAccelerations(
         m_link_list[i]->parent->accel,
         m_LB[i],
         m_num_elements_LB[i],
         m_Xik[i],
         m_lambda_c,
         m_num_constraints,
         m_link_list[i]->accel,
         &joint_vel[joint_index_offset],
         &joint_acc[joint_index_offset]);

      // Compute constraint forces of loops whose root is link i.
      if (m_num_elements_LR[i] > 0)
         computeConstraintForces(i);

      joint_index_offset += m_link_list[i]->link->getNumDOFs();
   }
}

//----------------------------------------------------------------------------
void dmClosedArticulation::computeConstraintForces(unsigned int i)
{
   Float *lambda_star = (Float *)malloc(m_constraints_at_root[i]*
                                        sizeof(Float));

   for (unsigned int j = 0; j < m_constraints_at_root[i]; j++)
   {
      lambda_star[j] = (m_Binv_zetai[i][j]
                        -  m_Binv_Xi[i][j][0]*(m_link_list[i]->accel)[0]
                        -  m_Binv_Xi[i][j][1]*(m_link_list[i]->accel)[1]
                        -  m_Binv_Xi[i][j][2]*(m_link_list[i]->accel)[2]
                        -  m_Binv_Xi[i][j][3]*(m_link_list[i]->accel)[3]
                        -  m_Binv_Xi[i][j][4]*(m_link_list[i]->accel)[4]
                        -  m_Binv_Xi[i][j][5]*(m_link_list[i]->accel)[5]);

      for (unsigned int p = 0; p < m_num_elements_LJ_star[i]; p++)
      {
         int m = m_LJ_star[i][p];

         for (unsigned int q = 0; q < m_num_constraints[m]; q++)
         {
            lambda_star[j] -= (m_Binv_Bim[i][m][j][q]*
                               m_lambda_c[m][q]);
         }
      }
   }


   // Pull constraint force elements out of lambda_star.
   unsigned int force_offset = 0;
   for (unsigned int jj = 0; jj < m_num_elements_LR[i]; jj++)
   {
      int m = m_LR[i][jj];

      for (unsigned int p = 0; p < m_num_constraints[m]; p++)
         m_lambda_c[m][p] = lambda_star[force_offset+p];

      force_offset += m_num_constraints[m];
   }

   free(lambda_star);
}


//----------------------------------------------------------------------------
//    Summary: adds a 'Hard' secondary joint to the closed articulation.
//    Returns: TRUE if operation is successful
//             FALSE if unsuccessful
//----------------------------------------------------------------------------
bool dmClosedArticulation::addHardSecondaryJoint(dmSecondaryJoint *joint)
{
   dmSecondaryJoint **tmp = m_sec_joint;
   if ((m_sec_joint = (dmSecondaryJoint **)
        realloc(m_sec_joint, (m_num_sec_joints+1)*sizeof(dmSecondaryJoint*)))
       == NULL)
   {
      cerr << "dmClosedArticulation::addHardSecondaryJoint error:  "
           << "Unable to realloc m_sec_joint." << endl;
      // restore previous pointer
      m_sec_joint = tmp;
      return false;
   }

   m_sec_joint[m_num_sec_joints] = joint;
   m_num_sec_joints++;

   return true;
}

//----------------------------------------------------------------------------
//    Summary: adds a 'Soft' secondary joint to the closed articulation.
//    Returns: TRUE if operation is successful
//             FALSE if unsuccessful
//----------------------------------------------------------------------------
bool dmClosedArticulation::addSoftSecondaryJoint(dmSecondaryJoint *joint)
{
   dmSecondaryJoint **tmp = m_soft_joint;
   if ((m_soft_joint = (dmSecondaryJoint **)
        realloc(m_soft_joint, (m_num_soft_joints+1)*sizeof(dmSecondaryJoint*)))
       == NULL)
   {
      cerr << "dmClosedArticulation::addSoftSecondaryJoint error:  "
           << "Unable to realloc m_soft_joint." << endl;
      // restore previous pointer
      m_soft_joint = tmp;
      return false;
   }

   m_soft_joint[m_num_soft_joints] = joint;
   m_num_soft_joints++;

   return true;
}

//----------------------------------------------------------------------------
void dmClosedArticulation::initKinematicLoopVars()
{
   unsigned int i, j, k, l;

   m_num_elements_LB =
      (unsigned int *)malloc(m_link_list.size()*sizeof(unsigned int));
   m_LB = (unsigned int **)malloc(m_link_list.size()*sizeof(unsigned int *));

   m_num_elements_LR =
      (unsigned int *)malloc(m_link_list.size()*sizeof(unsigned int));
   m_LR = (unsigned int **)malloc(m_link_list.size()*sizeof(unsigned int *));

   m_loop_root_index =
      (unsigned int *)malloc(m_num_sec_joints*sizeof(unsigned int));
   m_num_constraints =
      (unsigned int *)malloc(m_num_sec_joints*sizeof(unsigned int));

   for (i = 0; i < m_link_list.size(); i++)
   {
      m_num_elements_LB[i] = 0;
      m_LB[i] = NULL;

      m_num_elements_LR[i] = 0;
      m_LR[i] = NULL;
   }

   // Determine which links belong to loop k and also the root of k.
   for (k = 0; k < m_num_sec_joints; k++)
   {
      unsigned int a = m_sec_joint[k]->getLinkAIndex();
      unsigned int b = m_sec_joint[k]->getLinkBIndex();

      // Determine links which belong to loop k.
      while (a != b)
      {
         if (a>b) // a isn't root of loop k, so add k to LB(a)
         {
            m_LB[a] = (unsigned int *)realloc(m_LB[a],
                                              (m_num_elements_LB[a]+1)*
                                              sizeof(unsigned int));
            m_LB[a][m_num_elements_LB[a]] = k;
            m_num_elements_LB[a] += 1;
            a = (m_link_list[a]->parent)->index;
         }
         else  // b isn't root of loop k, so add k to LB(b)
         {
            m_LB[b] =
               (unsigned int *)realloc(m_LB[b],
                                       (m_num_elements_LB[b]+1)*
                                       sizeof(unsigned int));
            m_LB[b][m_num_elements_LB[b]] = k;
            m_num_elements_LB[b] += 1;
            b = (m_link_list[b]->parent)->index;
         }
      }

      // At root of loop since a == b.  Add k to LR(a).
      m_loop_root_index[k] = a;
      m_LR[a] = (unsigned int *)realloc(
         m_LR[a], (m_num_elements_LR[a]+1)*sizeof(unsigned int));
      m_LR[a][m_num_elements_LR[a]] = k;
      m_num_elements_LR[a] += 1;
   }

   m_num_elements_LC =
      (unsigned int *)malloc(m_num_sec_joints*sizeof(unsigned int));
   m_LC = (unsigned int **)malloc(m_num_sec_joints*sizeof(unsigned int *));

   // Compute connected loops (LC(k)) for each secondary joint.
   for (k = 0; k < m_num_sec_joints; k++)
   {
      // Initialize LC(k).
      m_num_elements_LC[k] = 0;
      m_LC[k] = NULL;

      for (i = 0; i < m_link_list.size(); i++)
      {
         unsigned int flag = 0;
         for (j = 0; j < m_num_elements_LB[i]; j++)
         {
            if (m_LB[i][j] == k)
               flag = 1;
         }

         if (flag == 1) // k is in LB(i)
         {
            // add elements of LB(i) to LC(k)
            for (j = 0; j < m_num_elements_LB[i]; j++)
            {
               // Test if element aleady in LC(k).
               unsigned int already_connected = 0;
               for (l = 0; l < m_num_elements_LC[k]; l++)
               {
                  if (m_LC[k][l] == m_LB[i][j])
                     already_connected = 1;
               }

               // Add to LC(k) if not already included and not k itself.
               if ((!already_connected) && (m_LB[i][j]!=k))
               {
                  m_LC[k] = (unsigned int *)realloc(m_LC[k],
                                                    (m_num_elements_LC[k]+1)
                                                    *sizeof(unsigned int));
                  m_LC[k][m_num_elements_LC[k]] = m_LB[i][j];
                  m_num_elements_LC[k] += 1;
               }
            }
         }
      }
   }

   // Compute LJ*(i) for each link.
   m_num_elements_LJ_star =
      (unsigned int *)malloc(m_link_list.size()*sizeof(unsigned int));
   m_LJ_star =
      (unsigned int **)malloc(m_link_list.size()*sizeof(unsigned int *));

   bool *LJ_work = (bool *)malloc(m_num_sec_joints*sizeof(bool));

   for (i = 0; i < m_link_list.size(); i++)
   {
      m_num_elements_LJ_star[i] = 0;
      m_LJ_star[i] = (unsigned int *)NULL;

      // Initialize membership of each loop in LJ*(i) = False.
      for (k = 0; k < m_num_sec_joints; k++)
         LJ_work[k] = false;

      // Loop through all loops in LR(i).
      for (j = 0; j < m_num_elements_LR[i]; j++)
      {
         unsigned int loop_in_LR = m_LR[i][j];

         // Loop through loops connected to current element of LR.
         for (k = 0; k < m_num_elements_LC[loop_in_LR]; k++)
         {
            unsigned int connected_loop = m_LC[loop_in_LR][k];

            // Mark loops for membership in LJ*(i).
            if (m_loop_root_index[connected_loop] < i)
               LJ_work[connected_loop] = true;
         }
      }

      // Add marked loops to LJ*(i).
      for (k = 0; k < m_num_sec_joints; k++)
         if (LJ_work[k] == true)
         {
            m_LJ_star[i] =
               (unsigned int *)realloc(m_LJ_star[i],
                                       (m_num_elements_LJ_star[i]+1)*
                                       sizeof(unsigned int));
            m_LJ_star[i][m_num_elements_LJ_star[i]] = k;
            m_num_elements_LJ_star[i] += 1;
         }
   }

   free(LJ_work);


   // Allocate the Xik's. (2D array of matrices m_Xik[i][k][r][c])
   m_Xik = (Float ****)malloc(m_link_list.size()*sizeof(Float ***));
   for (i = 0; i < m_link_list.size(); i++)
   {
      m_Xik[i] = (Float ***)malloc(m_num_sec_joints*sizeof(Float **));

      for (k = 0; k < m_num_sec_joints; k++)
      {
         // Only allocate the matrix if k is an element of LB(i) or LR(i).

         bool member_flag = false;
         for (j = 0; j < m_num_elements_LR[i]; j++)
            if (m_LR[i][j] == k)
               member_flag = true;

         for (j = 0; j < m_num_elements_LB[i]; j++)
            if (m_LB[i][j] == k)
               member_flag = true;

         if (member_flag == false)
            m_Xik[i][k] = NULL;
         else
         {
            // Matrix has 6 rows.
            m_Xik[i][k] = (Float **)malloc(6*sizeof(Float *));

            unsigned int r, columns;
            for (r = 0; r < 6; r++)
            {
               columns = 6 - m_sec_joint[k]->getNumDOFs();
               m_Xik[i][k][r] = (Float *)malloc(columns*sizeof(Float));
            }
         }
      }
   }

   // Fill in the number of constrained DOF's for each loop k.
   for (k = 0; k < m_num_sec_joints; k++)
      m_num_constraints[k] = 6 - m_sec_joint[k]->getNumDOFs();

   // Allocate the Zeta_k's.
   m_zetak = (Float **)malloc(m_num_sec_joints*sizeof(Float *));
   for (k = 0; k < m_num_sec_joints; k++)
      m_zetak[k] = (Float *)malloc(m_num_constraints[k]*sizeof(Float));

   // Allocate the Bmn's. (2D array of matrices m_Bmn[m][n][r][c])
   m_Bmn = (Float ****)malloc(m_num_sec_joints*sizeof(Float ***));
   for (unsigned int m = 0; m < m_num_sec_joints; m++)
   {
      m_Bmn[m] = (Float ***)malloc(m_num_sec_joints*sizeof(Float **));

      // Initialize all Bmn's to null pointers.
      for (unsigned int n = 0; n < m_num_sec_joints; n++)
         m_Bmn[m][n] = (Float **)NULL;

      // Allocate Bmn's which are actually used (connected loops).
      for (unsigned int i = 0; i < m_num_elements_LC[m]; i++)
      {
         unsigned int n = m_LC[m][i];

         m_Bmn[m][n] = (Float **)malloc(m_num_constraints[m]*sizeof(Float *));

         for (unsigned int r = 0; r < m_num_constraints[m]; r++)
            m_Bmn[m][n][r] = (Float *)malloc(m_num_constraints[n]
                                             *sizeof(Float));
      }

      // Allocate Bmm.
      m_Bmn[m][m] = (Float **)malloc(m_num_constraints[m]*sizeof(Float *));
      for (unsigned int r = 0; r < m_num_constraints[m]; r++)
         m_Bmn[m][m][r] = (Float *)malloc(m_num_constraints[m]*sizeof(Float));
   }

   // Compute how many constraint force elements are resolved at each link.
   m_constraints_at_root =
      (unsigned int *)malloc(m_link_list.size()*sizeof(unsigned int));
   for (i = 0; i < m_link_list.size(); i++)
   {
      m_constraints_at_root[i] = 0;
      for (unsigned int j = 0; j < m_num_elements_LR[i]; j++)
         m_constraints_at_root[i] += m_num_constraints[m_LR[i][j]];
   }

   // Allocate the m_Binv_zeta's.
   m_Binv_zetai = (Float **)malloc(m_link_list.size()*sizeof(Float *));
   for (i = 0; i < m_link_list.size(); i++)
      m_Binv_zetai[i] = (Float *)malloc(m_constraints_at_root[i]*sizeof(Float));

   // Allocate the m_Binv_Xi's.
   m_Binv_Xi = (Float ***)malloc(m_link_list.size()*sizeof(Float **));
   for (i = 0; i < m_link_list.size(); i++)
   {
      m_Binv_Xi[i] = (Float **)malloc(m_constraints_at_root[i]*
                                      sizeof(Float *));

      for (unsigned int j = 0; j < m_constraints_at_root[i]; j++)
         m_Binv_Xi[i][j] = (Float *)malloc(6*sizeof(Float));
   }

   // Allocate the m_Binv_Bim's.
   m_Binv_Bim = (Float ****)malloc(m_link_list.size()*sizeof(Float ***));
   for (i = 0; i < m_link_list.size(); i++)
   {
      m_Binv_Bim[i] = (Float ***)malloc(m_num_sec_joints*sizeof(Float **));
      for (unsigned int j = 0; j < m_num_elements_LJ_star[i]; j++)
      {
         unsigned int m = m_LJ_star[i][j];

         m_Binv_Bim[i][m] = (Float **)malloc(m_constraints_at_root[i]*
                                             sizeof(Float *));

         for (unsigned int r = 0; r < m_constraints_at_root[i]; r++)
            m_Binv_Bim[i][m][r] = (Float *)malloc(m_num_constraints[m]*
                                                  sizeof(Float));
      }
   }

   // Allocate storage for the constraint forces.
   m_lambda_c = (Float **)malloc(m_num_sec_joints*sizeof(Float *));
   for (i = 0; i < m_num_sec_joints; i++)
      m_lambda_c[i] = (Float *)malloc(m_num_constraints[i]*sizeof(Float));

#if 0
   for (i = 0; i < m_link_list.size(); i++)
   {
      cerr << "\nLB(" << i << "): ";
      for (unsigned int j = 0; j < m_num_elements_LB[i]; j++)
         cerr << m_LB[i][j] << " ";
   }
   cerr << endl << endl;

   for (i = 0; i < m_link_list.size(); i++)
   {
      cerr << "\nLR(" << i << "): ";
      for (unsigned int j = 0; j < m_num_elements_LR[i]; j++)
         cerr << m_LR[i][j] << " ";
   }
   cerr << endl << endl;

   for (k = 0; k < m_num_sec_joints; k++)
   {
      cerr << "\nLC(" << k << "): ";
      for (unsigned int l = 0; l < m_num_elements_LC[k]; l++)
         cerr << m_LC[k][l] << " ";
   }
   cerr << endl << endl;

   for (i = 0; i < m_link_list.size(); i++)
   {
      cerr << "\nLJ*(" << i << "): ";
      for (unsigned int k = 0; k < m_num_elements_LJ_star[i]; k++)
         cerr << m_LJ_star[i][k] << " ";
   }
   cerr << endl << endl;

   for (k = 0; k < m_num_sec_joints; k++)
   {
      cerr << "\nRoot(" << k << ") = " << m_loop_root_index[k];
   }
   cerr << endl << endl;
#endif
}


//----------------------------------------------------------------------------
void dmClosedArticulation::eliminateLoops(unsigned int i)
{
   unsigned int j;
   Float **X_star = (Float **)malloc(6*sizeof(Float *));
   for (j = 0; j < 6; j++)
      X_star[j] = (Float *)malloc(m_constraints_at_root[i]
                                  *sizeof(Float));

   Float *zeta_star = (Float *)malloc(m_constraints_at_root[i]
                                      *sizeof(Float));

   Float ***Bim_star = (Float ***)malloc(m_num_sec_joints*
                                         sizeof(Float **));
   for (j = 0; j < m_num_elements_LJ_star[i]; j++)
   {
      unsigned int m = m_LJ_star[i][j];

      Bim_star[m] = (Float **)malloc(m_constraints_at_root[i]
                                     *sizeof(Float *));

      for (unsigned int n = 0; n < m_constraints_at_root[i]; n++)
         Bim_star[m][n] = (Float *)calloc(m_num_constraints[m],
                                          sizeof(Float));
   }

   unsigned int offset = 0;
   for (j = 0; j < m_num_elements_LR[i]; j++)
   {
      // Set up X*(i).
      for (unsigned int l = 0; l < 6; l++)
      {
         for (unsigned int k = 0; k < m_num_constraints[m_LR[i][j]]; k++)
            X_star[l][k+offset] = m_Xik[i][m_LR[i][j]][l][k];
      }

      // Set up zeta*(i).
      for (unsigned int k = 0; k < m_num_constraints[m_LR[i][j]]; k++)
      {
         zeta_star[k+offset] = m_zetak[m_LR[i][j]][k];
      }

      // Set up B*im.
      for (unsigned int n = 0; n < m_num_elements_LC[m_LR[i][j]]; n++)
      {
         unsigned int m = m_LC[m_LR[i][j]][n];

         if (m_loop_root_index[m] < i)
            for (unsigned int r = 0; r < m_num_constraints[m_LR[i][j]]; r++)
               for (unsigned int c = 0; c < m_num_constraints[m]; c++)
                  Bim_star[m][r+offset][c] = m_Bmn[m_LR[i][j]][m][r][c];
      }

      offset += m_num_constraints[m_LR[i][j]];
   }


   // ******************* Linpack SVD ********************************

   // Allocate a 1D array for B*(i) (to interface with Fortran SVD).
   // SVD routines come in single and double single precision, so use can
   // use the 'Float' typedef, which could be defined as float or double.
   // SVD routine will destroy contents of Bi_star.
   Float *Bi_star = (Float *)calloc(m_constraints_at_root[i]*
                                    m_constraints_at_root[i],
                                    sizeof(Float));

   unsigned int row_offset = 0;
   for (j = 0; j < m_num_elements_LR[i]; j++)
   {
      unsigned int k = m_LR[i][j];
      unsigned int col_offset = 0;

      for (unsigned int p = 0; p < m_num_elements_LR[i]; p++)
      {
         unsigned int m = m_LR[i][p];

         if (m_Bmn[k][m] != NULL) // k and m connected
         {
            // Copy Bkm into B*(i).
            for (unsigned int r = 0; r < m_num_constraints[k]; r++)
               for (unsigned int c = 0; c < m_num_constraints[m]; c++)
               {
                  unsigned int index = ((r+row_offset) +
                                        m_constraints_at_root[i]*
                                        (c+col_offset));
                  Bi_star[index] = m_Bmn[k][m][r][c];
               }
         }

         col_offset += m_num_constraints[m];
      }

      row_offset += m_num_constraints[k];
   }

   Float *u;           /* svd decomp u */
   Float *v;           /* svd decomp v */
   Float *s;           /* array of singular values (descending order)*/
   Float *e;           /* don't worry about */
   Float *work;        /* scratch array used by ssvdc. */
   long int n;         /* Matrix dimensions = nxn. */
   long int info;      /* Should equal zero upon return from ssvdc. */
   long int job = 11;

   n = (long int) m_constraints_at_root[i];  // HACK cast
   u = (Float *)malloc(n*n*sizeof(Float));
   v = (Float *)malloc(n*n*sizeof(Float));
   s = (Float *)malloc(n*sizeof(Float));
   e = (Float *)malloc(n*sizeof(Float));
   work = (Float *)malloc(n*sizeof(Float));

   if ((Bi_star == NULL) || (u == NULL) || (v == NULL) ||
       (s == NULL) || (e == NULL) || (work == NULL))
      cout << "SVD ALLOCATION ERROR" << endl;

#ifdef DM_DOUBLE_PRECISION
   dsvdc_(Bi_star, &n, &n, &n, s, e, u, &n, v, &n, work, &job, &info);
#else
   ssvdc_(Bi_star, &n, &n, &n, s, e, u, &n, v, &n, work, &job, &info);
#endif

   if (info != 0)
   {
      cout << "\n\nEROOR:  Singular Value Decomposition failed." << endl;
      exit(-1);
   }

   // ********************** End Linpack SVD ***************************

#if 0
   //  cout << "\ninfo: " << info << endl;

   cout << "\nU:";
   for (unsigned int rr = 0; rr < n; rr++)
   {
      cout << endl;
      for (unsigned int c = 0; c < n; c++)
         cout << "  " << u[rr+c*n];
   }
   cout << endl;

   cout << "\ns:";
   for (rr = 0; rr < n; rr++)
      cout << "  " << s[rr];
   cout << endl;

   cout << "\nV:";
   for (rr = 0; rr < n; rr++)
   {
      cout << endl;
      for (unsigned int c = 0; c < n; c++)
         cout << "  " << v[rr+c*n];
   }
   cout << endl;
#endif



   // Invert singular value diagonal matrix,
   // zeroing infinite elements.
   float max_singular_value = s[0];
   s[0] = 1.0/s[0];
   for (j = 1; j < (unsigned int)n; j++)  // HACK (cast)
   {
      if (50000*s[j] < max_singular_value)
         s[j] = 0;
      else
         s[j] = 1.0/s[j];
   }

   //  Compute inverse(B*(i)).
   Float **inv_Bi_star = (Float **)malloc(m_constraints_at_root[i]*
                                          sizeof(Float *));
   for (j = 0; j < m_constraints_at_root[i]; j++)
      inv_Bi_star[j] = (Float *)malloc(m_constraints_at_root[i]*
                                       sizeof(Float));

   unsigned int r;
   for (r = 0; r < m_constraints_at_root[i]; r++)
      for (unsigned int c = 0; c < m_constraints_at_root[i]; c++)
      {
         inv_Bi_star[r][c] = 0;

         for (j = 0; j < m_constraints_at_root[i]; j++)
            inv_Bi_star[r][c] += (v[r+m_constraints_at_root[i]*j]*s[j]*
                                  u[c+m_constraints_at_root[i]*j]);
      }


   // Compute inv(B*(i)) x (X*(i))^T
   for (r = 0; r < m_constraints_at_root[i]; r++)
      for (unsigned int c = 0; c < 6; c++)
      {
         m_Binv_Xi[i][r][c] = 0;
         for (j = 0; j < m_constraints_at_root[i]; j++)
            m_Binv_Xi[i][r][c] += inv_Bi_star[r][j]*X_star[c][j];
      }

   // *******************************
   // Compute/Add in reflected inertia due to the loop.
   for (r = 0; r < 6; r++)
      for (unsigned int c = 0; c < 6; c++)
         for (j = 0; j < m_constraints_at_root[i]; j++)
            (m_link_list[i]->I_refl)[r][c] += X_star[r][j]*m_Binv_Xi[i][j][c];

   // Compute inv(B*(i)) x zeta*(i)
   for (r = 0; r < m_constraints_at_root[i]; r++)
   {
      m_Binv_zetai[i][r] = 0;

      for (j = 0; j < m_constraints_at_root[i]; j++)
         m_Binv_zetai[i][r] += inv_Bi_star[r][j]*zeta_star[j];
   }

   // ******************************************************************
   // Constraint stabilization with springs and dampers.
   // Add known stabilization forces to lambda_star in inv(B*(i)) x zeta*(i)

   unsigned int force_offset = 0;
   for (j = 0; j < m_num_elements_LR[i]; j++)
   {
      unsigned int k = m_LR[i][j];

      if (m_sec_joint[k]->getStabilizationType() ==
          dmSecondaryJoint::SPRING_DAMPER)
      {
         // Get spring/damper stabilization wrench for secondary joint k.
         Float lambda_c[6];
         m_sec_joint[k]->computeStabilizationForce(lambda_c);

         for (unsigned int p = 0; p < m_num_constraints[k]; p++)
            m_Binv_zetai[i][force_offset+p] += lambda_c[p];
      }

      force_offset += m_num_constraints[k];
   }
   // ******************************************************************

   // Modify bias force.
   for (r = 0; r < 6; r++)
      for (j = 0; j < m_constraints_at_root[i]; j++)
         (m_link_list[i]->f_star)[r] += X_star[r][j]*m_Binv_zetai[i][j];

   //  Compute changes to Xim's for m in LJ*(i).
   for (j = 0; j < m_num_elements_LJ_star[i]; j++)
   {
      unsigned int m = m_LJ_star[i][j];

      // Compute inv(B*(i)) x B*im
      for (r = 0; r < m_constraints_at_root[i]; r++)
         for (unsigned int c = 0; c < m_num_constraints[m]; c++)
         {
            m_Binv_Bim[i][m][r][c] = 0;

            for (unsigned int p = 0; p < m_constraints_at_root[i]; p++)
               m_Binv_Bim[i][m][r][c] += (inv_Bi_star[r][p]*
                                          Bim_star[m][p][c]);
         }

      for (r = 0; r < 6; r++)
         for (unsigned int c = 0; c < m_num_constraints[m]; c++)
            for (unsigned int p = 0; p < m_constraints_at_root[i]; p++)
               m_Xik[i][m][r][c] -= X_star[r][p]*m_Binv_Bim[i][m][p][c];
   }

   //  Compute changes to Bmn's in LJ*(i).
   for (j = 0; j < m_num_elements_LJ_star[i]; j++)
   {
      unsigned int m = m_LJ_star[i][j];

      for (unsigned int p = 0; p < m_num_elements_LJ_star[i]; p++)
      {
         unsigned int n = m_LJ_star[i][p];

         for (r = 0; r < m_num_constraints[m]; r++)
            for (unsigned int c = 0; c < m_num_constraints[n]; c++)
               for (unsigned int q = 0; q < m_constraints_at_root[i]; q++)
                  m_Bmn[m][n][r][c] -= (Bim_star[m][q][r]*
                                        m_Binv_Bim[i][n][q][c]);
      }
   }

   //  Compute changes to m_zetak's in  LJ*(i).
   for (j = 0; j < m_num_elements_LJ_star[i]; j++)
   {
      unsigned int m = m_LJ_star[i][j];

      for (r = 0; r < m_num_constraints[m]; r++)
         for (unsigned int p = 0; p < m_constraints_at_root[i]; p++)
            m_zetak[m][r] -=  Bim_star[m][p][r]*m_Binv_zetai[i][p];
   }


   // **********************************************************

   // Free temporary variables.
   for (j = 0; j < 6; j++)
      free(X_star[j]);
   free(X_star);

   for (j = 0; j < m_constraints_at_root[i]; j++)
   {
      free(inv_Bi_star[j]);
   }
   free(inv_Bi_star);

   for (j = 0; j < m_num_elements_LJ_star[i]; j++)
   {
      unsigned int m = m_LJ_star[i][j];

      for (unsigned int n = 0; n < m_constraints_at_root[i]; n++)
         free(Bim_star[m][n]);

      free(Bim_star[m]);
   }
   free(Bim_star);

   free(zeta_star);
   free(Bi_star);
   free(u);
   free(v);
   free(s);
   free(e);
   free(work);
}


//----------------------------------------------------------------------------
void dmClosedArticulation::propagateConstraints(unsigned int i)
{
   unsigned int j;
   for (j = 0; j < m_num_elements_LB[i]; j++)
   {
      unsigned int k = m_LB[i][j];

      // get the parent's index
      unsigned int prev = m_link_list[i]->parent->index;

      if (prev != m_loop_root_index[k])
      {
         // Set Xik directly for parent link.
         m_link_list[i]->link->XikToInboard(m_Xik[i][k], m_Xik[prev][k],
                                            m_num_constraints[k]);
      }
      else
      {
         // Must accumulate Xik for parent link (loop root).
         // Note that m_Xik was set to zero in ABForwardKinematics
         // for the loop root.
         Float **tmp;
         unsigned int r;

         tmp = (Float **)malloc(6*sizeof(Float *));
         for (r = 0; r < 6; r++)
            tmp[r] = (Float *)malloc(m_num_constraints[k]*sizeof(Float));

         m_link_list[i]->link->XikToInboard(m_Xik[i][k], tmp,
                                            m_num_constraints[k]);

         for (r = 0; r < 6; r++)
         {
            for (unsigned int c = 0; c < m_num_constraints[k]; c++)
               m_Xik[prev][k][r][c] += tmp[r][c];

            free(tmp[r]);
         }
         free(tmp);
      }
   }

   for (j = 0; j < m_num_elements_LB[i]; j++)
   {
      unsigned int k = m_LB[i][j];

      for (unsigned int l = 0; l < m_num_elements_LB[i]; l++)
      {
         unsigned int n = m_LB[i][l];

         m_link_list[i]->link->BToInboard(m_Bmn[k][n],
                                          m_Xik[i][k], m_num_constraints[k],
                                          m_Xik[i][n], m_num_constraints[n]);
      }

      m_link_list[i]->link->xformZetak(m_zetak[k],
                                       m_Xik[i][k], m_num_constraints[k]);
   }
}
