/*****************************************************************************
 * DynaMechs: A Multibody Dynamic Simulation Library
 *
 * Copyright (C) 1994-2001  Scott McMillan   All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *****************************************************************************
 *     File: dmSecondaryRevoluteJoint.hpp
 *   Author: Duane Marhefka
 *  Created: 1999
 *  Summary: Class definitions for revolute secondary joints.
 *****************************************************************************/

#ifndef _DM_SECONDARY_REVOLUTE_JOINT_HPP
#define _DM_SECONDARY_REVOLUTE_JOINT_HPP

#include <dm.h>
#include <dmObject.hpp>
#include <dmSecondaryJoint.hpp>

//======================================================================

/** Documentation pending
 */


class DM_DLL_API dmSecondaryRevoluteJoint :  public dmSecondaryJoint
{
public:
   enum {NUM_DOFS = 1};

public:
   ///
   dmSecondaryRevoluteJoint();
   ///
   ~dmSecondaryRevoluteJoint() {};

   ///
   int getNumDOFs() const {return NUM_DOFS;}
   ///
   void initXik(Float **Xik, int link_index, int root_index) const;
   ///
   void getZeta(Float *zeta) const;

   ///
   inline void setJointInput(Float joint_input[])
      {
         m_joint_input = joint_input[0];
      }

   ///
   void getFreeState(Float q[], Float qd[]) const;
   ///
   void getConstrainedState(Float q[], Float qd[]) const;
   ///
   void computeState();
   ///
   void computeEtas();
   ///
   void computeAppliedForce();
   ///
   void applyPenaltyForce();
   ///
   void computeStabilizationForce(Float force[]);

   ///
   void setConstraintParams(Float linear_spring, Float linear_damper,
                            Float angular_spring, Float angular_damper);

private:   // not implemented
   dmSecondaryRevoluteJoint(const dmSecondaryRevoluteJoint &);
   dmSecondaryRevoluteJoint &operator=(const dmSecondaryRevoluteJoint &);

protected:
   Float m_pos_spring;
   Float m_pos_damper;
   Float m_euler_spring;
   Float m_euler_damper;

   CartesianVector m_euler;            // orientation sv's
   CartesianVector m_euler_dot;        // derivatives of orientation sv's
   Float m_c2, m_s2, m_c1, m_s1, m_t1; // trig. fctns. of the euler angles

   Float m_joint_input;
};

#endif
