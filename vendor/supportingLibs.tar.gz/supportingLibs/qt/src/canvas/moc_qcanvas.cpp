/****************************************************************************
** QCanvas meta object code from reading C++ file 'qcanvas.h'
**
** Created: Wed May 9 12:26:07 2001
**      by: The Qt MOC ($Id: moc_qcanvas.cpp,v 1.1.1.1 2001/11/20 12:08:16 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qcanvas.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QCanvas::className() const
{
    return "QCanvas";
}

QMetaObject *QCanvas::metaObj = 0;

void QCanvas::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QObject::className(), "QObject") != 0 )
	badSuperclassWarning("QCanvas","QObject");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QCanvas::tr(const char* s)
{
    return qApp->translate( "QCanvas", s, 0 );
}

QString QCanvas::tr(const char* s, const char * c)
{
    return qApp->translate( "QCanvas", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QCanvas::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QObject::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QCanvas::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QCanvas::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    m1_t0 v1_0 = &QCanvas::advance;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QCanvas::update;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    QMetaData *slot_tbl = QMetaObject::new_metadata(2);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(2);
    slot_tbl[0].name = "advance()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "update()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    typedef void (QCanvas::*m2_t0)();
    typedef void (QObject::*om2_t0)();
    m2_t0 v2_0 = &QCanvas::resized;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    QMetaData *signal_tbl = QMetaObject::new_metadata(1);
    signal_tbl[0].name = "resized()";
    signal_tbl[0].ptr = (QMember)ov2_0;
    metaObj = QMetaObject::new_metaobject(
	"QCanvas", "QObject",
	slot_tbl, 2,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL resized
void QCanvas::resized()
{
    activate_signal( "resized()" );
}


const char *QCanvasView::className() const
{
    return "QCanvasView";
}

QMetaObject *QCanvasView::metaObj = 0;

void QCanvasView::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QScrollView::className(), "QScrollView") != 0 )
	badSuperclassWarning("QCanvasView","QScrollView");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QCanvasView::tr(const char* s)
{
    return qApp->translate( "QCanvasView", s, 0 );
}

QString QCanvasView::tr(const char* s, const char * c)
{
    return qApp->translate( "QCanvasView", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QCanvasView::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QScrollView::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QCanvasView::*m1_t0)(int,int);
    typedef void (QObject::*om1_t0)(int,int);
    typedef void (QCanvasView::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    m1_t0 v1_0 = &QCanvasView::cMoving;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QCanvasView::updateContentsSize;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    QMetaData *slot_tbl = QMetaObject::new_metadata(2);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(2);
    slot_tbl[0].name = "cMoving(int,int)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Private;
    slot_tbl[1].name = "updateContentsSize()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Private;
    metaObj = QMetaObject::new_metaobject(
	"QCanvasView", "QScrollView",
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
