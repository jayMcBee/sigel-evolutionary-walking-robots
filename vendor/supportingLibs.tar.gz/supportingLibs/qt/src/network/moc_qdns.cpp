/****************************************************************************
** QDns meta object code from reading C++ file 'qdns.h'
**
** Created: Wed May 9 12:25:16 2001
**      by: The Qt MOC ($Id: moc_qdns.cpp,v 1.1.1.1 2001/11/20 12:08:21 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qdns.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QDns::className() const
{
    return "QDns";
}

QMetaObject *QDns::metaObj = 0;

void QDns::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QObject::className(), "QObject") != 0 )
	badSuperclassWarning("QDns","QObject");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QDns::tr(const char* s)
{
    return qApp->translate( "QDns", s, 0 );
}

QString QDns::tr(const char* s, const char * c)
{
    return qApp->translate( "QDns", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QDns::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QObject::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QDns::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    m1_t0 v1_0 = &QDns::startQuery;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    QMetaData *slot_tbl = QMetaObject::new_metadata(1);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(1);
    slot_tbl[0].name = "startQuery()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Private;
    typedef void (QDns::*m2_t0)();
    typedef void (QObject::*om2_t0)();
    m2_t0 v2_0 = &QDns::resultsReady;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    QMetaData *signal_tbl = QMetaObject::new_metadata(1);
    signal_tbl[0].name = "resultsReady()";
    signal_tbl[0].ptr = (QMember)ov2_0;
    metaObj = QMetaObject::new_metaobject(
	"QDns", "QObject",
	slot_tbl, 1,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL resultsReady
void QDns::resultsReady()
{
    activate_signal( "resultsReady()" );
}


const char *QDnsSocket::className() const
{
    return "QDnsSocket";
}

QMetaObject *QDnsSocket::metaObj = 0;

void QDnsSocket::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QObject::className(), "QObject") != 0 )
	badSuperclassWarning("QDnsSocket","QObject");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QDnsSocket::tr(const char* s)
{
    return qApp->translate( "QDnsSocket", s, 0 );
}

QString QDnsSocket::tr(const char* s, const char * c)
{
    return qApp->translate( "QDnsSocket", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QDnsSocket::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QObject::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QDnsSocket::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QDnsSocket::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    typedef void (QDnsSocket::*m1_t2)();
    typedef void (QObject::*om1_t2)();
    m1_t0 v1_0 = &QDnsSocket::cleanCache;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QDnsSocket::retransmit;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QDnsSocket::answer;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    QMetaData *slot_tbl = QMetaObject::new_metadata(3);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(3);
    slot_tbl[0].name = "cleanCache()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Private;
    slot_tbl[1].name = "retransmit()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Private;
    slot_tbl[2].name = "answer()";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Private;
    metaObj = QMetaObject::new_metaobject(
	"QDnsSocket", "QObject",
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
