/****************************************************************************
** QFtp meta object code from reading C++ file 'qftp.h'
**
** Created: Wed May 9 12:25:21 2001
**      by: The Qt MOC ($Id: moc_qftp.cpp,v 1.1.1.1 2001/11/20 12:08:21 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qftp.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QFtp::className() const
{
    return "QFtp";
}

QMetaObject *QFtp::metaObj = 0;

void QFtp::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QNetworkProtocol::className(), "QNetworkProtocol") != 0 )
	badSuperclassWarning("QFtp","QNetworkProtocol");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QFtp::tr(const char* s)
{
    return qApp->translate( "QFtp", s, 0 );
}

QString QFtp::tr(const char* s, const char * c)
{
    return qApp->translate( "QFtp", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QFtp::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QNetworkProtocol::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QFtp::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QFtp::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    typedef void (QFtp::*m1_t2)();
    typedef void (QObject::*om1_t2)();
    typedef void (QFtp::*m1_t3)();
    typedef void (QObject::*om1_t3)();
    typedef void (QFtp::*m1_t4)();
    typedef void (QObject::*om1_t4)();
    typedef void (QFtp::*m1_t5)();
    typedef void (QObject::*om1_t5)();
    typedef void (QFtp::*m1_t6)();
    typedef void (QObject::*om1_t6)();
    typedef void (QFtp::*m1_t7)();
    typedef void (QObject::*om1_t7)();
    typedef void (QFtp::*m1_t8)(int);
    typedef void (QObject::*om1_t8)(int);
    typedef void (QFtp::*m1_t9)(int);
    typedef void (QObject::*om1_t9)(int);
    m1_t0 v1_0 = &QFtp::hostFound;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QFtp::connected;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QFtp::closed;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QFtp::readyRead;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QFtp::dataHostFound;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QFtp::dataConnected;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QFtp::dataClosed;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QFtp::dataReadyRead;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    m1_t8 v1_8 = &QFtp::dataBytesWritten;
    om1_t8 ov1_8 = (om1_t8)v1_8;
    m1_t9 v1_9 = &QFtp::error;
    om1_t9 ov1_9 = (om1_t9)v1_9;
    QMetaData *slot_tbl = QMetaObject::new_metadata(10);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(10);
    slot_tbl[0].name = "hostFound()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Protected;
    slot_tbl[1].name = "connected()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Protected;
    slot_tbl[2].name = "closed()";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Protected;
    slot_tbl[3].name = "readyRead()";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Protected;
    slot_tbl[4].name = "dataHostFound()";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Protected;
    slot_tbl[5].name = "dataConnected()";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Protected;
    slot_tbl[6].name = "dataClosed()";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Protected;
    slot_tbl[7].name = "dataReadyRead()";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Protected;
    slot_tbl[8].name = "dataBytesWritten(int)";
    slot_tbl[8].ptr = (QMember)ov1_8;
    slot_tbl_access[8] = QMetaData::Protected;
    slot_tbl[9].name = "error(int)";
    slot_tbl[9].ptr = (QMember)ov1_9;
    slot_tbl_access[9] = QMetaData::Protected;
    metaObj = QMetaObject::new_metaobject(
	"QFtp", "QNetworkProtocol",
	slot_tbl, 10,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
