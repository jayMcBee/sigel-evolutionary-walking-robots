/****************************************************************************
** QSocket meta object code from reading C++ file 'qsocket.h'
**
** Created: Wed May 9 12:25:32 2001
**      by: The Qt MOC ($Id: moc_qsocket.cpp,v 1.1.1.1 2001/11/20 12:08:21 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qsocket.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QSocket::className() const
{
    return "QSocket";
}

QMetaObject *QSocket::metaObj = 0;

void QSocket::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QObject::className(), "QObject") != 0 )
	badSuperclassWarning("QSocket","QObject");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QSocket::tr(const char* s)
{
    return qApp->translate( "QSocket", s, 0 );
}

QString QSocket::tr(const char* s, const char * c)
{
    return qApp->translate( "QSocket", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QSocket::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QObject::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QSocket::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QSocket::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    typedef void (QSocket::*m1_t2)();
    typedef void (QObject::*om1_t2)();
    m1_t0 v1_0 = &QSocket::sn_read;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QSocket::sn_write;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QSocket::tryConnecting;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    QMetaData *slot_tbl = QMetaObject::new_metadata(3);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(3);
    slot_tbl[0].name = "sn_read()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Protected;
    slot_tbl[1].name = "sn_write()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Protected;
    slot_tbl[2].name = "tryConnecting()";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Private;
    typedef void (QSocket::*m2_t0)();
    typedef void (QObject::*om2_t0)();
    typedef void (QSocket::*m2_t1)();
    typedef void (QObject::*om2_t1)();
    typedef void (QSocket::*m2_t2)();
    typedef void (QObject::*om2_t2)();
    typedef void (QSocket::*m2_t3)();
    typedef void (QObject::*om2_t3)();
    typedef void (QSocket::*m2_t4)();
    typedef void (QObject::*om2_t4)();
    typedef void (QSocket::*m2_t5)(int);
    typedef void (QObject::*om2_t5)(int);
    typedef void (QSocket::*m2_t6)(int);
    typedef void (QObject::*om2_t6)(int);
    m2_t0 v2_0 = &QSocket::hostFound;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QSocket::connected;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    m2_t2 v2_2 = &QSocket::connectionClosed;
    om2_t2 ov2_2 = (om2_t2)v2_2;
    m2_t3 v2_3 = &QSocket::delayedCloseFinished;
    om2_t3 ov2_3 = (om2_t3)v2_3;
    m2_t4 v2_4 = &QSocket::readyRead;
    om2_t4 ov2_4 = (om2_t4)v2_4;
    m2_t5 v2_5 = &QSocket::bytesWritten;
    om2_t5 ov2_5 = (om2_t5)v2_5;
    m2_t6 v2_6 = &QSocket::error;
    om2_t6 ov2_6 = (om2_t6)v2_6;
    QMetaData *signal_tbl = QMetaObject::new_metadata(7);
    signal_tbl[0].name = "hostFound()";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "connected()";
    signal_tbl[1].ptr = (QMember)ov2_1;
    signal_tbl[2].name = "connectionClosed()";
    signal_tbl[2].ptr = (QMember)ov2_2;
    signal_tbl[3].name = "delayedCloseFinished()";
    signal_tbl[3].ptr = (QMember)ov2_3;
    signal_tbl[4].name = "readyRead()";
    signal_tbl[4].ptr = (QMember)ov2_4;
    signal_tbl[5].name = "bytesWritten(int)";
    signal_tbl[5].ptr = (QMember)ov2_5;
    signal_tbl[6].name = "error(int)";
    signal_tbl[6].ptr = (QMember)ov2_6;
    metaObj = QMetaObject::new_metaobject(
	"QSocket", "QObject",
	slot_tbl, 3,
	signal_tbl, 7,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL hostFound
void QSocket::hostFound()
{
    activate_signal( "hostFound()" );
}

// SIGNAL connected
void QSocket::connected()
{
    activate_signal( "connected()" );
}

// SIGNAL connectionClosed
void QSocket::connectionClosed()
{
    activate_signal( "connectionClosed()" );
}

// SIGNAL delayedCloseFinished
void QSocket::delayedCloseFinished()
{
    activate_signal( "delayedCloseFinished()" );
}

// SIGNAL readyRead
void QSocket::readyRead()
{
    activate_signal( "readyRead()" );
}

// SIGNAL bytesWritten
void QSocket::bytesWritten( int t0 )
{
    activate_signal( "bytesWritten(int)", t0 );
}

// SIGNAL error
void QSocket::error( int t0 )
{
    activate_signal( "error(int)", t0 );
}
