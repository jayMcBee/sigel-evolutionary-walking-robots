/****************************************************************************
** QServerSocket meta object code from reading C++ file 'qserversocket.h'
**
** Created: Wed May 9 12:25:27 2001
**      by: The Qt MOC ($Id: moc_qserversocket.cpp,v 1.1.1.1 2001/11/20 12:08:21 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qserversocket.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QServerSocket::className() const
{
    return "QServerSocket";
}

QMetaObject *QServerSocket::metaObj = 0;

void QServerSocket::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QObject::className(), "QObject") != 0 )
	badSuperclassWarning("QServerSocket","QObject");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QServerSocket::tr(const char* s)
{
    return qApp->translate( "QServerSocket", s, 0 );
}

QString QServerSocket::tr(const char* s, const char * c)
{
    return qApp->translate( "QServerSocket", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QServerSocket::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QObject::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QServerSocket::*m1_t0)(int);
    typedef void (QObject::*om1_t0)(int);
    m1_t0 v1_0 = &QServerSocket::incomingConnection;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    QMetaData *slot_tbl = QMetaObject::new_metadata(1);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(1);
    slot_tbl[0].name = "incomingConnection(int)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Private;
    metaObj = QMetaObject::new_metaobject(
	"QServerSocket", "QObject",
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
