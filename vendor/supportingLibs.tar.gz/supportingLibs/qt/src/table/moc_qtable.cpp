/****************************************************************************
** QTable meta object code from reading C++ file 'qtable.h'
**
** Created: Wed May 9 12:26:45 2001
**      by: The Qt MOC ($Id: moc_qtable.cpp,v 1.1.1.1 2001/11/20 12:08:22 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qtable.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QTable::className() const
{
    return "QTable";
}

QMetaObject *QTable::metaObj = 0;

void QTable::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QScrollView::className(), "QScrollView") != 0 )
	badSuperclassWarning("QTable","QScrollView");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QTable::tr(const char* s)
{
    return qApp->translate( "QTable", s, 0 );
}

QString QTable::tr(const char* s, const char * c)
{
    return qApp->translate( "QTable", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QTable::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QScrollView::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    typedef int (QTable::*m3_t0)()const;
    typedef int (QObject::*om3_t0)()const;
    typedef void (QTable::*m3_t1)(int);
    typedef void (QObject::*om3_t1)(int);
    typedef int (QTable::*m3_t3)()const;
    typedef int (QObject::*om3_t3)()const;
    typedef void (QTable::*m3_t4)(int);
    typedef void (QObject::*om3_t4)(int);
    typedef bool (QTable::*m3_t6)()const;
    typedef bool (QObject::*om3_t6)()const;
    typedef void (QTable::*m3_t7)(bool);
    typedef void (QObject::*om3_t7)(bool);
    typedef bool (QTable::*m3_t9)()const;
    typedef bool (QObject::*om3_t9)()const;
    typedef void (QTable::*m3_t10)(bool);
    typedef void (QObject::*om3_t10)(bool);
    typedef bool (QTable::*m3_t12)()const;
    typedef bool (QObject::*om3_t12)()const;
    typedef void (QTable::*m3_t13)(bool);
    typedef void (QObject::*om3_t13)(bool);
    m3_t0 v3_0 = &QTable::numRows;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t1 v3_1 = &QTable::setNumRows;
    om3_t1 ov3_1 = (om3_t1)v3_1;
    m3_t3 v3_3 = &QTable::numCols;
    om3_t3 ov3_3 = (om3_t3)v3_3;
    m3_t4 v3_4 = &QTable::setNumCols;
    om3_t4 ov3_4 = (om3_t4)v3_4;
    m3_t6 v3_6 = &QTable::showGrid;
    om3_t6 ov3_6 = (om3_t6)v3_6;
    m3_t7 v3_7 = &QTable::setShowGrid;
    om3_t7 ov3_7 = (om3_t7)v3_7;
    m3_t9 v3_9 = &QTable::rowMovingEnabled;
    om3_t9 ov3_9 = (om3_t9)v3_9;
    m3_t10 v3_10 = &QTable::setRowMovingEnabled;
    om3_t10 ov3_10 = (om3_t10)v3_10;
    m3_t12 v3_12 = &QTable::columnMovingEnabled;
    om3_t12 ov3_12 = (om3_t12)v3_12;
    m3_t13 v3_13 = &QTable::setColumnMovingEnabled;
    om3_t13 ov3_13 = (om3_t13)v3_13;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 5 );
    props_tbl[0].t = "int";
    props_tbl[0].n = "numRows";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = (QMember)ov3_1;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Class;
    props_tbl[0].setFlags(QMetaProperty::StdSet);
    props_tbl[1].t = "int";
    props_tbl[1].n = "numCols";
    props_tbl[1].get = (QMember)ov3_3;
    props_tbl[1].set = (QMember)ov3_4;
    props_tbl[1].reset = 0;
    props_tbl[1].gspec = QMetaProperty::Class;
    props_tbl[1].sspec = QMetaProperty::Class;
    props_tbl[1].setFlags(QMetaProperty::StdSet);
    props_tbl[2].t = "bool";
    props_tbl[2].n = "showGrid";
    props_tbl[2].get = (QMember)ov3_6;
    props_tbl[2].set = (QMember)ov3_7;
    props_tbl[2].reset = 0;
    props_tbl[2].gspec = QMetaProperty::Class;
    props_tbl[2].sspec = QMetaProperty::Class;
    props_tbl[2].setFlags(QMetaProperty::StdSet);
    props_tbl[3].t = "bool";
    props_tbl[3].n = "rowMovingEnabled";
    props_tbl[3].get = (QMember)ov3_9;
    props_tbl[3].set = (QMember)ov3_10;
    props_tbl[3].reset = 0;
    props_tbl[3].gspec = QMetaProperty::Class;
    props_tbl[3].sspec = QMetaProperty::Class;
    props_tbl[3].setFlags(QMetaProperty::StdSet);
    props_tbl[4].t = "bool";
    props_tbl[4].n = "columnMovingEnabled";
    props_tbl[4].get = (QMember)ov3_12;
    props_tbl[4].set = (QMember)ov3_13;
    props_tbl[4].reset = 0;
    props_tbl[4].gspec = QMetaProperty::Class;
    props_tbl[4].sspec = QMetaProperty::Class;
    props_tbl[4].setFlags(QMetaProperty::StdSet);
#endif // QT_NO_PROPERTIES
    typedef void (QTable::*m1_t0)(int);
    typedef void (QObject::*om1_t0)(int);
    typedef void (QTable::*m1_t1)(int);
    typedef void (QObject::*om1_t1)(int);
    typedef void (QTable::*m1_t2)(bool);
    typedef void (QObject::*om1_t2)(bool);
    typedef void (QTable::*m1_t3)(int);
    typedef void (QObject::*om1_t3)(int);
    typedef void (QTable::*m1_t4)(int);
    typedef void (QObject::*om1_t4)(int);
    typedef void (QTable::*m1_t5)(int);
    typedef void (QObject::*om1_t5)(int);
    typedef void (QTable::*m1_t6)(int);
    typedef void (QObject::*om1_t6)(int);
    typedef void (QTable::*m1_t7)(int,int);
    typedef void (QObject::*om1_t7)(int,int);
    typedef void (QTable::*m1_t8)(int,int);
    typedef void (QObject::*om1_t8)(int,int);
    typedef void (QTable::*m1_t9)(int);
    typedef void (QObject::*om1_t9)(int);
    typedef void (QTable::*m1_t10)(int);
    typedef void (QObject::*om1_t10)(int);
    typedef void (QTable::*m1_t11)(int,bool);
    typedef void (QObject::*om1_t11)(int,bool);
    typedef void (QTable::*m1_t12)(int,bool);
    typedef void (QObject::*om1_t12)(int,bool);
    typedef bool (QTable::*m1_t13)(int)const;
    typedef bool (QObject::*om1_t13)(int)const;
    typedef bool (QTable::*m1_t14)(int)const;
    typedef bool (QObject::*om1_t14)(int)const;
    typedef void (QTable::*m1_t15)(bool);
    typedef void (QObject::*om1_t15)(bool);
    typedef void (QTable::*m1_t16)(int,int);
    typedef void (QObject::*om1_t16)(int,int);
    typedef void (QTable::*m1_t17)(int,int);
    typedef void (QObject::*om1_t17)(int,int);
    typedef void (QTable::*m1_t18)(int,int,int,int);
    typedef void (QObject::*om1_t18)(int,int,int,int);
    typedef void (QTable::*m1_t19)(int);
    typedef void (QObject::*om1_t19)(int);
    typedef void (QTable::*m1_t20)(int);
    typedef void (QObject::*om1_t20)(int);
    typedef void (QTable::*m1_t21)(int,int);
    typedef void (QObject::*om1_t21)(int,int);
    typedef void (QTable::*m1_t22)(bool);
    typedef void (QObject::*om1_t22)(bool);
    typedef void (QTable::*m1_t23)(bool);
    typedef void (QObject::*om1_t23)(bool);
    typedef void (QTable::*m1_t24)(bool);
    typedef void (QObject::*om1_t24)(bool);
    typedef void (QTable::*m1_t25)(int);
    typedef void (QObject::*om1_t25)(int);
    typedef void (QTable::*m1_t26)(int);
    typedef void (QObject::*om1_t26)(int);
    typedef void (QTable::*m1_t27)(int,int,int);
    typedef void (QObject::*om1_t27)(int,int,int);
    typedef void (QTable::*m1_t28)(int,int,int);
    typedef void (QObject::*om1_t28)(int,int,int);
    typedef void (QTable::*m1_t29)(int);
    typedef void (QObject::*om1_t29)(int);
    typedef void (QTable::*m1_t30)();
    typedef void (QObject::*om1_t30)();
    m1_t0 v1_0 = &QTable::setNumRows;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QTable::setNumCols;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QTable::setShowGrid;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QTable::hideRow;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QTable::hideColumn;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QTable::showRow;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QTable::showColumn;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QTable::setColumnWidth;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    m1_t8 v1_8 = &QTable::setRowHeight;
    om1_t8 ov1_8 = (om1_t8)v1_8;
    m1_t9 v1_9 = &QTable::adjustColumn;
    om1_t9 ov1_9 = (om1_t9)v1_9;
    m1_t10 v1_10 = &QTable::adjustRow;
    om1_t10 ov1_10 = (om1_t10)v1_10;
    m1_t11 v1_11 = &QTable::setColumnStretchable;
    om1_t11 ov1_11 = (om1_t11)v1_11;
    m1_t12 v1_12 = &QTable::setRowStretchable;
    om1_t12 ov1_12 = (om1_t12)v1_12;
    m1_t13 v1_13 = &QTable::isColumnStretchable;
    om1_t13 ov1_13 = (om1_t13)v1_13;
    m1_t14 v1_14 = &QTable::isRowStretchable;
    om1_t14 ov1_14 = (om1_t14)v1_14;
    m1_t15 v1_15 = &QTable::setSorting;
    om1_t15 ov1_15 = (om1_t15)v1_15;
    m1_t16 v1_16 = &QTable::swapRows;
    om1_t16 ov1_16 = (om1_t16)v1_16;
    m1_t17 v1_17 = &QTable::swapColumns;
    om1_t17 ov1_17 = (om1_t17)v1_17;
    m1_t18 v1_18 = &QTable::swapCells;
    om1_t18 ov1_18 = (om1_t18)v1_18;
    m1_t19 v1_19 = &QTable::setLeftMargin;
    om1_t19 ov1_19 = (om1_t19)v1_19;
    m1_t20 v1_20 = &QTable::setTopMargin;
    om1_t20 ov1_20 = (om1_t20)v1_20;
    m1_t21 v1_21 = &QTable::setCurrentCell;
    om1_t21 ov1_21 = (om1_t21)v1_21;
    m1_t22 v1_22 = &QTable::clearSelection;
    om1_t22 ov1_22 = (om1_t22)v1_22;
    m1_t23 v1_23 = &QTable::setColumnMovingEnabled;
    om1_t23 ov1_23 = (om1_t23)v1_23;
    m1_t24 v1_24 = &QTable::setRowMovingEnabled;
    om1_t24 ov1_24 = (om1_t24)v1_24;
    m1_t25 v1_25 = &QTable::columnWidthChanged;
    om1_t25 ov1_25 = (om1_t25)v1_25;
    m1_t26 v1_26 = &QTable::rowHeightChanged;
    om1_t26 ov1_26 = (om1_t26)v1_26;
    m1_t27 v1_27 = &QTable::columnIndexChanged;
    om1_t27 ov1_27 = (om1_t27)v1_27;
    m1_t28 v1_28 = &QTable::rowIndexChanged;
    om1_t28 ov1_28 = (om1_t28)v1_28;
    m1_t29 v1_29 = &QTable::columnClicked;
    om1_t29 ov1_29 = (om1_t29)v1_29;
    m1_t30 v1_30 = &QTable::doAutoScroll;
    om1_t30 ov1_30 = (om1_t30)v1_30;
    QMetaData *slot_tbl = QMetaObject::new_metadata(31);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(31);
    slot_tbl[0].name = "setNumRows(int)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "setNumCols(int)";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "setShowGrid(bool)";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "hideRow(int)";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "hideColumn(int)";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "showRow(int)";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "showColumn(int)";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "setColumnWidth(int,int)";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Public;
    slot_tbl[8].name = "setRowHeight(int,int)";
    slot_tbl[8].ptr = (QMember)ov1_8;
    slot_tbl_access[8] = QMetaData::Public;
    slot_tbl[9].name = "adjustColumn(int)";
    slot_tbl[9].ptr = (QMember)ov1_9;
    slot_tbl_access[9] = QMetaData::Public;
    slot_tbl[10].name = "adjustRow(int)";
    slot_tbl[10].ptr = (QMember)ov1_10;
    slot_tbl_access[10] = QMetaData::Public;
    slot_tbl[11].name = "setColumnStretchable(int,bool)";
    slot_tbl[11].ptr = (QMember)ov1_11;
    slot_tbl_access[11] = QMetaData::Public;
    slot_tbl[12].name = "setRowStretchable(int,bool)";
    slot_tbl[12].ptr = (QMember)ov1_12;
    slot_tbl_access[12] = QMetaData::Public;
    slot_tbl[13].name = "isColumnStretchable(int)";
    slot_tbl[13].ptr = (QMember)ov1_13;
    slot_tbl_access[13] = QMetaData::Public;
    slot_tbl[14].name = "isRowStretchable(int)";
    slot_tbl[14].ptr = (QMember)ov1_14;
    slot_tbl_access[14] = QMetaData::Public;
    slot_tbl[15].name = "setSorting(bool)";
    slot_tbl[15].ptr = (QMember)ov1_15;
    slot_tbl_access[15] = QMetaData::Public;
    slot_tbl[16].name = "swapRows(int,int)";
    slot_tbl[16].ptr = (QMember)ov1_16;
    slot_tbl_access[16] = QMetaData::Public;
    slot_tbl[17].name = "swapColumns(int,int)";
    slot_tbl[17].ptr = (QMember)ov1_17;
    slot_tbl_access[17] = QMetaData::Public;
    slot_tbl[18].name = "swapCells(int,int,int,int)";
    slot_tbl[18].ptr = (QMember)ov1_18;
    slot_tbl_access[18] = QMetaData::Public;
    slot_tbl[19].name = "setLeftMargin(int)";
    slot_tbl[19].ptr = (QMember)ov1_19;
    slot_tbl_access[19] = QMetaData::Public;
    slot_tbl[20].name = "setTopMargin(int)";
    slot_tbl[20].ptr = (QMember)ov1_20;
    slot_tbl_access[20] = QMetaData::Public;
    slot_tbl[21].name = "setCurrentCell(int,int)";
    slot_tbl[21].ptr = (QMember)ov1_21;
    slot_tbl_access[21] = QMetaData::Public;
    slot_tbl[22].name = "clearSelection(bool)";
    slot_tbl[22].ptr = (QMember)ov1_22;
    slot_tbl_access[22] = QMetaData::Public;
    slot_tbl[23].name = "setColumnMovingEnabled(bool)";
    slot_tbl[23].ptr = (QMember)ov1_23;
    slot_tbl_access[23] = QMetaData::Public;
    slot_tbl[24].name = "setRowMovingEnabled(bool)";
    slot_tbl[24].ptr = (QMember)ov1_24;
    slot_tbl_access[24] = QMetaData::Public;
    slot_tbl[25].name = "columnWidthChanged(int)";
    slot_tbl[25].ptr = (QMember)ov1_25;
    slot_tbl_access[25] = QMetaData::Protected;
    slot_tbl[26].name = "rowHeightChanged(int)";
    slot_tbl[26].ptr = (QMember)ov1_26;
    slot_tbl_access[26] = QMetaData::Protected;
    slot_tbl[27].name = "columnIndexChanged(int,int,int)";
    slot_tbl[27].ptr = (QMember)ov1_27;
    slot_tbl_access[27] = QMetaData::Protected;
    slot_tbl[28].name = "rowIndexChanged(int,int,int)";
    slot_tbl[28].ptr = (QMember)ov1_28;
    slot_tbl_access[28] = QMetaData::Protected;
    slot_tbl[29].name = "columnClicked(int)";
    slot_tbl[29].ptr = (QMember)ov1_29;
    slot_tbl_access[29] = QMetaData::Protected;
    slot_tbl[30].name = "doAutoScroll()";
    slot_tbl[30].ptr = (QMember)ov1_30;
    slot_tbl_access[30] = QMetaData::Private;
    typedef void (QTable::*m2_t0)(int,int);
    typedef void (QObject::*om2_t0)(int,int);
    typedef void (QTable::*m2_t1)(int,int,int,const QPoint&);
    typedef void (QObject::*om2_t1)(int,int,int,const QPoint&);
    typedef void (QTable::*m2_t2)(int,int,int,const QPoint&);
    typedef void (QObject::*om2_t2)(int,int,int,const QPoint&);
    typedef void (QTable::*m2_t3)(int,int,int,const QPoint&);
    typedef void (QObject::*om2_t3)(int,int,int,const QPoint&);
    typedef void (QTable::*m2_t4)();
    typedef void (QObject::*om2_t4)();
    typedef void (QTable::*m2_t5)(int,int);
    typedef void (QObject::*om2_t5)(int,int);
    m2_t0 v2_0 = &QTable::currentChanged;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QTable::clicked;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    m2_t2 v2_2 = &QTable::doubleClicked;
    om2_t2 ov2_2 = (om2_t2)v2_2;
    m2_t3 v2_3 = &QTable::pressed;
    om2_t3 ov2_3 = (om2_t3)v2_3;
    m2_t4 v2_4 = &QTable::selectionChanged;
    om2_t4 ov2_4 = (om2_t4)v2_4;
    m2_t5 v2_5 = &QTable::valueChanged;
    om2_t5 ov2_5 = (om2_t5)v2_5;
    QMetaData *signal_tbl = QMetaObject::new_metadata(6);
    signal_tbl[0].name = "currentChanged(int,int)";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "clicked(int,int,int,const QPoint&)";
    signal_tbl[1].ptr = (QMember)ov2_1;
    signal_tbl[2].name = "doubleClicked(int,int,int,const QPoint&)";
    signal_tbl[2].ptr = (QMember)ov2_2;
    signal_tbl[3].name = "pressed(int,int,int,const QPoint&)";
    signal_tbl[3].ptr = (QMember)ov2_3;
    signal_tbl[4].name = "selectionChanged()";
    signal_tbl[4].ptr = (QMember)ov2_4;
    signal_tbl[5].name = "valueChanged(int,int)";
    signal_tbl[5].ptr = (QMember)ov2_5;
    metaObj = QMetaObject::new_metaobject(
	"QTable", "QScrollView",
	slot_tbl, 31,
	signal_tbl, 6,
#ifndef QT_NO_PROPERTIES
	props_tbl, 5,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL currentChanged
void QTable::currentChanged( int t0, int t1 )
{
    // No builtin function for signal parameter type int,int
    QConnectionList *clist = receivers("currentChanged(int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(int);
    typedef void (QObject::*RT2)(int,int);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL clicked
void QTable::clicked( int t0, int t1, int t2, const QPoint& t3 )
{
    // No builtin function for signal parameter type int,int,int,const QPoint&
    QConnectionList *clist = receivers("clicked(int,int,int,const QPoint&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(int);
    typedef void (QObject::*RT2)(int,int);
    typedef void (QObject::*RT3)(int,int,int);
    typedef void (QObject::*RT4)(int,int,int,const QPoint&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    RT4 r4;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	    case 3:
#ifdef Q_FP_CCAST_BROKEN
		r3 = reinterpret_cast<RT3>(*(c->member()));
#else
		r3 = (RT3)*(c->member());
#endif
		(object->*r3)(t0, t1, t2);
		break;
	    case 4:
#ifdef Q_FP_CCAST_BROKEN
		r4 = reinterpret_cast<RT4>(*(c->member()));
#else
		r4 = (RT4)*(c->member());
#endif
		(object->*r4)(t0, t1, t2, t3);
		break;
	}
    }
}

// SIGNAL doubleClicked
void QTable::doubleClicked( int t0, int t1, int t2, const QPoint& t3 )
{
    // No builtin function for signal parameter type int,int,int,const QPoint&
    QConnectionList *clist = receivers("doubleClicked(int,int,int,const QPoint&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(int);
    typedef void (QObject::*RT2)(int,int);
    typedef void (QObject::*RT3)(int,int,int);
    typedef void (QObject::*RT4)(int,int,int,const QPoint&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    RT4 r4;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	    case 3:
#ifdef Q_FP_CCAST_BROKEN
		r3 = reinterpret_cast<RT3>(*(c->member()));
#else
		r3 = (RT3)*(c->member());
#endif
		(object->*r3)(t0, t1, t2);
		break;
	    case 4:
#ifdef Q_FP_CCAST_BROKEN
		r4 = reinterpret_cast<RT4>(*(c->member()));
#else
		r4 = (RT4)*(c->member());
#endif
		(object->*r4)(t0, t1, t2, t3);
		break;
	}
    }
}

// SIGNAL pressed
void QTable::pressed( int t0, int t1, int t2, const QPoint& t3 )
{
    // No builtin function for signal parameter type int,int,int,const QPoint&
    QConnectionList *clist = receivers("pressed(int,int,int,const QPoint&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(int);
    typedef void (QObject::*RT2)(int,int);
    typedef void (QObject::*RT3)(int,int,int);
    typedef void (QObject::*RT4)(int,int,int,const QPoint&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    RT4 r4;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	    case 3:
#ifdef Q_FP_CCAST_BROKEN
		r3 = reinterpret_cast<RT3>(*(c->member()));
#else
		r3 = (RT3)*(c->member());
#endif
		(object->*r3)(t0, t1, t2);
		break;
	    case 4:
#ifdef Q_FP_CCAST_BROKEN
		r4 = reinterpret_cast<RT4>(*(c->member()));
#else
		r4 = (RT4)*(c->member());
#endif
		(object->*r4)(t0, t1, t2, t3);
		break;
	}
    }
}

// SIGNAL selectionChanged
void QTable::selectionChanged()
{
    activate_signal( "selectionChanged()" );
}

// SIGNAL valueChanged
void QTable::valueChanged( int t0, int t1 )
{
    // No builtin function for signal parameter type int,int
    QConnectionList *clist = receivers("valueChanged(int,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(int);
    typedef void (QObject::*RT2)(int,int);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	}
    }
}


const char *QTableHeader::className() const
{
    return "QTableHeader";
}

QMetaObject *QTableHeader::metaObj = 0;

void QTableHeader::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QHeader::className(), "QHeader") != 0 )
	badSuperclassWarning("QTableHeader","QHeader");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QTableHeader::tr(const char* s)
{
    return qApp->translate( "QTableHeader", s, 0 );
}

QString QTableHeader::tr(const char* s, const char * c)
{
    return qApp->translate( "QTableHeader", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QTableHeader::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QHeader::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QTableHeader::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QTableHeader::*m1_t1)(int,int,int);
    typedef void (QObject::*om1_t1)(int,int,int);
    typedef void (QTableHeader::*m1_t2)(int,int,int);
    typedef void (QObject::*om1_t2)(int,int,int);
    typedef void (QTableHeader::*m1_t3)();
    typedef void (QObject::*om1_t3)();
    typedef void (QTableHeader::*m1_t4)();
    typedef void (QObject::*om1_t4)();
    m1_t0 v1_0 = &QTableHeader::doAutoScroll;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QTableHeader::sectionWidthChanged;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QTableHeader::indexChanged;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QTableHeader::updateStretches;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QTableHeader::updateWidgetStretches;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    QMetaData *slot_tbl = QMetaObject::new_metadata(5);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(5);
    slot_tbl[0].name = "doAutoScroll()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Private;
    slot_tbl[1].name = "sectionWidthChanged(int,int,int)";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Private;
    slot_tbl[2].name = "indexChanged(int,int,int)";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Private;
    slot_tbl[3].name = "updateStretches()";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Private;
    slot_tbl[4].name = "updateWidgetStretches()";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Private;
    typedef void (QTableHeader::*m2_t0)(int);
    typedef void (QObject::*om2_t0)(int);
    m2_t0 v2_0 = &QTableHeader::sectionSizeChanged;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    QMetaData *signal_tbl = QMetaObject::new_metadata(1);
    signal_tbl[0].name = "sectionSizeChanged(int)";
    signal_tbl[0].ptr = (QMember)ov2_0;
    metaObj = QMetaObject::new_metaobject(
	"QTableHeader", "QHeader",
	slot_tbl, 5,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL sectionSizeChanged
void QTableHeader::sectionSizeChanged( int t0 )
{
    activate_signal( "sectionSizeChanged(int)", t0 );
}
