/****************************************************************************
** QPrintDialog meta object code from reading C++ file 'qprintdialog.h'
**
** Created: Wed May 9 12:22:06 2001
**      by: The Qt MOC ($Id: moc_qprintdialog.cpp,v 1.1.1.1 2001/11/20 12:08:17 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qprintdialog.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QPrintDialog::className() const
{
    return "QPrintDialog";
}

QMetaObject *QPrintDialog::metaObj = 0;

void QPrintDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("QPrintDialog","QDialog");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QPrintDialog::tr(const char* s)
{
    return qApp->translate( "QPrintDialog", s, 0 );
}

QString QPrintDialog::tr(const char* s, const char * c)
{
    return qApp->translate( "QPrintDialog", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QPrintDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QDialog::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QPrintDialog::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QPrintDialog::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    typedef void (QPrintDialog::*m1_t2)(int);
    typedef void (QObject::*om1_t2)(int);
    typedef void (QPrintDialog::*m1_t3)(int);
    typedef void (QObject::*om1_t3)(int);
    typedef void (QPrintDialog::*m1_t4)(int);
    typedef void (QObject::*om1_t4)(int);
    typedef void (QPrintDialog::*m1_t5)(int);
    typedef void (QObject::*om1_t5)(int);
    typedef void (QPrintDialog::*m1_t6)(int);
    typedef void (QObject::*om1_t6)(int);
    typedef void (QPrintDialog::*m1_t7)(int);
    typedef void (QObject::*om1_t7)(int);
    typedef void (QPrintDialog::*m1_t8)(int);
    typedef void (QObject::*om1_t8)(int);
    typedef void (QPrintDialog::*m1_t9)(int);
    typedef void (QObject::*om1_t9)(int);
    typedef void (QPrintDialog::*m1_t10)(int);
    typedef void (QObject::*om1_t10)(int);
    typedef void (QPrintDialog::*m1_t11)(int);
    typedef void (QObject::*om1_t11)(int);
    typedef void (QPrintDialog::*m1_t12)(const QString&);
    typedef void (QObject::*om1_t12)(const QString&);
    m1_t0 v1_0 = &QPrintDialog::browseClicked;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QPrintDialog::okClicked;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QPrintDialog::printerOrFileSelected;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QPrintDialog::landscapeSelected;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QPrintDialog::paperSizeSelected;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QPrintDialog::orientSelected;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QPrintDialog::pageOrderSelected;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QPrintDialog::colorModeSelected;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    m1_t8 v1_8 = &QPrintDialog::setNumCopies;
    om1_t8 ov1_8 = (om1_t8)v1_8;
    m1_t9 v1_9 = &QPrintDialog::printRangeSelected;
    om1_t9 ov1_9 = (om1_t9)v1_9;
    m1_t10 v1_10 = &QPrintDialog::setFirstPage;
    om1_t10 ov1_10 = (om1_t10)v1_10;
    m1_t11 v1_11 = &QPrintDialog::setLastPage;
    om1_t11 ov1_11 = (om1_t11)v1_11;
    m1_t12 v1_12 = &QPrintDialog::fileNameEditChanged;
    om1_t12 ov1_12 = (om1_t12)v1_12;
    QMetaData *slot_tbl = QMetaObject::new_metadata(13);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(13);
    slot_tbl[0].name = "browseClicked()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Private;
    slot_tbl[1].name = "okClicked()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Private;
    slot_tbl[2].name = "printerOrFileSelected(int)";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Private;
    slot_tbl[3].name = "landscapeSelected(int)";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Private;
    slot_tbl[4].name = "paperSizeSelected(int)";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Private;
    slot_tbl[5].name = "orientSelected(int)";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Private;
    slot_tbl[6].name = "pageOrderSelected(int)";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Private;
    slot_tbl[7].name = "colorModeSelected(int)";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Private;
    slot_tbl[8].name = "setNumCopies(int)";
    slot_tbl[8].ptr = (QMember)ov1_8;
    slot_tbl_access[8] = QMetaData::Private;
    slot_tbl[9].name = "printRangeSelected(int)";
    slot_tbl[9].ptr = (QMember)ov1_9;
    slot_tbl_access[9] = QMetaData::Private;
    slot_tbl[10].name = "setFirstPage(int)";
    slot_tbl[10].ptr = (QMember)ov1_10;
    slot_tbl_access[10] = QMetaData::Private;
    slot_tbl[11].name = "setLastPage(int)";
    slot_tbl[11].ptr = (QMember)ov1_11;
    slot_tbl_access[11] = QMetaData::Private;
    slot_tbl[12].name = "fileNameEditChanged(const QString&)";
    slot_tbl[12].ptr = (QMember)ov1_12;
    slot_tbl_access[12] = QMetaData::Private;
    metaObj = QMetaObject::new_metaobject(
	"QPrintDialog", "QDialog",
	slot_tbl, 13,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
