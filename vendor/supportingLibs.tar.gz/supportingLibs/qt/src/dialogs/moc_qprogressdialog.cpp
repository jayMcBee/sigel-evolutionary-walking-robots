/****************************************************************************
** QProgressDialog meta object code from reading C++ file 'qprogressdialog.h'
**
** Created: Wed May 9 12:21:39 2001
**      by: The Qt MOC ($Id: moc_qprogressdialog.cpp,v 1.1.1.1 2001/11/20 12:08:17 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qprogressdialog.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QProgressDialog::className() const
{
    return "QProgressDialog";
}

QMetaObject *QProgressDialog::metaObj = 0;

void QProgressDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QSemiModal::className(), "QSemiModal") != 0 )
	badSuperclassWarning("QProgressDialog","QSemiModal");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QProgressDialog::tr(const char* s)
{
    return qApp->translate( "QProgressDialog", s, 0 );
}

QString QProgressDialog::tr(const char* s, const char * c)
{
    return qApp->translate( "QProgressDialog", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QProgressDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QSemiModal::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    typedef bool (QProgressDialog::*m3_t0)()const;
    typedef bool (QObject::*om3_t0)()const;
    typedef int (QProgressDialog::*m3_t3)()const;
    typedef int (QObject::*om3_t3)()const;
    typedef void (QProgressDialog::*m3_t4)(int);
    typedef void (QObject::*om3_t4)(int);
    typedef int (QProgressDialog::*m3_t6)()const;
    typedef int (QObject::*om3_t6)()const;
    typedef void (QProgressDialog::*m3_t7)(int);
    typedef void (QObject::*om3_t7)(int);
    typedef bool (QProgressDialog::*m3_t9)()const;
    typedef bool (QObject::*om3_t9)()const;
    typedef void (QProgressDialog::*m3_t10)(bool);
    typedef void (QObject::*om3_t10)(bool);
    typedef bool (QProgressDialog::*m3_t12)()const;
    typedef bool (QObject::*om3_t12)()const;
    typedef void (QProgressDialog::*m3_t13)(bool);
    typedef void (QObject::*om3_t13)(bool);
    typedef QString (QProgressDialog::*m3_t15)()const;
    typedef QString (QObject::*om3_t15)()const;
    typedef void (QProgressDialog::*m3_t16)(const QString&);
    typedef void (QObject::*om3_t16)(const QString&);
    m3_t0 v3_0 = &QProgressDialog::wasCancelled;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t3 v3_3 = &QProgressDialog::totalSteps;
    om3_t3 ov3_3 = (om3_t3)v3_3;
    m3_t4 v3_4 = &QProgressDialog::setTotalSteps;
    om3_t4 ov3_4 = (om3_t4)v3_4;
    m3_t6 v3_6 = &QProgressDialog::progress;
    om3_t6 ov3_6 = (om3_t6)v3_6;
    m3_t7 v3_7 = &QProgressDialog::setProgress;
    om3_t7 ov3_7 = (om3_t7)v3_7;
    m3_t9 v3_9 = &QProgressDialog::autoReset;
    om3_t9 ov3_9 = (om3_t9)v3_9;
    m3_t10 v3_10 = &QProgressDialog::setAutoReset;
    om3_t10 ov3_10 = (om3_t10)v3_10;
    m3_t12 v3_12 = &QProgressDialog::autoClose;
    om3_t12 ov3_12 = (om3_t12)v3_12;
    m3_t13 v3_13 = &QProgressDialog::setAutoClose;
    om3_t13 ov3_13 = (om3_t13)v3_13;
    m3_t15 v3_15 = &QProgressDialog::labelText;
    om3_t15 ov3_15 = (om3_t15)v3_15;
    m3_t16 v3_16 = &QProgressDialog::setLabelText;
    om3_t16 ov3_16 = (om3_t16)v3_16;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 6 );
    props_tbl[0].t = "bool";
    props_tbl[0].n = "wasCancelled";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = 0;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Unspecified;
    props_tbl[1].t = "int";
    props_tbl[1].n = "totalSteps";
    props_tbl[1].get = (QMember)ov3_3;
    props_tbl[1].set = (QMember)ov3_4;
    props_tbl[1].reset = 0;
    props_tbl[1].gspec = QMetaProperty::Class;
    props_tbl[1].sspec = QMetaProperty::Class;
    props_tbl[1].setFlags(QMetaProperty::StdSet);
    props_tbl[2].t = "int";
    props_tbl[2].n = "progress";
    props_tbl[2].get = (QMember)ov3_6;
    props_tbl[2].set = (QMember)ov3_7;
    props_tbl[2].reset = 0;
    props_tbl[2].gspec = QMetaProperty::Class;
    props_tbl[2].sspec = QMetaProperty::Class;
    props_tbl[2].setFlags(QMetaProperty::StdSet);
    props_tbl[3].t = "bool";
    props_tbl[3].n = "autoReset";
    props_tbl[3].get = (QMember)ov3_9;
    props_tbl[3].set = (QMember)ov3_10;
    props_tbl[3].reset = 0;
    props_tbl[3].gspec = QMetaProperty::Class;
    props_tbl[3].sspec = QMetaProperty::Class;
    props_tbl[3].setFlags(QMetaProperty::StdSet);
    props_tbl[4].t = "bool";
    props_tbl[4].n = "autoClose";
    props_tbl[4].get = (QMember)ov3_12;
    props_tbl[4].set = (QMember)ov3_13;
    props_tbl[4].reset = 0;
    props_tbl[4].gspec = QMetaProperty::Class;
    props_tbl[4].sspec = QMetaProperty::Class;
    props_tbl[4].setFlags(QMetaProperty::StdSet);
    props_tbl[5].t = "QString";
    props_tbl[5].n = "labelText";
    props_tbl[5].get = (QMember)ov3_15;
    props_tbl[5].set = (QMember)ov3_16;
    props_tbl[5].reset = 0;
    props_tbl[5].gspec = QMetaProperty::Class;
    props_tbl[5].sspec = QMetaProperty::Reference;
    props_tbl[5].setFlags(QMetaProperty::StdSet);
#endif // QT_NO_PROPERTIES
    typedef void (QProgressDialog::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QProgressDialog::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    typedef void (QProgressDialog::*m1_t2)(int);
    typedef void (QObject::*om1_t2)(int);
    typedef void (QProgressDialog::*m1_t3)(int);
    typedef void (QObject::*om1_t3)(int);
    typedef void (QProgressDialog::*m1_t4)(const QString&);
    typedef void (QObject::*om1_t4)(const QString&);
    typedef void (QProgressDialog::*m1_t5)(const QString&);
    typedef void (QObject::*om1_t5)(const QString&);
    typedef void (QProgressDialog::*m1_t6)(int);
    typedef void (QObject::*om1_t6)(int);
    typedef void (QProgressDialog::*m1_t7)();
    typedef void (QObject::*om1_t7)();
    m1_t0 v1_0 = &QProgressDialog::cancel;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QProgressDialog::reset;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QProgressDialog::setTotalSteps;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QProgressDialog::setProgress;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QProgressDialog::setLabelText;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QProgressDialog::setCancelButtonText;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QProgressDialog::setMinimumDuration;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QProgressDialog::forceShow;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    QMetaData *slot_tbl = QMetaObject::new_metadata(8);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(8);
    slot_tbl[0].name = "cancel()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "reset()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "setTotalSteps(int)";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "setProgress(int)";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "setLabelText(const QString&)";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "setCancelButtonText(const QString&)";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "setMinimumDuration(int)";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "forceShow()";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Protected;
    typedef void (QProgressDialog::*m2_t0)();
    typedef void (QObject::*om2_t0)();
    m2_t0 v2_0 = &QProgressDialog::cancelled;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    QMetaData *signal_tbl = QMetaObject::new_metadata(1);
    signal_tbl[0].name = "cancelled()";
    signal_tbl[0].ptr = (QMember)ov2_0;
    metaObj = QMetaObject::new_metaobject(
	"QProgressDialog", "QSemiModal",
	slot_tbl, 8,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	props_tbl, 6,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL cancelled
void QProgressDialog::cancelled()
{
    activate_signal( "cancelled()" );
}
