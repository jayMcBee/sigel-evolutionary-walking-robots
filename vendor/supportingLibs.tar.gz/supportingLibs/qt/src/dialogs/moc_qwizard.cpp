/****************************************************************************
** QWizard meta object code from reading C++ file 'qwizard.h'
**
** Created: Wed May 9 12:21:54 2001
**      by: The Qt MOC ($Id: moc_qwizard.cpp,v 1.1.1.1 2001/11/20 12:08:17 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qwizard.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QWizard::className() const
{
    return "QWizard";
}

QMetaObject *QWizard::metaObj = 0;

void QWizard::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("QWizard","QDialog");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QWizard::tr(const char* s)
{
    return qApp->translate( "QWizard", s, 0 );
}

QString QWizard::tr(const char* s, const char * c)
{
    return qApp->translate( "QWizard", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QWizard::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QDialog::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QWizard::*m1_t0)(QWidget*,bool);
    typedef void (QObject::*om1_t0)(QWidget*,bool);
    typedef void (QWizard::*m1_t1)(QWidget*,bool);
    typedef void (QObject::*om1_t1)(QWidget*,bool);
    typedef void (QWizard::*m1_t2)(QWidget*,bool);
    typedef void (QObject::*om1_t2)(QWidget*,bool);
    typedef void (QWizard::*m1_t3)(QWidget*,bool);
    typedef void (QObject::*om1_t3)(QWidget*,bool);
    typedef void (QWizard::*m1_t4)(QWidget*,bool);
    typedef void (QObject::*om1_t4)(QWidget*,bool);
    typedef void (QWizard::*m1_t5)();
    typedef void (QObject::*om1_t5)();
    typedef void (QWizard::*m1_t6)();
    typedef void (QObject::*om1_t6)();
    typedef void (QWizard::*m1_t7)();
    typedef void (QObject::*om1_t7)();
    m1_t0 v1_0 = &QWizard::setBackEnabled;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QWizard::setNextEnabled;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QWizard::setFinishEnabled;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QWizard::setHelpEnabled;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QWizard::setFinish;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QWizard::back;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QWizard::next;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QWizard::help;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    QMetaData *slot_tbl = QMetaObject::new_metadata(8);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(8);
    slot_tbl[0].name = "setBackEnabled(QWidget*,bool)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "setNextEnabled(QWidget*,bool)";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "setFinishEnabled(QWidget*,bool)";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "setHelpEnabled(QWidget*,bool)";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "setFinish(QWidget*,bool)";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "back()";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Protected;
    slot_tbl[6].name = "next()";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Protected;
    slot_tbl[7].name = "help()";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Protected;
    typedef void (QWizard::*m2_t0)();
    typedef void (QObject::*om2_t0)();
    typedef void (QWizard::*m2_t1)(const QString&);
    typedef void (QObject::*om2_t1)(const QString&);
    m2_t0 v2_0 = &QWizard::helpClicked;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QWizard::selected;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    QMetaData *signal_tbl = QMetaObject::new_metadata(2);
    signal_tbl[0].name = "helpClicked()";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "selected(const QString&)";
    signal_tbl[1].ptr = (QMember)ov2_1;
    metaObj = QMetaObject::new_metaobject(
	"QWizard", "QDialog",
	slot_tbl, 8,
	signal_tbl, 2,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL helpClicked
void QWizard::helpClicked()
{
    activate_signal( "helpClicked()" );
}

// SIGNAL selected
void QWizard::selected( const QString& t0 )
{
    activate_signal_strref( "selected(const QString&)", t0 );
}
