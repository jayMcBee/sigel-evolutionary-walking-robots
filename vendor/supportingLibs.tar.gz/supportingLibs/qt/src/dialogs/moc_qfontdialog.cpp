/****************************************************************************
** QFontDialog meta object code from reading C++ file 'qfontdialog.h'
**
** Created: Wed May 9 12:21:25 2001
**      by: The Qt MOC ($Id: moc_qfontdialog.cpp,v 1.1.1.1 2001/11/20 12:08:17 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qfontdialog.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QFontDialog::className() const
{
    return "QFontDialog";
}

QMetaObject *QFontDialog::metaObj = 0;

void QFontDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("QFontDialog","QDialog");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QFontDialog::tr(const char* s)
{
    return qApp->translate( "QFontDialog", s, 0 );
}

QString QFontDialog::tr(const char* s, const char * c)
{
    return qApp->translate( "QFontDialog", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QFontDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QDialog::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QFontDialog::*m1_t0)(const QString&);
    typedef void (QObject::*om1_t0)(const QString&);
    typedef void (QFontDialog::*m1_t1)(const QString&);
    typedef void (QObject::*om1_t1)(const QString&);
    typedef void (QFontDialog::*m1_t2)(int);
    typedef void (QObject::*om1_t2)(int);
    typedef void (QFontDialog::*m1_t3)(const QString&);
    typedef void (QObject::*om1_t3)(const QString&);
    typedef void (QFontDialog::*m1_t4)(int);
    typedef void (QObject::*om1_t4)(int);
    typedef void (QFontDialog::*m1_t5)(const QString&);
    typedef void (QObject::*om1_t5)(const QString&);
    typedef void (QFontDialog::*m1_t6)(const QString&);
    typedef void (QObject::*om1_t6)(const QString&);
    typedef void (QFontDialog::*m1_t7)();
    typedef void (QObject::*om1_t7)();
    typedef void (QFontDialog::*m1_t8)();
    typedef void (QObject::*om1_t8)();
    m1_t0 v1_0 = &QFontDialog::sizeChanged;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QFontDialog::familyHighlighted;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QFontDialog::familyHighlighted;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QFontDialog::scriptHighlighted;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QFontDialog::scriptHighlighted;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QFontDialog::styleHighlighted;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QFontDialog::sizeHighlighted;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QFontDialog::updateSample;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    m1_t8 v1_8 = &QFontDialog::emitSelectedFont;
    om1_t8 ov1_8 = (om1_t8)v1_8;
    QMetaData *slot_tbl = QMetaObject::new_metadata(9);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(9);
    slot_tbl[0].name = "sizeChanged(const QString&)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Protected;
    slot_tbl[1].name = "familyHighlighted(const QString&)";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Private;
    slot_tbl[2].name = "familyHighlighted(int)";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Private;
    slot_tbl[3].name = "scriptHighlighted(const QString&)";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Private;
    slot_tbl[4].name = "scriptHighlighted(int)";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Private;
    slot_tbl[5].name = "styleHighlighted(const QString&)";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Private;
    slot_tbl[6].name = "sizeHighlighted(const QString&)";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Private;
    slot_tbl[7].name = "updateSample()";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Private;
    slot_tbl[8].name = "emitSelectedFont()";
    slot_tbl[8].ptr = (QMember)ov1_8;
    slot_tbl_access[8] = QMetaData::Private;
    typedef void (QFontDialog::*m2_t0)(const QFont&);
    typedef void (QObject::*om2_t0)(const QFont&);
    typedef void (QFontDialog::*m2_t1)(const QFont&);
    typedef void (QObject::*om2_t1)(const QFont&);
    m2_t0 v2_0 = &QFontDialog::fontSelected;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QFontDialog::fontHighlighted;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    QMetaData *signal_tbl = QMetaObject::new_metadata(2);
    signal_tbl[0].name = "fontSelected(const QFont&)";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "fontHighlighted(const QFont&)";
    signal_tbl[1].ptr = (QMember)ov2_1;
    metaObj = QMetaObject::new_metaobject(
	"QFontDialog", "QDialog",
	slot_tbl, 9,
	signal_tbl, 2,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL fontSelected
void QFontDialog::fontSelected( const QFont& t0 )
{
    // No builtin function for signal parameter type const QFont&
    QConnectionList *clist = receivers("fontSelected(const QFont&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(const QFont&);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL fontHighlighted
void QFontDialog::fontHighlighted( const QFont& t0 )
{
    // No builtin function for signal parameter type const QFont&
    QConnectionList *clist = receivers("fontHighlighted(const QFont&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(const QFont&);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}
