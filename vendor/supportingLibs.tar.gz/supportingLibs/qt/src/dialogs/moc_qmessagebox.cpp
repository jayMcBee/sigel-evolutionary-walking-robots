/****************************************************************************
** QMessageBox meta object code from reading C++ file 'qmessagebox.h'
**
** Created: Wed May 9 12:21:32 2001
**      by: The Qt MOC ($Id: moc_qmessagebox.cpp,v 1.1.1.1 2001/11/20 12:08:17 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qmessagebox.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QMessageBox::className() const
{
    return "QMessageBox";
}

QMetaObject *QMessageBox::metaObj = 0;

void QMessageBox::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("QMessageBox","QDialog");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QMessageBox::tr(const char* s)
{
    return qApp->translate( "QMessageBox", s, 0 );
}

QString QMessageBox::tr(const char* s, const char * c)
{
    return qApp->translate( "QMessageBox", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QMessageBox::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QDialog::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    QMetaEnum* enum_tbl = QMetaObject::new_metaenum( 1 );
    enum_tbl[0].name = "Icon";
    enum_tbl[0].count = 4;
    enum_tbl[0].items = QMetaObject::new_metaenum_item( 4 );
    enum_tbl[0].set = FALSE;
    enum_tbl[0].items[0].key = "NoIcon";
    enum_tbl[0].items[0].value = (int) QMessageBox::NoIcon;
    enum_tbl[0].items[1].key = "Information";
    enum_tbl[0].items[1].value = (int) QMessageBox::Information;
    enum_tbl[0].items[2].key = "Warning";
    enum_tbl[0].items[2].value = (int) QMessageBox::Warning;
    enum_tbl[0].items[3].key = "Critical";
    enum_tbl[0].items[3].value = (int) QMessageBox::Critical;
#endif // QT_NO_PROPERTIES
#ifndef QT_NO_PROPERTIES
    typedef QString (QMessageBox::*m3_t0)()const;
    typedef QString (QObject::*om3_t0)()const;
    typedef void (QMessageBox::*m3_t1)(const QString&);
    typedef void (QObject::*om3_t1)(const QString&);
    typedef Icon (QMessageBox::*m3_t3)()const;
    typedef Icon (QObject::*om3_t3)()const;
    typedef void (QMessageBox::*m3_t4)(Icon);
    typedef void (QObject::*om3_t4)(Icon);
    typedef const QPixmap* (QMessageBox::*m3_t6)()const;
    typedef const QPixmap* (QObject::*om3_t6)()const;
    typedef void (QMessageBox::*m3_t7)(const QPixmap&);
    typedef void (QObject::*om3_t7)(const QPixmap&);
    typedef TextFormat (QMessageBox::*m3_t9)()const;
    typedef TextFormat (QObject::*om3_t9)()const;
    typedef void (QMessageBox::*m3_t10)(TextFormat);
    typedef void (QObject::*om3_t10)(TextFormat);
    m3_t0 v3_0 = &QMessageBox::text;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t1 v3_1 = &QMessageBox::setText;
    om3_t1 ov3_1 = (om3_t1)v3_1;
    m3_t3 v3_3 = &QMessageBox::icon;
    om3_t3 ov3_3 = (om3_t3)v3_3;
    m3_t4 v3_4 = &QMessageBox::setIcon;
    om3_t4 ov3_4 = (om3_t4)v3_4;
    m3_t6 v3_6 = &QMessageBox::iconPixmap;
    om3_t6 ov3_6 = (om3_t6)v3_6;
    m3_t7 v3_7 = &QMessageBox::setIconPixmap;
    om3_t7 ov3_7 = (om3_t7)v3_7;
    m3_t9 v3_9 = &QMessageBox::textFormat;
    om3_t9 ov3_9 = (om3_t9)v3_9;
    m3_t10 v3_10 = &QMessageBox::setTextFormat;
    om3_t10 ov3_10 = (om3_t10)v3_10;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 4 );
    props_tbl[0].t = "QString";
    props_tbl[0].n = "text";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = (QMember)ov3_1;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Reference;
    props_tbl[0].setFlags(QMetaProperty::StdSet);
    props_tbl[1].t = "Icon";
    props_tbl[1].n = "icon";
    props_tbl[1].get = (QMember)ov3_3;
    props_tbl[1].set = (QMember)ov3_4;
    props_tbl[1].reset = 0;
    props_tbl[1].gspec = QMetaProperty::Class;
    props_tbl[1].sspec = QMetaProperty::Class;
    props_tbl[1].enumData = &enum_tbl[0];
    props_tbl[1].setFlags(QMetaProperty::StdSet);
    props_tbl[2].t = "QPixmap";
    props_tbl[2].n = "iconPixmap";
    props_tbl[2].get = (QMember)ov3_6;
    props_tbl[2].set = (QMember)ov3_7;
    props_tbl[2].reset = 0;
    props_tbl[2].gspec = QMetaProperty::Pointer;
    props_tbl[2].sspec = QMetaProperty::Reference;
    props_tbl[2].setFlags(QMetaProperty::StdSet);
    props_tbl[3].t = "TextFormat";
    props_tbl[3].n = "textFormat";
    props_tbl[3].get = (QMember)ov3_9;
    props_tbl[3].set = (QMember)ov3_10;
    props_tbl[3].reset = 0;
    props_tbl[3].gspec = QMetaProperty::Class;
    props_tbl[3].sspec = QMetaProperty::Class;
    props_tbl[3].setFlags(QMetaProperty::UnresolvedEnum|QMetaProperty::StdSet);
#endif // QT_NO_PROPERTIES
    typedef void (QMessageBox::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    m1_t0 v1_0 = &QMessageBox::buttonClicked;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    QMetaData *slot_tbl = QMetaObject::new_metadata(1);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(1);
    slot_tbl[0].name = "buttonClicked()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Private;
    metaObj = QMetaObject::new_metaobject(
	"QMessageBox", "QDialog",
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	props_tbl, 4,
	enum_tbl, 1,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
    metaObj->resolveProperty( &props_tbl[3] );
#endif // QT_NO_PROPERTIES
    return metaObj;
}
