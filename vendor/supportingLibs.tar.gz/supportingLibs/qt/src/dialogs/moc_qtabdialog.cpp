/****************************************************************************
** QTabDialog meta object code from reading C++ file 'qtabdialog.h'
**
** Created: Wed May 9 12:21:47 2001
**      by: The Qt MOC ($Id: moc_qtabdialog.cpp,v 1.1.1.1 2001/11/20 12:08:17 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qtabdialog.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QTabDialog::className() const
{
    return "QTabDialog";
}

QMetaObject *QTabDialog::metaObj = 0;

void QTabDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("QTabDialog","QDialog");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QTabDialog::tr(const char* s)
{
    return qApp->translate( "QTabDialog", s, 0 );
}

QString QTabDialog::tr(const char* s, const char * c)
{
    return qApp->translate( "QTabDialog", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QTabDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QDialog::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QTabDialog::*m1_t0)(int);
    typedef void (QObject::*om1_t0)(int);
    m1_t0 v1_0 = &QTabDialog::showTab;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    QMetaData *slot_tbl = QMetaObject::new_metadata(1);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(1);
    slot_tbl[0].name = "showTab(int)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Private;
    typedef void (QTabDialog::*m2_t0)();
    typedef void (QObject::*om2_t0)();
    typedef void (QTabDialog::*m2_t1)();
    typedef void (QObject::*om2_t1)();
    typedef void (QTabDialog::*m2_t2)();
    typedef void (QObject::*om2_t2)();
    typedef void (QTabDialog::*m2_t3)();
    typedef void (QObject::*om2_t3)();
    typedef void (QTabDialog::*m2_t4)();
    typedef void (QObject::*om2_t4)();
    typedef void (QTabDialog::*m2_t5)(QWidget*);
    typedef void (QObject::*om2_t5)(QWidget*);
    typedef void (QTabDialog::*m2_t6)(const QString&);
    typedef void (QObject::*om2_t6)(const QString&);
    m2_t0 v2_0 = &QTabDialog::aboutToShow;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QTabDialog::applyButtonPressed;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    m2_t2 v2_2 = &QTabDialog::cancelButtonPressed;
    om2_t2 ov2_2 = (om2_t2)v2_2;
    m2_t3 v2_3 = &QTabDialog::defaultButtonPressed;
    om2_t3 ov2_3 = (om2_t3)v2_3;
    m2_t4 v2_4 = &QTabDialog::helpButtonPressed;
    om2_t4 ov2_4 = (om2_t4)v2_4;
    m2_t5 v2_5 = &QTabDialog::currentChanged;
    om2_t5 ov2_5 = (om2_t5)v2_5;
    m2_t6 v2_6 = &QTabDialog::selected;
    om2_t6 ov2_6 = (om2_t6)v2_6;
    QMetaData *signal_tbl = QMetaObject::new_metadata(7);
    signal_tbl[0].name = "aboutToShow()";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "applyButtonPressed()";
    signal_tbl[1].ptr = (QMember)ov2_1;
    signal_tbl[2].name = "cancelButtonPressed()";
    signal_tbl[2].ptr = (QMember)ov2_2;
    signal_tbl[3].name = "defaultButtonPressed()";
    signal_tbl[3].ptr = (QMember)ov2_3;
    signal_tbl[4].name = "helpButtonPressed()";
    signal_tbl[4].ptr = (QMember)ov2_4;
    signal_tbl[5].name = "currentChanged(QWidget*)";
    signal_tbl[5].ptr = (QMember)ov2_5;
    signal_tbl[6].name = "selected(const QString&)";
    signal_tbl[6].ptr = (QMember)ov2_6;
    metaObj = QMetaObject::new_metaobject(
	"QTabDialog", "QDialog",
	slot_tbl, 1,
	signal_tbl, 7,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL aboutToShow
void QTabDialog::aboutToShow()
{
    activate_signal( "aboutToShow()" );
}

// SIGNAL applyButtonPressed
void QTabDialog::applyButtonPressed()
{
    activate_signal( "applyButtonPressed()" );
}

// SIGNAL cancelButtonPressed
void QTabDialog::cancelButtonPressed()
{
    activate_signal( "cancelButtonPressed()" );
}

// SIGNAL defaultButtonPressed
void QTabDialog::defaultButtonPressed()
{
    activate_signal( "defaultButtonPressed()" );
}

// SIGNAL helpButtonPressed
void QTabDialog::helpButtonPressed()
{
    activate_signal( "helpButtonPressed()" );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL currentChanged
void QTabDialog::currentChanged( QWidget* t0 )
{
    // No builtin function for signal parameter type QWidget*
    QConnectionList *clist = receivers("currentChanged(QWidget*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QWidget*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL selected
void QTabDialog::selected( const QString& t0 )
{
    activate_signal_strref( "selected(const QString&)", t0 );
}
