/****************************************************************************
** QFileIconProvider meta object code from reading C++ file 'qfiledialog.h'
**
** Created: Wed May 9 12:21:10 2001
**      by: The Qt MOC ($Id: moc_qfiledialog.cpp,v 1.1.1.1 2001/11/20 12:08:17 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qfiledialog.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QFileIconProvider::className() const
{
    return "QFileIconProvider";
}

QMetaObject *QFileIconProvider::metaObj = 0;

void QFileIconProvider::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QObject::className(), "QObject") != 0 )
	badSuperclassWarning("QFileIconProvider","QObject");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QFileIconProvider::tr(const char* s)
{
    return qApp->translate( "QFileIconProvider", s, 0 );
}

QString QFileIconProvider::tr(const char* s, const char * c)
{
    return qApp->translate( "QFileIconProvider", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QFileIconProvider::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QObject::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    QMetaData::Access *slot_tbl_access = 0;
    metaObj = QMetaObject::new_metaobject(
	"QFileIconProvider", "QObject",
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}


const char *QFileDialog::className() const
{
    return "QFileDialog";
}

QMetaObject *QFileDialog::metaObj = 0;

void QFileDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("QFileDialog","QDialog");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QFileDialog::tr(const char* s)
{
    return qApp->translate( "QFileDialog", s, 0 );
}

QString QFileDialog::tr(const char* s, const char * c)
{
    return qApp->translate( "QFileDialog", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QFileDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QDialog::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    QMetaEnum* enum_tbl = QMetaObject::new_metaenum( 3 );
    enum_tbl[0].name = "Mode";
    enum_tbl[0].count = 5;
    enum_tbl[0].items = QMetaObject::new_metaenum_item( 5 );
    enum_tbl[0].set = FALSE;
    enum_tbl[0].items[0].key = "AnyFile";
    enum_tbl[0].items[0].value = (int) QFileDialog::AnyFile;
    enum_tbl[0].items[1].key = "ExistingFile";
    enum_tbl[0].items[1].value = (int) QFileDialog::ExistingFile;
    enum_tbl[0].items[2].key = "Directory";
    enum_tbl[0].items[2].value = (int) QFileDialog::Directory;
    enum_tbl[0].items[3].key = "ExistingFiles";
    enum_tbl[0].items[3].value = (int) QFileDialog::ExistingFiles;
    enum_tbl[0].items[4].key = "DirectoryOnly";
    enum_tbl[0].items[4].value = (int) QFileDialog::DirectoryOnly;
    enum_tbl[1].name = "ViewMode";
    enum_tbl[1].count = 2;
    enum_tbl[1].items = QMetaObject::new_metaenum_item( 2 );
    enum_tbl[1].set = FALSE;
    enum_tbl[1].items[0].key = "Detail";
    enum_tbl[1].items[0].value = (int) QFileDialog::Detail;
    enum_tbl[1].items[1].key = "List";
    enum_tbl[1].items[1].value = (int) QFileDialog::List;
    enum_tbl[2].name = "PreviewMode";
    enum_tbl[2].count = 3;
    enum_tbl[2].items = QMetaObject::new_metaenum_item( 3 );
    enum_tbl[2].set = FALSE;
    enum_tbl[2].items[0].key = "NoPreview";
    enum_tbl[2].items[0].value = (int) QFileDialog::NoPreview;
    enum_tbl[2].items[1].key = "Contents";
    enum_tbl[2].items[1].value = (int) QFileDialog::Contents;
    enum_tbl[2].items[2].key = "Info";
    enum_tbl[2].items[2].value = (int) QFileDialog::Info;
#endif // QT_NO_PROPERTIES
#ifndef QT_NO_PROPERTIES
    typedef QString (QFileDialog::*m3_t0)()const;
    typedef QString (QObject::*om3_t0)()const;
    typedef QString (QFileDialog::*m3_t3)()const;
    typedef QString (QObject::*om3_t3)()const;
    typedef QStringList (QFileDialog::*m3_t6)()const;
    typedef QStringList (QObject::*om3_t6)()const;
    typedef QString (QFileDialog::*m3_t9)()const;
    typedef QString (QObject::*om3_t9)()const;
    typedef bool (QFileDialog::*m3_t12)()const;
    typedef bool (QObject::*om3_t12)()const;
    typedef void (QFileDialog::*m3_t13)(bool);
    typedef void (QObject::*om3_t13)(bool);
    typedef Mode (QFileDialog::*m3_t15)()const;
    typedef Mode (QObject::*om3_t15)()const;
    typedef void (QFileDialog::*m3_t16)(Mode);
    typedef void (QObject::*om3_t16)(Mode);
    typedef ViewMode (QFileDialog::*m3_t18)()const;
    typedef ViewMode (QObject::*om3_t18)()const;
    typedef void (QFileDialog::*m3_t19)(ViewMode);
    typedef void (QObject::*om3_t19)(ViewMode);
    typedef PreviewMode (QFileDialog::*m3_t21)()const;
    typedef PreviewMode (QObject::*om3_t21)()const;
    typedef void (QFileDialog::*m3_t22)(PreviewMode);
    typedef void (QObject::*om3_t22)(PreviewMode);
    typedef bool (QFileDialog::*m3_t24)()const;
    typedef bool (QObject::*om3_t24)()const;
    typedef void (QFileDialog::*m3_t25)(bool);
    typedef void (QObject::*om3_t25)(bool);
    typedef bool (QFileDialog::*m3_t27)()const;
    typedef bool (QObject::*om3_t27)()const;
    typedef void (QFileDialog::*m3_t28)(bool);
    typedef void (QObject::*om3_t28)(bool);
    m3_t0 v3_0 = &QFileDialog::selectedFile;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t3 v3_3 = &QFileDialog::selectedFilter;
    om3_t3 ov3_3 = (om3_t3)v3_3;
    m3_t6 v3_6 = &QFileDialog::selectedFiles;
    om3_t6 ov3_6 = (om3_t6)v3_6;
    m3_t9 v3_9 = &QFileDialog::dirPath;
    om3_t9 ov3_9 = (om3_t9)v3_9;
    m3_t12 v3_12 = &QFileDialog::showHiddenFiles;
    om3_t12 ov3_12 = (om3_t12)v3_12;
    m3_t13 v3_13 = &QFileDialog::setShowHiddenFiles;
    om3_t13 ov3_13 = (om3_t13)v3_13;
    m3_t15 v3_15 = &QFileDialog::mode;
    om3_t15 ov3_15 = (om3_t15)v3_15;
    m3_t16 v3_16 = &QFileDialog::setMode;
    om3_t16 ov3_16 = (om3_t16)v3_16;
    m3_t18 v3_18 = &QFileDialog::viewMode;
    om3_t18 ov3_18 = (om3_t18)v3_18;
    m3_t19 v3_19 = &QFileDialog::setViewMode;
    om3_t19 ov3_19 = (om3_t19)v3_19;
    m3_t21 v3_21 = &QFileDialog::previewMode;
    om3_t21 ov3_21 = (om3_t21)v3_21;
    m3_t22 v3_22 = &QFileDialog::setPreviewMode;
    om3_t22 ov3_22 = (om3_t22)v3_22;
    m3_t24 v3_24 = &QFileDialog::isInfoPreviewEnabled;
    om3_t24 ov3_24 = (om3_t24)v3_24;
    m3_t25 v3_25 = &QFileDialog::setInfoPreviewEnabled;
    om3_t25 ov3_25 = (om3_t25)v3_25;
    m3_t27 v3_27 = &QFileDialog::isContentsPreviewEnabled;
    om3_t27 ov3_27 = (om3_t27)v3_27;
    m3_t28 v3_28 = &QFileDialog::setContentsPreviewEnabled;
    om3_t28 ov3_28 = (om3_t28)v3_28;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 10 );
    props_tbl[0].t = "QString";
    props_tbl[0].n = "selectedFile";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = 0;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Unspecified;
    props_tbl[1].t = "QString";
    props_tbl[1].n = "selectedFilter";
    props_tbl[1].get = (QMember)ov3_3;
    props_tbl[1].set = 0;
    props_tbl[1].reset = 0;
    props_tbl[1].gspec = QMetaProperty::Class;
    props_tbl[1].sspec = QMetaProperty::Unspecified;
    props_tbl[2].t = "QStringList";
    props_tbl[2].n = "selectedFiles";
    props_tbl[2].get = (QMember)ov3_6;
    props_tbl[2].set = 0;
    props_tbl[2].reset = 0;
    props_tbl[2].gspec = QMetaProperty::Class;
    props_tbl[2].sspec = QMetaProperty::Unspecified;
    props_tbl[3].t = "QString";
    props_tbl[3].n = "dirPath";
    props_tbl[3].get = (QMember)ov3_9;
    props_tbl[3].set = 0;
    props_tbl[3].reset = 0;
    props_tbl[3].gspec = QMetaProperty::Class;
    props_tbl[3].sspec = QMetaProperty::Unspecified;
    props_tbl[4].t = "bool";
    props_tbl[4].n = "showHiddenFiles";
    props_tbl[4].get = (QMember)ov3_12;
    props_tbl[4].set = (QMember)ov3_13;
    props_tbl[4].reset = 0;
    props_tbl[4].gspec = QMetaProperty::Class;
    props_tbl[4].sspec = QMetaProperty::Class;
    props_tbl[4].setFlags(QMetaProperty::StdSet);
    props_tbl[5].t = "Mode";
    props_tbl[5].n = "mode";
    props_tbl[5].get = (QMember)ov3_15;
    props_tbl[5].set = (QMember)ov3_16;
    props_tbl[5].reset = 0;
    props_tbl[5].gspec = QMetaProperty::Class;
    props_tbl[5].sspec = QMetaProperty::Class;
    props_tbl[5].enumData = &enum_tbl[0];
    props_tbl[5].setFlags(QMetaProperty::StdSet);
    props_tbl[6].t = "ViewMode";
    props_tbl[6].n = "viewMode";
    props_tbl[6].get = (QMember)ov3_18;
    props_tbl[6].set = (QMember)ov3_19;
    props_tbl[6].reset = 0;
    props_tbl[6].gspec = QMetaProperty::Class;
    props_tbl[6].sspec = QMetaProperty::Class;
    props_tbl[6].enumData = &enum_tbl[1];
    props_tbl[6].setFlags(QMetaProperty::StdSet);
    props_tbl[7].t = "PreviewMode";
    props_tbl[7].n = "previewMode";
    props_tbl[7].get = (QMember)ov3_21;
    props_tbl[7].set = (QMember)ov3_22;
    props_tbl[7].reset = 0;
    props_tbl[7].gspec = QMetaProperty::Class;
    props_tbl[7].sspec = QMetaProperty::Class;
    props_tbl[7].enumData = &enum_tbl[2];
    props_tbl[7].setFlags(QMetaProperty::StdSet);
    props_tbl[8].t = "bool";
    props_tbl[8].n = "infoPreview";
    props_tbl[8].get = (QMember)ov3_24;
    props_tbl[8].set = (QMember)ov3_25;
    props_tbl[8].reset = 0;
    props_tbl[8].gspec = QMetaProperty::Class;
    props_tbl[8].sspec = QMetaProperty::Class;
    props_tbl[9].t = "bool";
    props_tbl[9].n = "contentsPreview";
    props_tbl[9].get = (QMember)ov3_27;
    props_tbl[9].set = (QMember)ov3_28;
    props_tbl[9].reset = 0;
    props_tbl[9].gspec = QMetaProperty::Class;
    props_tbl[9].sspec = QMetaProperty::Class;
#endif // QT_NO_PROPERTIES
    typedef void (QFileDialog::*m1_t0)(int);
    typedef void (QObject::*om1_t0)(int);
    typedef void (QFileDialog::*m1_t1)(const QString&);
    typedef void (QObject::*om1_t1)(const QString&);
    typedef void (QFileDialog::*m1_t2)(const QUrlOperator&);
    typedef void (QObject::*om1_t2)(const QUrlOperator&);
    typedef void (QFileDialog::*m1_t3)(const QString&);
    typedef void (QObject::*om1_t3)(const QString&);
    typedef void (QFileDialog::*m1_t4)(const QString&);
    typedef void (QObject::*om1_t4)(const QString&);
    typedef void (QFileDialog::*m1_t5)(const char**);
    typedef void (QObject::*om1_t5)(const char**);
    typedef void (QFileDialog::*m1_t6)(const QStringList&);
    typedef void (QObject::*om1_t6)(const QStringList&);
    typedef void (QFileDialog::*m1_t7)();
    typedef void (QObject::*om1_t7)();
    typedef void (QFileDialog::*m1_t8)();
    typedef void (QObject::*om1_t8)();
    typedef void (QFileDialog::*m1_t9)(int);
    typedef void (QObject::*om1_t9)(int);
    typedef void (QFileDialog::*m1_t10)();
    typedef void (QObject::*om1_t10)();
    typedef void (QFileDialog::*m1_t11)();
    typedef void (QObject::*om1_t11)();
    typedef void (QFileDialog::*m1_t12)();
    typedef void (QObject::*om1_t12)();
    typedef void (QFileDialog::*m1_t13)(int);
    typedef void (QObject::*om1_t13)(int);
    typedef void (QFileDialog::*m1_t14)(int);
    typedef void (QObject::*om1_t14)(int);
    typedef void (QFileDialog::*m1_t15)(int);
    typedef void (QObject::*om1_t15)(int);
    typedef void (QFileDialog::*m1_t16)(int);
    typedef void (QObject::*om1_t16)(int);
    typedef void (QFileDialog::*m1_t17)(QListViewItem*);
    typedef void (QObject::*om1_t17)(QListViewItem*);
    typedef void (QFileDialog::*m1_t18)(QListViewItem*);
    typedef void (QObject::*om1_t18)(QListViewItem*);
    typedef void (QFileDialog::*m1_t19)(QListViewItem*,const QPoint&,int);
    typedef void (QObject::*om1_t19)(QListViewItem*,const QPoint&,int);
    typedef void (QFileDialog::*m1_t20)(QListBoxItem*,const QPoint&);
    typedef void (QObject::*om1_t20)(QListBoxItem*,const QPoint&);
    typedef void (QFileDialog::*m1_t21)(QListBoxItem*);
    typedef void (QObject::*om1_t21)(QListBoxItem*);
    typedef void (QFileDialog::*m1_t22)(QListBoxItem*);
    typedef void (QObject::*om1_t22)(QListBoxItem*);
    typedef void (QFileDialog::*m1_t23)();
    typedef void (QObject::*om1_t23)();
    typedef void (QFileDialog::*m1_t24)();
    typedef void (QObject::*om1_t24)();
    typedef void (QFileDialog::*m1_t25)();
    typedef void (QObject::*om1_t25)();
    typedef void (QFileDialog::*m1_t26)();
    typedef void (QObject::*om1_t26)();
    typedef void (QFileDialog::*m1_t27)();
    typedef void (QObject::*om1_t27)();
    typedef void (QFileDialog::*m1_t28)();
    typedef void (QObject::*om1_t28)();
    typedef void (QFileDialog::*m1_t29)();
    typedef void (QObject::*om1_t29)();
    typedef void (QFileDialog::*m1_t30)();
    typedef void (QObject::*om1_t30)();
    typedef void (QFileDialog::*m1_t31)();
    typedef void (QObject::*om1_t31)();
    typedef void (QFileDialog::*m1_t32)();
    typedef void (QObject::*om1_t32)();
    typedef void (QFileDialog::*m1_t33)(QNetworkOperation*);
    typedef void (QObject::*om1_t33)(QNetworkOperation*);
    typedef void (QFileDialog::*m1_t34)(QNetworkOperation*);
    typedef void (QObject::*om1_t34)(QNetworkOperation*);
    typedef void (QFileDialog::*m1_t35)(int,int,QNetworkOperation*);
    typedef void (QObject::*om1_t35)(int,int,QNetworkOperation*);
    typedef void (QFileDialog::*m1_t36)(const QValueList<QUrlInfo>&,QNetworkOperation*);
    typedef void (QObject::*om1_t36)(const QValueList<QUrlInfo>&,QNetworkOperation*);
    typedef void (QFileDialog::*m1_t37)(QNetworkOperation*);
    typedef void (QObject::*om1_t37)(QNetworkOperation*);
    typedef void (QFileDialog::*m1_t38)(const QUrlInfo&,QNetworkOperation*);
    typedef void (QObject::*om1_t38)(const QUrlInfo&,QNetworkOperation*);
    typedef void (QFileDialog::*m1_t39)(QNetworkOperation*);
    typedef void (QObject::*om1_t39)(QNetworkOperation*);
    typedef void (QFileDialog::*m1_t40)();
    typedef void (QObject::*om1_t40)();
    m1_t0 v1_0 = &QFileDialog::done;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QFileDialog::setDir;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QFileDialog::setUrl;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QFileDialog::setFilter;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QFileDialog::setFilters;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QFileDialog::setFilters;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QFileDialog::setFilters;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QFileDialog::detailViewSelectionChanged;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    m1_t8 v1_8 = &QFileDialog::listBoxSelectionChanged;
    om1_t8 ov1_8 = (om1_t8)v1_8;
    m1_t9 v1_9 = &QFileDialog::changeMode;
    om1_t9 ov1_9 = (om1_t9)v1_9;
    m1_t10 v1_10 = &QFileDialog::fileNameEditReturnPressed;
    om1_t10 ov1_10 = (om1_t10)v1_10;
    m1_t11 v1_11 = &QFileDialog::stopCopy;
    om1_t11 ov1_11 = (om1_t11)v1_11;
    m1_t12 v1_12 = &QFileDialog::removeProgressDia;
    om1_t12 ov1_12 = (om1_t12)v1_12;
    m1_t13 v1_13 = &QFileDialog::fileSelected;
    om1_t13 ov1_13 = (om1_t13)v1_13;
    m1_t14 v1_14 = &QFileDialog::fileHighlighted;
    om1_t14 ov1_14 = (om1_t14)v1_14;
    m1_t15 v1_15 = &QFileDialog::dirSelected;
    om1_t15 ov1_15 = (om1_t15)v1_15;
    m1_t16 v1_16 = &QFileDialog::pathSelected;
    om1_t16 ov1_16 = (om1_t16)v1_16;
    m1_t17 v1_17 = &QFileDialog::updateFileNameEdit;
    om1_t17 ov1_17 = (om1_t17)v1_17;
    m1_t18 v1_18 = &QFileDialog::selectDirectoryOrFile;
    om1_t18 ov1_18 = (om1_t18)v1_18;
    m1_t19 v1_19 = &QFileDialog::popupContextMenu;
    om1_t19 ov1_19 = (om1_t19)v1_19;
    m1_t20 v1_20 = &QFileDialog::popupContextMenu;
    om1_t20 ov1_20 = (om1_t20)v1_20;
    m1_t21 v1_21 = &QFileDialog::updateFileNameEdit;
    om1_t21 ov1_21 = (om1_t21)v1_21;
    m1_t22 v1_22 = &QFileDialog::selectDirectoryOrFile;
    om1_t22 ov1_22 = (om1_t22)v1_22;
    m1_t23 v1_23 = &QFileDialog::fileNameEditDone;
    om1_t23 ov1_23 = (om1_t23)v1_23;
    m1_t24 v1_24 = &QFileDialog::okClicked;
    om1_t24 ov1_24 = (om1_t24)v1_24;
    m1_t25 v1_25 = &QFileDialog::filterClicked;
    om1_t25 ov1_25 = (om1_t25)v1_25;
    m1_t26 v1_26 = &QFileDialog::cancelClicked;
    om1_t26 ov1_26 = (om1_t26)v1_26;
    m1_t27 v1_27 = &QFileDialog::cdUpClicked;
    om1_t27 ov1_27 = (om1_t27)v1_27;
    m1_t28 v1_28 = &QFileDialog::newFolderClicked;
    om1_t28 ov1_28 = (om1_t28)v1_28;
    m1_t29 v1_29 = &QFileDialog::fixupNameEdit;
    om1_t29 ov1_29 = (om1_t29)v1_29;
    m1_t30 v1_30 = &QFileDialog::doMimeTypeLookup;
    om1_t30 ov1_30 = (om1_t30)v1_30;
    m1_t31 v1_31 = &QFileDialog::updateGeometries;
    om1_t31 ov1_31 = (om1_t31)v1_31;
    m1_t32 v1_32 = &QFileDialog::modeButtonsDestroyed;
    om1_t32 ov1_32 = (om1_t32)v1_32;
    m1_t33 v1_33 = &QFileDialog::urlStart;
    om1_t33 ov1_33 = (om1_t33)v1_33;
    m1_t34 v1_34 = &QFileDialog::urlFinished;
    om1_t34 ov1_34 = (om1_t34)v1_34;
    m1_t35 v1_35 = &QFileDialog::dataTransferProgress;
    om1_t35 ov1_35 = (om1_t35)v1_35;
    m1_t36 v1_36 = &QFileDialog::insertEntry;
    om1_t36 ov1_36 = (om1_t36)v1_36;
    m1_t37 v1_37 = &QFileDialog::removeEntry;
    om1_t37 ov1_37 = (om1_t37)v1_37;
    m1_t38 v1_38 = &QFileDialog::createdDirectory;
    om1_t38 ov1_38 = (om1_t38)v1_38;
    m1_t39 v1_39 = &QFileDialog::itemChanged;
    om1_t39 ov1_39 = (om1_t39)v1_39;
    m1_t40 v1_40 = &QFileDialog::goBack;
    om1_t40 ov1_40 = (om1_t40)v1_40;
    QMetaData *slot_tbl = QMetaObject::new_metadata(41);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(41);
    slot_tbl[0].name = "done(int)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "setDir(const QString&)";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "setUrl(const QUrlOperator&)";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "setFilter(const QString&)";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "setFilters(const QString&)";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "setFilters(const char**)";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "setFilters(const QStringList&)";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "detailViewSelectionChanged()";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Private;
    slot_tbl[8].name = "listBoxSelectionChanged()";
    slot_tbl[8].ptr = (QMember)ov1_8;
    slot_tbl_access[8] = QMetaData::Private;
    slot_tbl[9].name = "changeMode(int)";
    slot_tbl[9].ptr = (QMember)ov1_9;
    slot_tbl_access[9] = QMetaData::Private;
    slot_tbl[10].name = "fileNameEditReturnPressed()";
    slot_tbl[10].ptr = (QMember)ov1_10;
    slot_tbl_access[10] = QMetaData::Private;
    slot_tbl[11].name = "stopCopy()";
    slot_tbl[11].ptr = (QMember)ov1_11;
    slot_tbl_access[11] = QMetaData::Private;
    slot_tbl[12].name = "removeProgressDia()";
    slot_tbl[12].ptr = (QMember)ov1_12;
    slot_tbl_access[12] = QMetaData::Private;
    slot_tbl[13].name = "fileSelected(int)";
    slot_tbl[13].ptr = (QMember)ov1_13;
    slot_tbl_access[13] = QMetaData::Private;
    slot_tbl[14].name = "fileHighlighted(int)";
    slot_tbl[14].ptr = (QMember)ov1_14;
    slot_tbl_access[14] = QMetaData::Private;
    slot_tbl[15].name = "dirSelected(int)";
    slot_tbl[15].ptr = (QMember)ov1_15;
    slot_tbl_access[15] = QMetaData::Private;
    slot_tbl[16].name = "pathSelected(int)";
    slot_tbl[16].ptr = (QMember)ov1_16;
    slot_tbl_access[16] = QMetaData::Private;
    slot_tbl[17].name = "updateFileNameEdit(QListViewItem*)";
    slot_tbl[17].ptr = (QMember)ov1_17;
    slot_tbl_access[17] = QMetaData::Private;
    slot_tbl[18].name = "selectDirectoryOrFile(QListViewItem*)";
    slot_tbl[18].ptr = (QMember)ov1_18;
    slot_tbl_access[18] = QMetaData::Private;
    slot_tbl[19].name = "popupContextMenu(QListViewItem*,const QPoint&,int)";
    slot_tbl[19].ptr = (QMember)ov1_19;
    slot_tbl_access[19] = QMetaData::Private;
    slot_tbl[20].name = "popupContextMenu(QListBoxItem*,const QPoint&)";
    slot_tbl[20].ptr = (QMember)ov1_20;
    slot_tbl_access[20] = QMetaData::Private;
    slot_tbl[21].name = "updateFileNameEdit(QListBoxItem*)";
    slot_tbl[21].ptr = (QMember)ov1_21;
    slot_tbl_access[21] = QMetaData::Private;
    slot_tbl[22].name = "selectDirectoryOrFile(QListBoxItem*)";
    slot_tbl[22].ptr = (QMember)ov1_22;
    slot_tbl_access[22] = QMetaData::Private;
    slot_tbl[23].name = "fileNameEditDone()";
    slot_tbl[23].ptr = (QMember)ov1_23;
    slot_tbl_access[23] = QMetaData::Private;
    slot_tbl[24].name = "okClicked()";
    slot_tbl[24].ptr = (QMember)ov1_24;
    slot_tbl_access[24] = QMetaData::Private;
    slot_tbl[25].name = "filterClicked()";
    slot_tbl[25].ptr = (QMember)ov1_25;
    slot_tbl_access[25] = QMetaData::Private;
    slot_tbl[26].name = "cancelClicked()";
    slot_tbl[26].ptr = (QMember)ov1_26;
    slot_tbl_access[26] = QMetaData::Private;
    slot_tbl[27].name = "cdUpClicked()";
    slot_tbl[27].ptr = (QMember)ov1_27;
    slot_tbl_access[27] = QMetaData::Private;
    slot_tbl[28].name = "newFolderClicked()";
    slot_tbl[28].ptr = (QMember)ov1_28;
    slot_tbl_access[28] = QMetaData::Private;
    slot_tbl[29].name = "fixupNameEdit()";
    slot_tbl[29].ptr = (QMember)ov1_29;
    slot_tbl_access[29] = QMetaData::Private;
    slot_tbl[30].name = "doMimeTypeLookup()";
    slot_tbl[30].ptr = (QMember)ov1_30;
    slot_tbl_access[30] = QMetaData::Private;
    slot_tbl[31].name = "updateGeometries()";
    slot_tbl[31].ptr = (QMember)ov1_31;
    slot_tbl_access[31] = QMetaData::Private;
    slot_tbl[32].name = "modeButtonsDestroyed()";
    slot_tbl[32].ptr = (QMember)ov1_32;
    slot_tbl_access[32] = QMetaData::Private;
    slot_tbl[33].name = "urlStart(QNetworkOperation*)";
    slot_tbl[33].ptr = (QMember)ov1_33;
    slot_tbl_access[33] = QMetaData::Private;
    slot_tbl[34].name = "urlFinished(QNetworkOperation*)";
    slot_tbl[34].ptr = (QMember)ov1_34;
    slot_tbl_access[34] = QMetaData::Private;
    slot_tbl[35].name = "dataTransferProgress(int,int,QNetworkOperation*)";
    slot_tbl[35].ptr = (QMember)ov1_35;
    slot_tbl_access[35] = QMetaData::Private;
    slot_tbl[36].name = "insertEntry(const QValueList<QUrlInfo>&,QNetworkOperation*)";
    slot_tbl[36].ptr = (QMember)ov1_36;
    slot_tbl_access[36] = QMetaData::Private;
    slot_tbl[37].name = "removeEntry(QNetworkOperation*)";
    slot_tbl[37].ptr = (QMember)ov1_37;
    slot_tbl_access[37] = QMetaData::Private;
    slot_tbl[38].name = "createdDirectory(const QUrlInfo&,QNetworkOperation*)";
    slot_tbl[38].ptr = (QMember)ov1_38;
    slot_tbl_access[38] = QMetaData::Private;
    slot_tbl[39].name = "itemChanged(QNetworkOperation*)";
    slot_tbl[39].ptr = (QMember)ov1_39;
    slot_tbl_access[39] = QMetaData::Private;
    slot_tbl[40].name = "goBack()";
    slot_tbl[40].ptr = (QMember)ov1_40;
    slot_tbl_access[40] = QMetaData::Private;
    typedef void (QFileDialog::*m2_t0)(const QString&);
    typedef void (QObject::*om2_t0)(const QString&);
    typedef void (QFileDialog::*m2_t1)(const QString&);
    typedef void (QObject::*om2_t1)(const QString&);
    typedef void (QFileDialog::*m2_t2)(const QString&);
    typedef void (QObject::*om2_t2)(const QString&);
    m2_t0 v2_0 = &QFileDialog::fileHighlighted;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QFileDialog::fileSelected;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    m2_t2 v2_2 = &QFileDialog::dirEntered;
    om2_t2 ov2_2 = (om2_t2)v2_2;
    QMetaData *signal_tbl = QMetaObject::new_metadata(3);
    signal_tbl[0].name = "fileHighlighted(const QString&)";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "fileSelected(const QString&)";
    signal_tbl[1].ptr = (QMember)ov2_1;
    signal_tbl[2].name = "dirEntered(const QString&)";
    signal_tbl[2].ptr = (QMember)ov2_2;
    metaObj = QMetaObject::new_metaobject(
	"QFileDialog", "QDialog",
	slot_tbl, 41,
	signal_tbl, 3,
#ifndef QT_NO_PROPERTIES
	props_tbl, 10,
	enum_tbl, 3,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL fileHighlighted
void QFileDialog::fileHighlighted( const QString& t0 )
{
    activate_signal_strref( "fileHighlighted(const QString&)", t0 );
}

// SIGNAL fileSelected
void QFileDialog::fileSelected( const QString& t0 )
{
    activate_signal_strref( "fileSelected(const QString&)", t0 );
}

// SIGNAL dirEntered
void QFileDialog::dirEntered( const QString& t0 )
{
    activate_signal_strref( "dirEntered(const QString&)", t0 );
}
