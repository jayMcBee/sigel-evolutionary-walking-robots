/****************************************************************************
** QColorDialog meta object code from reading C++ file 'qcolordialog.h'
**
** Created: Wed May 9 12:21:04 2001
**      by: The Qt MOC ($Id: moc_qcolordialog.cpp,v 1.1.1.1 2001/11/20 12:08:17 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qcolordialog.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QColorDialog::className() const
{
    return "QColorDialog";
}

QMetaObject *QColorDialog::metaObj = 0;

void QColorDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QDialog::className(), "QDialog") != 0 )
	badSuperclassWarning("QColorDialog","QDialog");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QColorDialog::tr(const char* s)
{
    return qApp->translate( "QColorDialog", s, 0 );
}

QString QColorDialog::tr(const char* s, const char * c)
{
    return qApp->translate( "QColorDialog", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QColorDialog::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QDialog::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    QMetaData::Access *slot_tbl_access = 0;
    metaObj = QMetaObject::new_metaobject(
	"QColorDialog", "QDialog",
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
