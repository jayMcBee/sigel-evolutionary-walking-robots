/****************************************************************************
** QIconDrag meta object code from reading C++ file 'qiconview.h'
**
** Created: Wed May 9 12:22:59 2001
**      by: The Qt MOC ($Id: moc_qiconview.cpp,v 1.1.1.1 2001/11/20 12:08:17 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qiconview.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QIconDrag::className() const
{
    return "QIconDrag";
}

QMetaObject *QIconDrag::metaObj = 0;

void QIconDrag::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QDragObject::className(), "QDragObject") != 0 )
	badSuperclassWarning("QIconDrag","QDragObject");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QIconDrag::tr(const char* s)
{
    return qApp->translate( "QIconDrag", s, 0 );
}

QString QIconDrag::tr(const char* s, const char * c)
{
    return qApp->translate( "QIconDrag", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QIconDrag::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QDragObject::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    QMetaData::Access *slot_tbl_access = 0;
    metaObj = QMetaObject::new_metaobject(
	"QIconDrag", "QDragObject",
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}


const char *QIconView::className() const
{
    return "QIconView";
}

QMetaObject *QIconView::metaObj = 0;

void QIconView::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QScrollView::className(), "QScrollView") != 0 )
	badSuperclassWarning("QIconView","QScrollView");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QIconView::tr(const char* s)
{
    return qApp->translate( "QIconView", s, 0 );
}

QString QIconView::tr(const char* s, const char * c)
{
    return qApp->translate( "QIconView", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QIconView::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QScrollView::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    QMetaEnum* enum_tbl = QMetaObject::new_metaenum( 4 );
    enum_tbl[0].name = "SelectionMode";
    enum_tbl[0].count = 4;
    enum_tbl[0].items = QMetaObject::new_metaenum_item( 4 );
    enum_tbl[0].set = FALSE;
    enum_tbl[0].items[0].key = "Single";
    enum_tbl[0].items[0].value = (int) QIconView::Single;
    enum_tbl[0].items[1].key = "Multi";
    enum_tbl[0].items[1].value = (int) QIconView::Multi;
    enum_tbl[0].items[2].key = "Extended";
    enum_tbl[0].items[2].value = (int) QIconView::Extended;
    enum_tbl[0].items[3].key = "NoSelection";
    enum_tbl[0].items[3].value = (int) QIconView::NoSelection;
    enum_tbl[1].name = "Arrangement";
    enum_tbl[1].count = 2;
    enum_tbl[1].items = QMetaObject::new_metaenum_item( 2 );
    enum_tbl[1].set = FALSE;
    enum_tbl[1].items[0].key = "LeftToRight";
    enum_tbl[1].items[0].value = (int) QIconView::LeftToRight;
    enum_tbl[1].items[1].key = "TopToBottom";
    enum_tbl[1].items[1].value = (int) QIconView::TopToBottom;
    enum_tbl[2].name = "ResizeMode";
    enum_tbl[2].count = 2;
    enum_tbl[2].items = QMetaObject::new_metaenum_item( 2 );
    enum_tbl[2].set = FALSE;
    enum_tbl[2].items[0].key = "Fixed";
    enum_tbl[2].items[0].value = (int) QIconView::Fixed;
    enum_tbl[2].items[1].key = "Adjust";
    enum_tbl[2].items[1].value = (int) QIconView::Adjust;
    enum_tbl[3].name = "ItemTextPos";
    enum_tbl[3].count = 2;
    enum_tbl[3].items = QMetaObject::new_metaenum_item( 2 );
    enum_tbl[3].set = FALSE;
    enum_tbl[3].items[0].key = "Bottom";
    enum_tbl[3].items[0].value = (int) QIconView::Bottom;
    enum_tbl[3].items[1].key = "Right";
    enum_tbl[3].items[1].value = (int) QIconView::Right;
#endif // QT_NO_PROPERTIES
#ifndef QT_NO_PROPERTIES
    typedef bool (QIconView::*m3_t0)()const;
    typedef bool (QObject::*om3_t0)()const;
    typedef bool (QIconView::*m3_t3)()const;
    typedef bool (QObject::*om3_t3)()const;
    typedef SelectionMode (QIconView::*m3_t6)()const;
    typedef SelectionMode (QObject::*om3_t6)()const;
    typedef void (QIconView::*m3_t7)(SelectionMode);
    typedef void (QObject::*om3_t7)(SelectionMode);
    typedef int (QIconView::*m3_t9)()const;
    typedef int (QObject::*om3_t9)()const;
    typedef void (QIconView::*m3_t10)(int);
    typedef void (QObject::*om3_t10)(int);
    typedef int (QIconView::*m3_t12)()const;
    typedef int (QObject::*om3_t12)()const;
    typedef void (QIconView::*m3_t13)(int);
    typedef void (QObject::*om3_t13)(int);
    typedef int (QIconView::*m3_t15)()const;
    typedef int (QObject::*om3_t15)()const;
    typedef void (QIconView::*m3_t16)(int);
    typedef void (QObject::*om3_t16)(int);
    typedef ItemTextPos (QIconView::*m3_t18)()const;
    typedef ItemTextPos (QObject::*om3_t18)()const;
    typedef void (QIconView::*m3_t19)(ItemTextPos);
    typedef void (QObject::*om3_t19)(ItemTextPos);
    typedef QBrush (QIconView::*m3_t21)()const;
    typedef QBrush (QObject::*om3_t21)()const;
    typedef void (QIconView::*m3_t22)(const QBrush&);
    typedef void (QObject::*om3_t22)(const QBrush&);
    typedef Arrangement (QIconView::*m3_t24)()const;
    typedef Arrangement (QObject::*om3_t24)()const;
    typedef void (QIconView::*m3_t25)(Arrangement);
    typedef void (QObject::*om3_t25)(Arrangement);
    typedef ResizeMode (QIconView::*m3_t27)()const;
    typedef ResizeMode (QObject::*om3_t27)()const;
    typedef void (QIconView::*m3_t28)(ResizeMode);
    typedef void (QObject::*om3_t28)(ResizeMode);
    typedef int (QIconView::*m3_t30)()const;
    typedef int (QObject::*om3_t30)()const;
    typedef void (QIconView::*m3_t31)(int);
    typedef void (QObject::*om3_t31)(int);
    typedef int (QIconView::*m3_t33)()const;
    typedef int (QObject::*om3_t33)()const;
    typedef void (QIconView::*m3_t34)(int);
    typedef void (QObject::*om3_t34)(int);
    typedef bool (QIconView::*m3_t36)()const;
    typedef bool (QObject::*om3_t36)()const;
    typedef void (QIconView::*m3_t37)(bool);
    typedef void (QObject::*om3_t37)(bool);
    typedef bool (QIconView::*m3_t39)()const;
    typedef bool (QObject::*om3_t39)()const;
    typedef void (QIconView::*m3_t40)(bool);
    typedef void (QObject::*om3_t40)(bool);
    typedef bool (QIconView::*m3_t42)()const;
    typedef bool (QObject::*om3_t42)()const;
    typedef void (QIconView::*m3_t43)(bool);
    typedef void (QObject::*om3_t43)(bool);
    typedef bool (QIconView::*m3_t45)()const;
    typedef bool (QObject::*om3_t45)()const;
    typedef void (QIconView::*m3_t46)(bool);
    typedef void (QObject::*om3_t46)(bool);
    typedef uint (QIconView::*m3_t48)()const;
    typedef uint (QObject::*om3_t48)()const;
    m3_t0 v3_0 = &QIconView::sorting;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t3 v3_3 = &QIconView::sortDirection;
    om3_t3 ov3_3 = (om3_t3)v3_3;
    m3_t6 v3_6 = &QIconView::selectionMode;
    om3_t6 ov3_6 = (om3_t6)v3_6;
    m3_t7 v3_7 = &QIconView::setSelectionMode;
    om3_t7 ov3_7 = (om3_t7)v3_7;
    m3_t9 v3_9 = &QIconView::gridX;
    om3_t9 ov3_9 = (om3_t9)v3_9;
    m3_t10 v3_10 = &QIconView::setGridX;
    om3_t10 ov3_10 = (om3_t10)v3_10;
    m3_t12 v3_12 = &QIconView::gridY;
    om3_t12 ov3_12 = (om3_t12)v3_12;
    m3_t13 v3_13 = &QIconView::setGridY;
    om3_t13 ov3_13 = (om3_t13)v3_13;
    m3_t15 v3_15 = &QIconView::spacing;
    om3_t15 ov3_15 = (om3_t15)v3_15;
    m3_t16 v3_16 = &QIconView::setSpacing;
    om3_t16 ov3_16 = (om3_t16)v3_16;
    m3_t18 v3_18 = &QIconView::itemTextPos;
    om3_t18 ov3_18 = (om3_t18)v3_18;
    m3_t19 v3_19 = &QIconView::setItemTextPos;
    om3_t19 ov3_19 = (om3_t19)v3_19;
    m3_t21 v3_21 = &QIconView::itemTextBackground;
    om3_t21 ov3_21 = (om3_t21)v3_21;
    m3_t22 v3_22 = &QIconView::setItemTextBackground;
    om3_t22 ov3_22 = (om3_t22)v3_22;
    m3_t24 v3_24 = &QIconView::arrangement;
    om3_t24 ov3_24 = (om3_t24)v3_24;
    m3_t25 v3_25 = &QIconView::setArrangement;
    om3_t25 ov3_25 = (om3_t25)v3_25;
    m3_t27 v3_27 = &QIconView::resizeMode;
    om3_t27 ov3_27 = (om3_t27)v3_27;
    m3_t28 v3_28 = &QIconView::setResizeMode;
    om3_t28 ov3_28 = (om3_t28)v3_28;
    m3_t30 v3_30 = &QIconView::maxItemWidth;
    om3_t30 ov3_30 = (om3_t30)v3_30;
    m3_t31 v3_31 = &QIconView::setMaxItemWidth;
    om3_t31 ov3_31 = (om3_t31)v3_31;
    m3_t33 v3_33 = &QIconView::maxItemTextLength;
    om3_t33 ov3_33 = (om3_t33)v3_33;
    m3_t34 v3_34 = &QIconView::setMaxItemTextLength;
    om3_t34 ov3_34 = (om3_t34)v3_34;
    m3_t36 v3_36 = &QIconView::autoArrange;
    om3_t36 ov3_36 = (om3_t36)v3_36;
    m3_t37 v3_37 = &QIconView::setAutoArrange;
    om3_t37 ov3_37 = (om3_t37)v3_37;
    m3_t39 v3_39 = &QIconView::itemsMovable;
    om3_t39 ov3_39 = (om3_t39)v3_39;
    m3_t40 v3_40 = &QIconView::setItemsMovable;
    om3_t40 ov3_40 = (om3_t40)v3_40;
    m3_t42 v3_42 = &QIconView::wordWrapIconText;
    om3_t42 ov3_42 = (om3_t42)v3_42;
    m3_t43 v3_43 = &QIconView::setWordWrapIconText;
    om3_t43 ov3_43 = (om3_t43)v3_43;
    m3_t45 v3_45 = &QIconView::showToolTips;
    om3_t45 ov3_45 = (om3_t45)v3_45;
    m3_t46 v3_46 = &QIconView::setShowToolTips;
    om3_t46 ov3_46 = (om3_t46)v3_46;
    m3_t48 v3_48 = &QIconView::count;
    om3_t48 ov3_48 = (om3_t48)v3_48;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 17 );
    props_tbl[0].t = "bool";
    props_tbl[0].n = "sorting";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = 0;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Unspecified;
    props_tbl[1].t = "bool";
    props_tbl[1].n = "sortDirection";
    props_tbl[1].get = (QMember)ov3_3;
    props_tbl[1].set = 0;
    props_tbl[1].reset = 0;
    props_tbl[1].gspec = QMetaProperty::Class;
    props_tbl[1].sspec = QMetaProperty::Unspecified;
    props_tbl[2].t = "SelectionMode";
    props_tbl[2].n = "selectionMode";
    props_tbl[2].get = (QMember)ov3_6;
    props_tbl[2].set = (QMember)ov3_7;
    props_tbl[2].reset = 0;
    props_tbl[2].gspec = QMetaProperty::Class;
    props_tbl[2].sspec = QMetaProperty::Class;
    props_tbl[2].enumData = &enum_tbl[0];
    props_tbl[2].setFlags(QMetaProperty::StdSet);
    props_tbl[3].t = "int";
    props_tbl[3].n = "gridX";
    props_tbl[3].get = (QMember)ov3_9;
    props_tbl[3].set = (QMember)ov3_10;
    props_tbl[3].reset = 0;
    props_tbl[3].gspec = QMetaProperty::Class;
    props_tbl[3].sspec = QMetaProperty::Class;
    props_tbl[3].setFlags(QMetaProperty::StdSet);
    props_tbl[4].t = "int";
    props_tbl[4].n = "gridY";
    props_tbl[4].get = (QMember)ov3_12;
    props_tbl[4].set = (QMember)ov3_13;
    props_tbl[4].reset = 0;
    props_tbl[4].gspec = QMetaProperty::Class;
    props_tbl[4].sspec = QMetaProperty::Class;
    props_tbl[4].setFlags(QMetaProperty::StdSet);
    props_tbl[5].t = "int";
    props_tbl[5].n = "spacing";
    props_tbl[5].get = (QMember)ov3_15;
    props_tbl[5].set = (QMember)ov3_16;
    props_tbl[5].reset = 0;
    props_tbl[5].gspec = QMetaProperty::Class;
    props_tbl[5].sspec = QMetaProperty::Class;
    props_tbl[5].setFlags(QMetaProperty::StdSet);
    props_tbl[6].t = "ItemTextPos";
    props_tbl[6].n = "itemTextPos";
    props_tbl[6].get = (QMember)ov3_18;
    props_tbl[6].set = (QMember)ov3_19;
    props_tbl[6].reset = 0;
    props_tbl[6].gspec = QMetaProperty::Class;
    props_tbl[6].sspec = QMetaProperty::Class;
    props_tbl[6].enumData = &enum_tbl[3];
    props_tbl[6].setFlags(QMetaProperty::StdSet);
    props_tbl[7].t = "QBrush";
    props_tbl[7].n = "itemTextBackground";
    props_tbl[7].get = (QMember)ov3_21;
    props_tbl[7].set = (QMember)ov3_22;
    props_tbl[7].reset = 0;
    props_tbl[7].gspec = QMetaProperty::Class;
    props_tbl[7].sspec = QMetaProperty::Reference;
    props_tbl[7].setFlags(QMetaProperty::StdSet);
    props_tbl[8].t = "Arrangement";
    props_tbl[8].n = "arrangement";
    props_tbl[8].get = (QMember)ov3_24;
    props_tbl[8].set = (QMember)ov3_25;
    props_tbl[8].reset = 0;
    props_tbl[8].gspec = QMetaProperty::Class;
    props_tbl[8].sspec = QMetaProperty::Class;
    props_tbl[8].enumData = &enum_tbl[1];
    props_tbl[8].setFlags(QMetaProperty::StdSet);
    props_tbl[9].t = "ResizeMode";
    props_tbl[9].n = "resizeMode";
    props_tbl[9].get = (QMember)ov3_27;
    props_tbl[9].set = (QMember)ov3_28;
    props_tbl[9].reset = 0;
    props_tbl[9].gspec = QMetaProperty::Class;
    props_tbl[9].sspec = QMetaProperty::Class;
    props_tbl[9].enumData = &enum_tbl[2];
    props_tbl[9].setFlags(QMetaProperty::StdSet);
    props_tbl[10].t = "int";
    props_tbl[10].n = "maxItemWidth";
    props_tbl[10].get = (QMember)ov3_30;
    props_tbl[10].set = (QMember)ov3_31;
    props_tbl[10].reset = 0;
    props_tbl[10].gspec = QMetaProperty::Class;
    props_tbl[10].sspec = QMetaProperty::Class;
    props_tbl[10].setFlags(QMetaProperty::StdSet);
    props_tbl[11].t = "int";
    props_tbl[11].n = "maxItemTextLength";
    props_tbl[11].get = (QMember)ov3_33;
    props_tbl[11].set = (QMember)ov3_34;
    props_tbl[11].reset = 0;
    props_tbl[11].gspec = QMetaProperty::Class;
    props_tbl[11].sspec = QMetaProperty::Class;
    props_tbl[11].setFlags(QMetaProperty::StdSet);
    props_tbl[12].t = "bool";
    props_tbl[12].n = "autoArrange";
    props_tbl[12].get = (QMember)ov3_36;
    props_tbl[12].set = (QMember)ov3_37;
    props_tbl[12].reset = 0;
    props_tbl[12].gspec = QMetaProperty::Class;
    props_tbl[12].sspec = QMetaProperty::Class;
    props_tbl[12].setFlags(QMetaProperty::StdSet);
    props_tbl[13].t = "bool";
    props_tbl[13].n = "itemsMovable";
    props_tbl[13].get = (QMember)ov3_39;
    props_tbl[13].set = (QMember)ov3_40;
    props_tbl[13].reset = 0;
    props_tbl[13].gspec = QMetaProperty::Class;
    props_tbl[13].sspec = QMetaProperty::Class;
    props_tbl[13].setFlags(QMetaProperty::StdSet);
    props_tbl[14].t = "bool";
    props_tbl[14].n = "wordWrapIconText";
    props_tbl[14].get = (QMember)ov3_42;
    props_tbl[14].set = (QMember)ov3_43;
    props_tbl[14].reset = 0;
    props_tbl[14].gspec = QMetaProperty::Class;
    props_tbl[14].sspec = QMetaProperty::Class;
    props_tbl[14].setFlags(QMetaProperty::StdSet);
    props_tbl[15].t = "bool";
    props_tbl[15].n = "showToolTips";
    props_tbl[15].get = (QMember)ov3_45;
    props_tbl[15].set = (QMember)ov3_46;
    props_tbl[15].reset = 0;
    props_tbl[15].gspec = QMetaProperty::Class;
    props_tbl[15].sspec = QMetaProperty::Class;
    props_tbl[15].setFlags(QMetaProperty::StdSet);
    props_tbl[16].t = "uint";
    props_tbl[16].n = "count";
    props_tbl[16].get = (QMember)ov3_48;
    props_tbl[16].set = 0;
    props_tbl[16].reset = 0;
    props_tbl[16].gspec = QMetaProperty::Class;
    props_tbl[16].sspec = QMetaProperty::Unspecified;
#endif // QT_NO_PROPERTIES
    typedef void (QIconView::*m1_t0)(const QSize&,bool);
    typedef void (QObject::*om1_t0)(const QSize&,bool);
    typedef void (QIconView::*m1_t1)(bool);
    typedef void (QObject::*om1_t1)(bool);
    typedef void (QIconView::*m1_t2)(int,int);
    typedef void (QObject::*om1_t2)(int,int);
    typedef void (QIconView::*m1_t3)();
    typedef void (QObject::*om1_t3)();
    typedef void (QIconView::*m1_t4)();
    typedef void (QObject::*om1_t4)();
    typedef void (QIconView::*m1_t5)();
    typedef void (QObject::*om1_t5)();
    typedef void (QIconView::*m1_t6)();
    typedef void (QObject::*om1_t6)();
    typedef void (QIconView::*m1_t7)();
    typedef void (QObject::*om1_t7)();
    typedef void (QIconView::*m1_t8)(int,int);
    typedef void (QObject::*om1_t8)(int,int);
    m1_t0 v1_0 = &QIconView::arrangeItemsInGrid;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QIconView::arrangeItemsInGrid;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QIconView::setContentsPos;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QIconView::updateContents;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QIconView::doAutoScroll;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QIconView::adjustItems;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QIconView::slotUpdate;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QIconView::clearInputString;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    m1_t8 v1_8 = &QIconView::movedContents;
    om1_t8 ov1_8 = (om1_t8)v1_8;
    QMetaData *slot_tbl = QMetaObject::new_metadata(9);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(9);
    slot_tbl[0].name = "arrangeItemsInGrid(const QSize&,bool)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "arrangeItemsInGrid(bool)";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "setContentsPos(int,int)";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "updateContents()";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "doAutoScroll()";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Protected;
    slot_tbl[5].name = "adjustItems()";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Protected;
    slot_tbl[6].name = "slotUpdate()";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Protected;
    slot_tbl[7].name = "clearInputString()";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Private;
    slot_tbl[8].name = "movedContents(int,int)";
    slot_tbl[8].ptr = (QMember)ov1_8;
    slot_tbl_access[8] = QMetaData::Private;
    typedef void (QIconView::*m2_t0)();
    typedef void (QObject::*om2_t0)();
    typedef void (QIconView::*m2_t1)(QIconViewItem*);
    typedef void (QObject::*om2_t1)(QIconViewItem*);
    typedef void (QIconView::*m2_t2)(QIconViewItem*);
    typedef void (QObject::*om2_t2)(QIconViewItem*);
    typedef void (QIconView::*m2_t3)(QIconViewItem*);
    typedef void (QObject::*om2_t3)(QIconViewItem*);
    typedef void (QIconView::*m2_t4)(QIconViewItem*,const QPoint&);
    typedef void (QObject::*om2_t4)(QIconViewItem*,const QPoint&);
    typedef void (QIconView::*m2_t5)(QIconViewItem*);
    typedef void (QObject::*om2_t5)(QIconViewItem*);
    typedef void (QIconView::*m2_t6)(QIconViewItem*,const QPoint&);
    typedef void (QObject::*om2_t6)(QIconViewItem*,const QPoint&);
    typedef void (QIconView::*m2_t7)(QIconViewItem*);
    typedef void (QObject::*om2_t7)(QIconViewItem*);
    typedef void (QIconView::*m2_t8)(QIconViewItem*);
    typedef void (QObject::*om2_t8)(QIconViewItem*);
    typedef void (QIconView::*m2_t9)(QIconViewItem*,const QPoint&);
    typedef void (QObject::*om2_t9)(QIconViewItem*,const QPoint&);
    typedef void (QIconView::*m2_t10)(QIconViewItem*,const QPoint&);
    typedef void (QObject::*om2_t10)(QIconViewItem*,const QPoint&);
    typedef void (QIconView::*m2_t11)(int,QIconViewItem*,const QPoint&);
    typedef void (QObject::*om2_t11)(int,QIconViewItem*,const QPoint&);
    typedef void (QIconView::*m2_t12)(int,QIconViewItem*,const QPoint&);
    typedef void (QObject::*om2_t12)(int,QIconViewItem*,const QPoint&);
    typedef void (QIconView::*m2_t13)(QDropEvent*,const QValueList<QIconDragItem>&);
    typedef void (QObject::*om2_t13)(QDropEvent*,const QValueList<QIconDragItem>&);
    typedef void (QIconView::*m2_t14)();
    typedef void (QObject::*om2_t14)();
    typedef void (QIconView::*m2_t15)(QIconViewItem*);
    typedef void (QObject::*om2_t15)(QIconViewItem*);
    typedef void (QIconView::*m2_t16)();
    typedef void (QObject::*om2_t16)();
    typedef void (QIconView::*m2_t17)(QIconViewItem*,const QString&);
    typedef void (QObject::*om2_t17)(QIconViewItem*,const QString&);
    typedef void (QIconView::*m2_t18)(QIconViewItem*);
    typedef void (QObject::*om2_t18)(QIconViewItem*);
    m2_t0 v2_0 = &QIconView::selectionChanged;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QIconView::selectionChanged;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    m2_t2 v2_2 = &QIconView::currentChanged;
    om2_t2 ov2_2 = (om2_t2)v2_2;
    m2_t3 v2_3 = &QIconView::clicked;
    om2_t3 ov2_3 = (om2_t3)v2_3;
    m2_t4 v2_4 = &QIconView::clicked;
    om2_t4 ov2_4 = (om2_t4)v2_4;
    m2_t5 v2_5 = &QIconView::pressed;
    om2_t5 ov2_5 = (om2_t5)v2_5;
    m2_t6 v2_6 = &QIconView::pressed;
    om2_t6 ov2_6 = (om2_t6)v2_6;
    m2_t7 v2_7 = &QIconView::doubleClicked;
    om2_t7 ov2_7 = (om2_t7)v2_7;
    m2_t8 v2_8 = &QIconView::returnPressed;
    om2_t8 ov2_8 = (om2_t8)v2_8;
    m2_t9 v2_9 = &QIconView::rightButtonClicked;
    om2_t9 ov2_9 = (om2_t9)v2_9;
    m2_t10 v2_10 = &QIconView::rightButtonPressed;
    om2_t10 ov2_10 = (om2_t10)v2_10;
    m2_t11 v2_11 = &QIconView::mouseButtonPressed;
    om2_t11 ov2_11 = (om2_t11)v2_11;
    m2_t12 v2_12 = &QIconView::mouseButtonClicked;
    om2_t12 ov2_12 = (om2_t12)v2_12;
    m2_t13 v2_13 = &QIconView::dropped;
    om2_t13 ov2_13 = (om2_t13)v2_13;
    m2_t14 v2_14 = &QIconView::moved;
    om2_t14 ov2_14 = (om2_t14)v2_14;
    m2_t15 v2_15 = &QIconView::onItem;
    om2_t15 ov2_15 = (om2_t15)v2_15;
    m2_t16 v2_16 = &QIconView::onViewport;
    om2_t16 ov2_16 = (om2_t16)v2_16;
    m2_t17 v2_17 = &QIconView::itemRenamed;
    om2_t17 ov2_17 = (om2_t17)v2_17;
    m2_t18 v2_18 = &QIconView::itemRenamed;
    om2_t18 ov2_18 = (om2_t18)v2_18;
    QMetaData *signal_tbl = QMetaObject::new_metadata(19);
    signal_tbl[0].name = "selectionChanged()";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "selectionChanged(QIconViewItem*)";
    signal_tbl[1].ptr = (QMember)ov2_1;
    signal_tbl[2].name = "currentChanged(QIconViewItem*)";
    signal_tbl[2].ptr = (QMember)ov2_2;
    signal_tbl[3].name = "clicked(QIconViewItem*)";
    signal_tbl[3].ptr = (QMember)ov2_3;
    signal_tbl[4].name = "clicked(QIconViewItem*,const QPoint&)";
    signal_tbl[4].ptr = (QMember)ov2_4;
    signal_tbl[5].name = "pressed(QIconViewItem*)";
    signal_tbl[5].ptr = (QMember)ov2_5;
    signal_tbl[6].name = "pressed(QIconViewItem*,const QPoint&)";
    signal_tbl[6].ptr = (QMember)ov2_6;
    signal_tbl[7].name = "doubleClicked(QIconViewItem*)";
    signal_tbl[7].ptr = (QMember)ov2_7;
    signal_tbl[8].name = "returnPressed(QIconViewItem*)";
    signal_tbl[8].ptr = (QMember)ov2_8;
    signal_tbl[9].name = "rightButtonClicked(QIconViewItem*,const QPoint&)";
    signal_tbl[9].ptr = (QMember)ov2_9;
    signal_tbl[10].name = "rightButtonPressed(QIconViewItem*,const QPoint&)";
    signal_tbl[10].ptr = (QMember)ov2_10;
    signal_tbl[11].name = "mouseButtonPressed(int,QIconViewItem*,const QPoint&)";
    signal_tbl[11].ptr = (QMember)ov2_11;
    signal_tbl[12].name = "mouseButtonClicked(int,QIconViewItem*,const QPoint&)";
    signal_tbl[12].ptr = (QMember)ov2_12;
    signal_tbl[13].name = "dropped(QDropEvent*,const QValueList<QIconDragItem>&)";
    signal_tbl[13].ptr = (QMember)ov2_13;
    signal_tbl[14].name = "moved()";
    signal_tbl[14].ptr = (QMember)ov2_14;
    signal_tbl[15].name = "onItem(QIconViewItem*)";
    signal_tbl[15].ptr = (QMember)ov2_15;
    signal_tbl[16].name = "onViewport()";
    signal_tbl[16].ptr = (QMember)ov2_16;
    signal_tbl[17].name = "itemRenamed(QIconViewItem*,const QString&)";
    signal_tbl[17].ptr = (QMember)ov2_17;
    signal_tbl[18].name = "itemRenamed(QIconViewItem*)";
    signal_tbl[18].ptr = (QMember)ov2_18;
    metaObj = QMetaObject::new_metaobject(
	"QIconView", "QScrollView",
	slot_tbl, 9,
	signal_tbl, 19,
#ifndef QT_NO_PROPERTIES
	props_tbl, 17,
	enum_tbl, 4,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL selectionChanged
void QIconView::selectionChanged()
{
    activate_signal( "selectionChanged()" );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL selectionChanged
void QIconView::selectionChanged( QIconViewItem* t0 )
{
    // No builtin function for signal parameter type QIconViewItem*
    QConnectionList *clist = receivers("selectionChanged(QIconViewItem*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL currentChanged
void QIconView::currentChanged( QIconViewItem* t0 )
{
    // No builtin function for signal parameter type QIconViewItem*
    QConnectionList *clist = receivers("currentChanged(QIconViewItem*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL clicked
void QIconView::clicked( QIconViewItem* t0 )
{
    // No builtin function for signal parameter type QIconViewItem*
    QConnectionList *clist = receivers("clicked(QIconViewItem*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL clicked
void QIconView::clicked( QIconViewItem* t0, const QPoint& t1 )
{
    // No builtin function for signal parameter type QIconViewItem*,const QPoint&
    QConnectionList *clist = receivers("clicked(QIconViewItem*,const QPoint&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    typedef void (QObject::*RT2)(QIconViewItem*,const QPoint&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL pressed
void QIconView::pressed( QIconViewItem* t0 )
{
    // No builtin function for signal parameter type QIconViewItem*
    QConnectionList *clist = receivers("pressed(QIconViewItem*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL pressed
void QIconView::pressed( QIconViewItem* t0, const QPoint& t1 )
{
    // No builtin function for signal parameter type QIconViewItem*,const QPoint&
    QConnectionList *clist = receivers("pressed(QIconViewItem*,const QPoint&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    typedef void (QObject::*RT2)(QIconViewItem*,const QPoint&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL doubleClicked
void QIconView::doubleClicked( QIconViewItem* t0 )
{
    // No builtin function for signal parameter type QIconViewItem*
    QConnectionList *clist = receivers("doubleClicked(QIconViewItem*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL returnPressed
void QIconView::returnPressed( QIconViewItem* t0 )
{
    // No builtin function for signal parameter type QIconViewItem*
    QConnectionList *clist = receivers("returnPressed(QIconViewItem*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL rightButtonClicked
void QIconView::rightButtonClicked( QIconViewItem* t0, const QPoint& t1 )
{
    // No builtin function for signal parameter type QIconViewItem*,const QPoint&
    QConnectionList *clist = receivers("rightButtonClicked(QIconViewItem*,const QPoint&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    typedef void (QObject::*RT2)(QIconViewItem*,const QPoint&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL rightButtonPressed
void QIconView::rightButtonPressed( QIconViewItem* t0, const QPoint& t1 )
{
    // No builtin function for signal parameter type QIconViewItem*,const QPoint&
    QConnectionList *clist = receivers("rightButtonPressed(QIconViewItem*,const QPoint&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    typedef void (QObject::*RT2)(QIconViewItem*,const QPoint&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL mouseButtonPressed
void QIconView::mouseButtonPressed( int t0, QIconViewItem* t1, const QPoint& t2 )
{
    // No builtin function for signal parameter type int,QIconViewItem*,const QPoint&
    QConnectionList *clist = receivers("mouseButtonPressed(int,QIconViewItem*,const QPoint&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(int);
    typedef void (QObject::*RT2)(int,QIconViewItem*);
    typedef void (QObject::*RT3)(int,QIconViewItem*,const QPoint&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	    case 3:
#ifdef Q_FP_CCAST_BROKEN
		r3 = reinterpret_cast<RT3>(*(c->member()));
#else
		r3 = (RT3)*(c->member());
#endif
		(object->*r3)(t0, t1, t2);
		break;
	}
    }
}

// SIGNAL mouseButtonClicked
void QIconView::mouseButtonClicked( int t0, QIconViewItem* t1, const QPoint& t2 )
{
    // No builtin function for signal parameter type int,QIconViewItem*,const QPoint&
    QConnectionList *clist = receivers("mouseButtonClicked(int,QIconViewItem*,const QPoint&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(int);
    typedef void (QObject::*RT2)(int,QIconViewItem*);
    typedef void (QObject::*RT3)(int,QIconViewItem*,const QPoint&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    RT3 r3;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	    case 3:
#ifdef Q_FP_CCAST_BROKEN
		r3 = reinterpret_cast<RT3>(*(c->member()));
#else
		r3 = (RT3)*(c->member());
#endif
		(object->*r3)(t0, t1, t2);
		break;
	}
    }
}

// SIGNAL dropped
void QIconView::dropped( QDropEvent* t0, const QValueList<QIconDragItem>& t1 )
{
    // No builtin function for signal parameter type QDropEvent*,const QValueList<QIconDragItem>&
    QConnectionList *clist = receivers("dropped(QDropEvent*,const QValueList<QIconDragItem>&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QDropEvent*);
    typedef void (QObject::*RT2)(QDropEvent*,const QValueList<QIconDragItem>&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL moved
void QIconView::moved()
{
    activate_signal( "moved()" );
}

// SIGNAL onItem
void QIconView::onItem( QIconViewItem* t0 )
{
    // No builtin function for signal parameter type QIconViewItem*
    QConnectionList *clist = receivers("onItem(QIconViewItem*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL onViewport
void QIconView::onViewport()
{
    activate_signal( "onViewport()" );
}

// SIGNAL itemRenamed
void QIconView::itemRenamed( QIconViewItem* t0, const QString& t1 )
{
    // No builtin function for signal parameter type QIconViewItem*,const QString&
    QConnectionList *clist = receivers("itemRenamed(QIconViewItem*,const QString&)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    typedef void (QObject::*RT2)(QIconViewItem*,const QString&);
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	    case 2:
#ifdef Q_FP_CCAST_BROKEN
		r2 = reinterpret_cast<RT2>(*(c->member()));
#else
		r2 = (RT2)*(c->member());
#endif
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL itemRenamed
void QIconView::itemRenamed( QIconViewItem* t0 )
{
    // No builtin function for signal parameter type QIconViewItem*
    QConnectionList *clist = receivers("itemRenamed(QIconViewItem*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QIconViewItem*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}
