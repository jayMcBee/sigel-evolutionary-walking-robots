/****************************************************************************
** QMainWindow meta object code from reading C++ file 'qmainwindow.h'
**
** Created: Wed May 9 12:13:50 2001
**      by: The Qt MOC ($Id: moc_qmainwindow.cpp,v 1.1.1.1 2001/11/20 12:08:26 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qmainwindow.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QMainWindow::className() const
{
    return "QMainWindow";
}

QMetaObject *QMainWindow::metaObj = 0;

void QMainWindow::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("QMainWindow","QWidget");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QMainWindow::tr(const char* s)
{
    return qApp->translate( "QMainWindow", s, 0 );
}

QString QMainWindow::tr(const char* s, const char * c)
{
    return qApp->translate( "QMainWindow", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QMainWindow::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QWidget::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    typedef bool (QMainWindow::*m3_t0)()const;
    typedef bool (QObject::*om3_t0)()const;
    typedef void (QMainWindow::*m3_t1)(bool);
    typedef void (QObject::*om3_t1)(bool);
    typedef bool (QMainWindow::*m3_t3)()const;
    typedef bool (QObject::*om3_t3)()const;
    typedef void (QMainWindow::*m3_t4)(bool);
    typedef void (QObject::*om3_t4)(bool);
    typedef bool (QMainWindow::*m3_t6)()const;
    typedef bool (QObject::*om3_t6)()const;
    typedef void (QMainWindow::*m3_t7)(bool);
    typedef void (QObject::*om3_t7)(bool);
    typedef bool (QMainWindow::*m3_t9)()const;
    typedef bool (QObject::*om3_t9)()const;
    typedef void (QMainWindow::*m3_t10)(bool);
    typedef void (QObject::*om3_t10)(bool);
    typedef bool (QMainWindow::*m3_t12)()const;
    typedef bool (QObject::*om3_t12)()const;
    typedef void (QMainWindow::*m3_t13)(bool);
    typedef void (QObject::*om3_t13)(bool);
    m3_t0 v3_0 = &QMainWindow::rightJustification;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t1 v3_1 = &QMainWindow::setRightJustification;
    om3_t1 ov3_1 = (om3_t1)v3_1;
    m3_t3 v3_3 = &QMainWindow::usesBigPixmaps;
    om3_t3 ov3_3 = (om3_t3)v3_3;
    m3_t4 v3_4 = &QMainWindow::setUsesBigPixmaps;
    om3_t4 ov3_4 = (om3_t4)v3_4;
    m3_t6 v3_6 = &QMainWindow::usesTextLabel;
    om3_t6 ov3_6 = (om3_t6)v3_6;
    m3_t7 v3_7 = &QMainWindow::setUsesTextLabel;
    om3_t7 ov3_7 = (om3_t7)v3_7;
    m3_t9 v3_9 = &QMainWindow::toolBarsMovable;
    om3_t9 ov3_9 = (om3_t9)v3_9;
    m3_t10 v3_10 = &QMainWindow::setToolBarsMovable;
    om3_t10 ov3_10 = (om3_t10)v3_10;
    m3_t12 v3_12 = &QMainWindow::opaqueMoving;
    om3_t12 ov3_12 = (om3_t12)v3_12;
    m3_t13 v3_13 = &QMainWindow::setOpaqueMoving;
    om3_t13 ov3_13 = (om3_t13)v3_13;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 5 );
    props_tbl[0].t = "bool";
    props_tbl[0].n = "rightJustification";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = (QMember)ov3_1;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Class;
    props_tbl[0].setFlags(QMetaProperty::StdSet);
    props_tbl[1].t = "bool";
    props_tbl[1].n = "usesBigPixmaps";
    props_tbl[1].get = (QMember)ov3_3;
    props_tbl[1].set = (QMember)ov3_4;
    props_tbl[1].reset = 0;
    props_tbl[1].gspec = QMetaProperty::Class;
    props_tbl[1].sspec = QMetaProperty::Class;
    props_tbl[1].setFlags(QMetaProperty::StdSet);
    props_tbl[2].t = "bool";
    props_tbl[2].n = "usesTextLabel";
    props_tbl[2].get = (QMember)ov3_6;
    props_tbl[2].set = (QMember)ov3_7;
    props_tbl[2].reset = 0;
    props_tbl[2].gspec = QMetaProperty::Class;
    props_tbl[2].sspec = QMetaProperty::Class;
    props_tbl[2].setFlags(QMetaProperty::StdSet);
    props_tbl[3].t = "bool";
    props_tbl[3].n = "toolBarsMovable";
    props_tbl[3].get = (QMember)ov3_9;
    props_tbl[3].set = (QMember)ov3_10;
    props_tbl[3].reset = 0;
    props_tbl[3].gspec = QMetaProperty::Class;
    props_tbl[3].sspec = QMetaProperty::Class;
    props_tbl[3].setFlags(QMetaProperty::StdSet);
    props_tbl[4].t = "bool";
    props_tbl[4].n = "opaqueMoving";
    props_tbl[4].get = (QMember)ov3_12;
    props_tbl[4].set = (QMember)ov3_13;
    props_tbl[4].reset = 0;
    props_tbl[4].gspec = QMetaProperty::Class;
    props_tbl[4].sspec = QMetaProperty::Class;
    props_tbl[4].setFlags(QMetaProperty::StdSet);
#endif // QT_NO_PROPERTIES
    typedef void (QMainWindow::*m1_t0)(bool);
    typedef void (QObject::*om1_t0)(bool);
    typedef void (QMainWindow::*m1_t1)(bool);
    typedef void (QObject::*om1_t1)(bool);
    typedef void (QMainWindow::*m1_t2)(bool);
    typedef void (QObject::*om1_t2)(bool);
    typedef void (QMainWindow::*m1_t3)(bool);
    typedef void (QObject::*om1_t3)(bool);
    typedef void (QMainWindow::*m1_t4)(bool);
    typedef void (QObject::*om1_t4)(bool);
    typedef void (QMainWindow::*m1_t5)(bool);
    typedef void (QObject::*om1_t5)(bool);
    typedef void (QMainWindow::*m1_t6)();
    typedef void (QObject::*om1_t6)();
    typedef void (QMainWindow::*m1_t7)();
    typedef void (QObject::*om1_t7)();
    m1_t0 v1_0 = &QMainWindow::setRightJustification;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QMainWindow::setUsesBigPixmaps;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QMainWindow::setUsesTextLabel;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QMainWindow::setToolBarsMovable;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QMainWindow::setOpaqueMoving;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QMainWindow::setDockMenuEnabled;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QMainWindow::whatsThis;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QMainWindow::setUpLayout;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    QMetaData *slot_tbl = QMetaObject::new_metadata(8);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(8);
    slot_tbl[0].name = "setRightJustification(bool)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "setUsesBigPixmaps(bool)";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "setUsesTextLabel(bool)";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "setToolBarsMovable(bool)";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "setOpaqueMoving(bool)";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "setDockMenuEnabled(bool)";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "whatsThis()";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Public;
    slot_tbl[7].name = "setUpLayout()";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Protected;
    typedef void (QMainWindow::*m2_t0)(bool);
    typedef void (QObject::*om2_t0)(bool);
    typedef void (QMainWindow::*m2_t1)(bool);
    typedef void (QObject::*om2_t1)(bool);
    typedef void (QMainWindow::*m2_t2)(QToolBar*);
    typedef void (QObject::*om2_t2)(QToolBar*);
    typedef void (QMainWindow::*m2_t3)(QToolBar*);
    typedef void (QObject::*om2_t3)(QToolBar*);
    typedef void (QMainWindow::*m2_t4)(QToolBar*);
    typedef void (QObject::*om2_t4)(QToolBar*);
    m2_t0 v2_0 = &QMainWindow::pixmapSizeChanged;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QMainWindow::usesTextLabelChanged;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    m2_t2 v2_2 = &QMainWindow::startMovingToolBar;
    om2_t2 ov2_2 = (om2_t2)v2_2;
    m2_t3 v2_3 = &QMainWindow::endMovingToolBar;
    om2_t3 ov2_3 = (om2_t3)v2_3;
    m2_t4 v2_4 = &QMainWindow::toolBarPositionChanged;
    om2_t4 ov2_4 = (om2_t4)v2_4;
    QMetaData *signal_tbl = QMetaObject::new_metadata(5);
    signal_tbl[0].name = "pixmapSizeChanged(bool)";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "usesTextLabelChanged(bool)";
    signal_tbl[1].ptr = (QMember)ov2_1;
    signal_tbl[2].name = "startMovingToolBar(QToolBar*)";
    signal_tbl[2].ptr = (QMember)ov2_2;
    signal_tbl[3].name = "endMovingToolBar(QToolBar*)";
    signal_tbl[3].ptr = (QMember)ov2_3;
    signal_tbl[4].name = "toolBarPositionChanged(QToolBar*)";
    signal_tbl[4].ptr = (QMember)ov2_4;
    metaObj = QMetaObject::new_metaobject(
	"QMainWindow", "QWidget",
	slot_tbl, 8,
	signal_tbl, 5,
#ifndef QT_NO_PROPERTIES
	props_tbl, 5,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL pixmapSizeChanged
void QMainWindow::pixmapSizeChanged( bool t0 )
{
    activate_signal_bool( "pixmapSizeChanged(bool)", t0 );
}

// SIGNAL usesTextLabelChanged
void QMainWindow::usesTextLabelChanged( bool t0 )
{
    activate_signal_bool( "usesTextLabelChanged(bool)", t0 );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL startMovingToolBar
void QMainWindow::startMovingToolBar( QToolBar* t0 )
{
    // No builtin function for signal parameter type QToolBar*
    QConnectionList *clist = receivers("startMovingToolBar(QToolBar*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QToolBar*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL endMovingToolBar
void QMainWindow::endMovingToolBar( QToolBar* t0 )
{
    // No builtin function for signal parameter type QToolBar*
    QConnectionList *clist = receivers("endMovingToolBar(QToolBar*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QToolBar*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL toolBarPositionChanged
void QMainWindow::toolBarPositionChanged( QToolBar* t0 )
{
    // No builtin function for signal parameter type QToolBar*
    QConnectionList *clist = receivers("toolBarPositionChanged(QToolBar*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QToolBar*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}
