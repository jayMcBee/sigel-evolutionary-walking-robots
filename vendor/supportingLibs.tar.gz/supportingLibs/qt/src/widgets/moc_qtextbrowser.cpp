/****************************************************************************
** QTextBrowser meta object code from reading C++ file 'qtextbrowser.h'
**
** Created: Wed May 9 12:16:10 2001
**      by: The Qt MOC ($Id: moc_qtextbrowser.cpp,v 1.1.1.1 2001/11/20 12:08:26 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qtextbrowser.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QTextBrowser::className() const
{
    return "QTextBrowser";
}

QMetaObject *QTextBrowser::metaObj = 0;

void QTextBrowser::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QTextView::className(), "QTextView") != 0 )
	badSuperclassWarning("QTextBrowser","QTextView");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QTextBrowser::tr(const char* s)
{
    return qApp->translate( "QTextBrowser", s, 0 );
}

QString QTextBrowser::tr(const char* s, const char * c)
{
    return qApp->translate( "QTextBrowser", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QTextBrowser::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QTextView::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    typedef QString (QTextBrowser::*m3_t0)()const;
    typedef QString (QObject::*om3_t0)()const;
    typedef void (QTextBrowser::*m3_t1)(const QString&);
    typedef void (QObject::*om3_t1)(const QString&);
    m3_t0 v3_0 = &QTextBrowser::source;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t1 v3_1 = &QTextBrowser::setSource;
    om3_t1 ov3_1 = (om3_t1)v3_1;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 1 );
    props_tbl[0].t = "QString";
    props_tbl[0].n = "source";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = (QMember)ov3_1;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Reference;
    props_tbl[0].setFlags(QMetaProperty::StdSet);
#endif // QT_NO_PROPERTIES
    typedef void (QTextBrowser::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QTextBrowser::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    typedef void (QTextBrowser::*m1_t2)();
    typedef void (QObject::*om1_t2)();
    m1_t0 v1_0 = &QTextBrowser::backward;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QTextBrowser::forward;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QTextBrowser::home;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    QMetaData *slot_tbl = QMetaObject::new_metadata(3);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(3);
    slot_tbl[0].name = "backward()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "forward()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "home()";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Public;
    typedef void (QTextBrowser::*m2_t0)(bool);
    typedef void (QObject::*om2_t0)(bool);
    typedef void (QTextBrowser::*m2_t1)(bool);
    typedef void (QObject::*om2_t1)(bool);
    typedef void (QTextBrowser::*m2_t2)(const QString&);
    typedef void (QObject::*om2_t2)(const QString&);
    typedef void (QTextBrowser::*m2_t3)();
    typedef void (QObject::*om2_t3)();
    m2_t0 v2_0 = &QTextBrowser::backwardAvailable;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QTextBrowser::forwardAvailable;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    m2_t2 v2_2 = &QTextBrowser::highlighted;
    om2_t2 ov2_2 = (om2_t2)v2_2;
    m2_t3 v2_3 = &QTextBrowser::textChanged;
    om2_t3 ov2_3 = (om2_t3)v2_3;
    QMetaData *signal_tbl = QMetaObject::new_metadata(4);
    signal_tbl[0].name = "backwardAvailable(bool)";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "forwardAvailable(bool)";
    signal_tbl[1].ptr = (QMember)ov2_1;
    signal_tbl[2].name = "highlighted(const QString&)";
    signal_tbl[2].ptr = (QMember)ov2_2;
    signal_tbl[3].name = "textChanged()";
    signal_tbl[3].ptr = (QMember)ov2_3;
    metaObj = QMetaObject::new_metaobject(
	"QTextBrowser", "QTextView",
	slot_tbl, 3,
	signal_tbl, 4,
#ifndef QT_NO_PROPERTIES
	props_tbl, 1,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL backwardAvailable
void QTextBrowser::backwardAvailable( bool t0 )
{
    activate_signal_bool( "backwardAvailable(bool)", t0 );
}

// SIGNAL forwardAvailable
void QTextBrowser::forwardAvailable( bool t0 )
{
    activate_signal_bool( "forwardAvailable(bool)", t0 );
}

// SIGNAL highlighted
void QTextBrowser::highlighted( const QString& t0 )
{
    activate_signal_strref( "highlighted(const QString&)", t0 );
}

// SIGNAL textChanged
void QTextBrowser::textChanged()
{
    activate_signal( "textChanged()" );
}
