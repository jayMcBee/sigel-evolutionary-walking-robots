/****************************************************************************
** QValidator meta object code from reading C++ file 'qvalidator.h'
**
** Created: Wed May 9 12:16:46 2001
**      by: The Qt MOC ($Id: moc_qvalidator.cpp,v 1.1.1.1 2001/11/20 12:08:26 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qvalidator.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QValidator::className() const
{
    return "QValidator";
}

QMetaObject *QValidator::metaObj = 0;

void QValidator::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QObject::className(), "QObject") != 0 )
	badSuperclassWarning("QValidator","QObject");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QValidator::tr(const char* s)
{
    return qApp->translate( "QValidator", s, 0 );
}

QString QValidator::tr(const char* s, const char * c)
{
    return qApp->translate( "QValidator", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QValidator::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QObject::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    QMetaData::Access *slot_tbl_access = 0;
    metaObj = QMetaObject::new_metaobject(
	"QValidator", "QObject",
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}


const char *QIntValidator::className() const
{
    return "QIntValidator";
}

QMetaObject *QIntValidator::metaObj = 0;

void QIntValidator::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QValidator::className(), "QValidator") != 0 )
	badSuperclassWarning("QIntValidator","QValidator");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QIntValidator::tr(const char* s)
{
    return qApp->translate( "QIntValidator", s, 0 );
}

QString QIntValidator::tr(const char* s, const char * c)
{
    return qApp->translate( "QIntValidator", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QIntValidator::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QValidator::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    typedef int (QIntValidator::*m3_t0)()const;
    typedef int (QObject::*om3_t0)()const;
    typedef void (QIntValidator::*m3_t1)(int);
    typedef void (QObject::*om3_t1)(int);
    typedef int (QIntValidator::*m3_t3)()const;
    typedef int (QObject::*om3_t3)()const;
    typedef void (QIntValidator::*m3_t4)(int);
    typedef void (QObject::*om3_t4)(int);
    m3_t0 v3_0 = &QIntValidator::bottom;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t1 v3_1 = &QIntValidator::setBottom;
    om3_t1 ov3_1 = (om3_t1)v3_1;
    m3_t3 v3_3 = &QIntValidator::top;
    om3_t3 ov3_3 = (om3_t3)v3_3;
    m3_t4 v3_4 = &QIntValidator::setTop;
    om3_t4 ov3_4 = (om3_t4)v3_4;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 2 );
    props_tbl[0].t = "int";
    props_tbl[0].n = "bottom";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = (QMember)ov3_1;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Class;
    props_tbl[0].setFlags(QMetaProperty::StdSet);
    props_tbl[1].t = "int";
    props_tbl[1].n = "top";
    props_tbl[1].get = (QMember)ov3_3;
    props_tbl[1].set = (QMember)ov3_4;
    props_tbl[1].reset = 0;
    props_tbl[1].gspec = QMetaProperty::Class;
    props_tbl[1].sspec = QMetaProperty::Class;
    props_tbl[1].setFlags(QMetaProperty::StdSet);
#endif // QT_NO_PROPERTIES
    QMetaData::Access *slot_tbl_access = 0;
    metaObj = QMetaObject::new_metaobject(
	"QIntValidator", "QValidator",
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	props_tbl, 2,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}


const char *QDoubleValidator::className() const
{
    return "QDoubleValidator";
}

QMetaObject *QDoubleValidator::metaObj = 0;

void QDoubleValidator::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QValidator::className(), "QValidator") != 0 )
	badSuperclassWarning("QDoubleValidator","QValidator");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QDoubleValidator::tr(const char* s)
{
    return qApp->translate( "QDoubleValidator", s, 0 );
}

QString QDoubleValidator::tr(const char* s, const char * c)
{
    return qApp->translate( "QDoubleValidator", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QDoubleValidator::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QValidator::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    typedef double (QDoubleValidator::*m3_t0)()const;
    typedef double (QObject::*om3_t0)()const;
    typedef void (QDoubleValidator::*m3_t1)(double);
    typedef void (QObject::*om3_t1)(double);
    typedef double (QDoubleValidator::*m3_t3)()const;
    typedef double (QObject::*om3_t3)()const;
    typedef void (QDoubleValidator::*m3_t4)(double);
    typedef void (QObject::*om3_t4)(double);
    typedef int (QDoubleValidator::*m3_t6)()const;
    typedef int (QObject::*om3_t6)()const;
    typedef void (QDoubleValidator::*m3_t7)(int);
    typedef void (QObject::*om3_t7)(int);
    m3_t0 v3_0 = &QDoubleValidator::bottom;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t1 v3_1 = &QDoubleValidator::setBottom;
    om3_t1 ov3_1 = (om3_t1)v3_1;
    m3_t3 v3_3 = &QDoubleValidator::top;
    om3_t3 ov3_3 = (om3_t3)v3_3;
    m3_t4 v3_4 = &QDoubleValidator::setTop;
    om3_t4 ov3_4 = (om3_t4)v3_4;
    m3_t6 v3_6 = &QDoubleValidator::decimals;
    om3_t6 ov3_6 = (om3_t6)v3_6;
    m3_t7 v3_7 = &QDoubleValidator::setDecimals;
    om3_t7 ov3_7 = (om3_t7)v3_7;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 3 );
    props_tbl[0].t = "double";
    props_tbl[0].n = "bottom";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = (QMember)ov3_1;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Class;
    props_tbl[0].setFlags(QMetaProperty::StdSet);
    props_tbl[1].t = "double";
    props_tbl[1].n = "top";
    props_tbl[1].get = (QMember)ov3_3;
    props_tbl[1].set = (QMember)ov3_4;
    props_tbl[1].reset = 0;
    props_tbl[1].gspec = QMetaProperty::Class;
    props_tbl[1].sspec = QMetaProperty::Class;
    props_tbl[1].setFlags(QMetaProperty::StdSet);
    props_tbl[2].t = "int";
    props_tbl[2].n = "decimals";
    props_tbl[2].get = (QMember)ov3_6;
    props_tbl[2].set = (QMember)ov3_7;
    props_tbl[2].reset = 0;
    props_tbl[2].gspec = QMetaProperty::Class;
    props_tbl[2].sspec = QMetaProperty::Class;
    props_tbl[2].setFlags(QMetaProperty::StdSet);
#endif // QT_NO_PROPERTIES
    QMetaData::Access *slot_tbl_access = 0;
    metaObj = QMetaObject::new_metaobject(
	"QDoubleValidator", "QValidator",
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	props_tbl, 3,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
