/****************************************************************************
** QLineEdit meta object code from reading C++ file 'qlineedit.h'
**
** Created: Wed May 9 12:13:09 2001
**      by: The Qt MOC ($Id: moc_qlineedit.cpp,v 1.1.1.1 2001/11/20 12:08:26 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qlineedit.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QLineEdit::className() const
{
    return "QLineEdit";
}

QMetaObject *QLineEdit::metaObj = 0;

void QLineEdit::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("QLineEdit","QWidget");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QLineEdit::tr(const char* s)
{
    return qApp->translate( "QLineEdit", s, 0 );
}

QString QLineEdit::tr(const char* s, const char * c)
{
    return qApp->translate( "QLineEdit", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QLineEdit::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QWidget::staticMetaObject();
#ifndef QT_NO_PROPERTIES
    QMetaEnum* enum_tbl = QMetaObject::new_metaenum( 1 );
    enum_tbl[0].name = "EchoMode";
    enum_tbl[0].count = 3;
    enum_tbl[0].items = QMetaObject::new_metaenum_item( 3 );
    enum_tbl[0].set = FALSE;
    enum_tbl[0].items[0].key = "Normal";
    enum_tbl[0].items[0].value = (int) QLineEdit::Normal;
    enum_tbl[0].items[1].key = "NoEcho";
    enum_tbl[0].items[1].value = (int) QLineEdit::NoEcho;
    enum_tbl[0].items[2].key = "Password";
    enum_tbl[0].items[2].value = (int) QLineEdit::Password;
#endif // QT_NO_PROPERTIES
#ifndef QT_NO_PROPERTIES
    typedef QString (QLineEdit::*m3_t0)()const;
    typedef QString (QObject::*om3_t0)()const;
    typedef void (QLineEdit::*m3_t1)(const QString&);
    typedef void (QObject::*om3_t1)(const QString&);
    typedef int (QLineEdit::*m3_t3)()const;
    typedef int (QObject::*om3_t3)()const;
    typedef void (QLineEdit::*m3_t4)(int);
    typedef void (QObject::*om3_t4)(int);
    typedef bool (QLineEdit::*m3_t6)()const;
    typedef bool (QObject::*om3_t6)()const;
    typedef void (QLineEdit::*m3_t7)(bool);
    typedef void (QObject::*om3_t7)(bool);
    typedef EchoMode (QLineEdit::*m3_t9)()const;
    typedef EchoMode (QObject::*om3_t9)()const;
    typedef void (QLineEdit::*m3_t10)(EchoMode);
    typedef void (QObject::*om3_t10)(EchoMode);
    typedef QString (QLineEdit::*m3_t12)()const;
    typedef QString (QObject::*om3_t12)()const;
    typedef int (QLineEdit::*m3_t15)()const;
    typedef int (QObject::*om3_t15)()const;
    typedef void (QLineEdit::*m3_t16)(int);
    typedef void (QObject::*om3_t16)(int);
    typedef int (QLineEdit::*m3_t18)()const;
    typedef int (QObject::*om3_t18)()const;
    typedef void (QLineEdit::*m3_t19)(int);
    typedef void (QObject::*om3_t19)(int);
    typedef bool (QLineEdit::*m3_t21)()const;
    typedef bool (QObject::*om3_t21)()const;
    typedef void (QLineEdit::*m3_t22)(bool);
    typedef void (QObject::*om3_t22)(bool);
    typedef bool (QLineEdit::*m3_t24)()const;
    typedef bool (QObject::*om3_t24)()const;
    typedef QString (QLineEdit::*m3_t27)()const;
    typedef QString (QObject::*om3_t27)()const;
    m3_t0 v3_0 = &QLineEdit::text;
    om3_t0 ov3_0 = (om3_t0)v3_0;
    m3_t1 v3_1 = &QLineEdit::setText;
    om3_t1 ov3_1 = (om3_t1)v3_1;
    m3_t3 v3_3 = &QLineEdit::maxLength;
    om3_t3 ov3_3 = (om3_t3)v3_3;
    m3_t4 v3_4 = &QLineEdit::setMaxLength;
    om3_t4 ov3_4 = (om3_t4)v3_4;
    m3_t6 v3_6 = &QLineEdit::frame;
    om3_t6 ov3_6 = (om3_t6)v3_6;
    m3_t7 v3_7 = &QLineEdit::setFrame;
    om3_t7 ov3_7 = (om3_t7)v3_7;
    m3_t9 v3_9 = &QLineEdit::echoMode;
    om3_t9 ov3_9 = (om3_t9)v3_9;
    m3_t10 v3_10 = &QLineEdit::setEchoMode;
    om3_t10 ov3_10 = (om3_t10)v3_10;
    m3_t12 v3_12 = &QLineEdit::displayText;
    om3_t12 ov3_12 = (om3_t12)v3_12;
    m3_t15 v3_15 = &QLineEdit::cursorPosition;
    om3_t15 ov3_15 = (om3_t15)v3_15;
    m3_t16 v3_16 = &QLineEdit::setCursorPosition;
    om3_t16 ov3_16 = (om3_t16)v3_16;
    m3_t18 v3_18 = &QLineEdit::alignment;
    om3_t18 ov3_18 = (om3_t18)v3_18;
    m3_t19 v3_19 = &QLineEdit::setAlignment;
    om3_t19 ov3_19 = (om3_t19)v3_19;
    m3_t21 v3_21 = &QLineEdit::edited;
    om3_t21 ov3_21 = (om3_t21)v3_21;
    m3_t22 v3_22 = &QLineEdit::setEdited;
    om3_t22 ov3_22 = (om3_t22)v3_22;
    m3_t24 v3_24 = &QLineEdit::hasMarkedText;
    om3_t24 ov3_24 = (om3_t24)v3_24;
    m3_t27 v3_27 = &QLineEdit::markedText;
    om3_t27 ov3_27 = (om3_t27)v3_27;
    QMetaProperty *props_tbl = QMetaObject::new_metaproperty( 10 );
    props_tbl[0].t = "QString";
    props_tbl[0].n = "text";
    props_tbl[0].get = (QMember)ov3_0;
    props_tbl[0].set = (QMember)ov3_1;
    props_tbl[0].reset = 0;
    props_tbl[0].gspec = QMetaProperty::Class;
    props_tbl[0].sspec = QMetaProperty::Reference;
    props_tbl[0].setFlags(QMetaProperty::StdSet);
    props_tbl[1].t = "int";
    props_tbl[1].n = "maxLength";
    props_tbl[1].get = (QMember)ov3_3;
    props_tbl[1].set = (QMember)ov3_4;
    props_tbl[1].reset = 0;
    props_tbl[1].gspec = QMetaProperty::Class;
    props_tbl[1].sspec = QMetaProperty::Class;
    props_tbl[1].setFlags(QMetaProperty::StdSet);
    props_tbl[2].t = "bool";
    props_tbl[2].n = "frame";
    props_tbl[2].get = (QMember)ov3_6;
    props_tbl[2].set = (QMember)ov3_7;
    props_tbl[2].reset = 0;
    props_tbl[2].gspec = QMetaProperty::Class;
    props_tbl[2].sspec = QMetaProperty::Class;
    props_tbl[2].setFlags(QMetaProperty::StdSet);
    props_tbl[3].t = "EchoMode";
    props_tbl[3].n = "echoMode";
    props_tbl[3].get = (QMember)ov3_9;
    props_tbl[3].set = (QMember)ov3_10;
    props_tbl[3].reset = 0;
    props_tbl[3].gspec = QMetaProperty::Class;
    props_tbl[3].sspec = QMetaProperty::Class;
    props_tbl[3].enumData = &enum_tbl[0];
    props_tbl[3].setFlags(QMetaProperty::StdSet);
    props_tbl[4].t = "QString";
    props_tbl[4].n = "displayText";
    props_tbl[4].get = (QMember)ov3_12;
    props_tbl[4].set = 0;
    props_tbl[4].reset = 0;
    props_tbl[4].gspec = QMetaProperty::Class;
    props_tbl[4].sspec = QMetaProperty::Unspecified;
    props_tbl[5].t = "int";
    props_tbl[5].n = "cursorPosition";
    props_tbl[5].get = (QMember)ov3_15;
    props_tbl[5].set = (QMember)ov3_16;
    props_tbl[5].reset = 0;
    props_tbl[5].gspec = QMetaProperty::Class;
    props_tbl[5].sspec = QMetaProperty::Class;
    props_tbl[5].setFlags(QMetaProperty::StdSet);
    props_tbl[6].t = "Alignment";
    props_tbl[6].n = "alignment";
    props_tbl[6].get = (QMember)ov3_18;
    props_tbl[6].set = (QMember)ov3_19;
    props_tbl[6].reset = 0;
    props_tbl[6].gspec = QMetaProperty::Class;
    props_tbl[6].sspec = QMetaProperty::Class;
    props_tbl[6].setFlags(QMetaProperty::UnresolvedSet|QMetaProperty::StdSet);
    props_tbl[7].t = "bool";
    props_tbl[7].n = "edited";
    props_tbl[7].get = (QMember)ov3_21;
    props_tbl[7].set = (QMember)ov3_22;
    props_tbl[7].reset = 0;
    props_tbl[7].gspec = QMetaProperty::Class;
    props_tbl[7].sspec = QMetaProperty::Class;
    props_tbl[7].setFlags(QMetaProperty::StdSet);
    props_tbl[8].t = "bool";
    props_tbl[8].n = "hasMarkedText";
    props_tbl[8].get = (QMember)ov3_24;
    props_tbl[8].set = 0;
    props_tbl[8].reset = 0;
    props_tbl[8].gspec = QMetaProperty::Class;
    props_tbl[8].sspec = QMetaProperty::Unspecified;
    props_tbl[9].t = "QString";
    props_tbl[9].n = "markedText";
    props_tbl[9].get = (QMember)ov3_27;
    props_tbl[9].set = 0;
    props_tbl[9].reset = 0;
    props_tbl[9].gspec = QMetaProperty::Class;
    props_tbl[9].sspec = QMetaProperty::Unspecified;
#endif // QT_NO_PROPERTIES
    typedef void (QLineEdit::*m1_t0)(const QString&);
    typedef void (QObject::*om1_t0)(const QString&);
    typedef void (QLineEdit::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    typedef void (QLineEdit::*m1_t2)();
    typedef void (QObject::*om1_t2)();
    typedef void (QLineEdit::*m1_t3)();
    typedef void (QObject::*om1_t3)();
    typedef void (QLineEdit::*m1_t4)(const QString&);
    typedef void (QObject::*om1_t4)(const QString&);
    typedef void (QLineEdit::*m1_t5)();
    typedef void (QObject::*om1_t5)();
    typedef void (QLineEdit::*m1_t6)();
    typedef void (QObject::*om1_t6)();
    typedef void (QLineEdit::*m1_t7)();
    typedef void (QObject::*om1_t7)();
    typedef void (QLineEdit::*m1_t8)();
    typedef void (QObject::*om1_t8)();
    typedef void (QLineEdit::*m1_t9)();
    typedef void (QObject::*om1_t9)();
    m1_t0 v1_0 = &QLineEdit::setText;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QLineEdit::selectAll;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QLineEdit::deselect;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QLineEdit::clearValidator;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QLineEdit::insert;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QLineEdit::clear;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QLineEdit::clipboardChanged;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QLineEdit::blinkSlot;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    m1_t8 v1_8 = &QLineEdit::dragScrollSlot;
    om1_t8 ov1_8 = (om1_t8)v1_8;
    m1_t9 v1_9 = &QLineEdit::doDrag;
    om1_t9 ov1_9 = (om1_t9)v1_9;
    QMetaData *slot_tbl = QMetaObject::new_metadata(10);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(10);
    slot_tbl[0].name = "setText(const QString&)";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "selectAll()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "deselect()";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Public;
    slot_tbl[3].name = "clearValidator()";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Public;
    slot_tbl[4].name = "insert(const QString&)";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Public;
    slot_tbl[5].name = "clear()";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Public;
    slot_tbl[6].name = "clipboardChanged()";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Private;
    slot_tbl[7].name = "blinkSlot()";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Private;
    slot_tbl[8].name = "dragScrollSlot()";
    slot_tbl[8].ptr = (QMember)ov1_8;
    slot_tbl_access[8] = QMetaData::Private;
    slot_tbl[9].name = "doDrag()";
    slot_tbl[9].ptr = (QMember)ov1_9;
    slot_tbl_access[9] = QMetaData::Private;
    typedef void (QLineEdit::*m2_t0)(const QString&);
    typedef void (QObject::*om2_t0)(const QString&);
    typedef void (QLineEdit::*m2_t1)();
    typedef void (QObject::*om2_t1)();
    m2_t0 v2_0 = &QLineEdit::textChanged;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    m2_t1 v2_1 = &QLineEdit::returnPressed;
    om2_t1 ov2_1 = (om2_t1)v2_1;
    QMetaData *signal_tbl = QMetaObject::new_metadata(2);
    signal_tbl[0].name = "textChanged(const QString&)";
    signal_tbl[0].ptr = (QMember)ov2_0;
    signal_tbl[1].name = "returnPressed()";
    signal_tbl[1].ptr = (QMember)ov2_1;
    metaObj = QMetaObject::new_metaobject(
	"QLineEdit", "QWidget",
	slot_tbl, 10,
	signal_tbl, 2,
#ifndef QT_NO_PROPERTIES
	props_tbl, 10,
	enum_tbl, 1,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
    metaObj->resolveProperty( &props_tbl[6] );
#endif // QT_NO_PROPERTIES
    return metaObj;
}

// SIGNAL textChanged
void QLineEdit::textChanged( const QString& t0 )
{
    activate_signal_strref( "textChanged(const QString&)", t0 );
}

// SIGNAL returnPressed
void QLineEdit::returnPressed()
{
    activate_signal( "returnPressed()" );
}
