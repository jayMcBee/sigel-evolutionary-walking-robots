/****************************************************************************
** QPlatinumStyle meta object code from reading C++ file 'qplatinumstyle.h'
**
** Created: Wed May 9 12:14:28 2001
**      by: The Qt MOC ($Id: moc_qplatinumstyle.cpp,v 1.1.1.1 2001/11/20 12:08:26 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qplatinumstyle.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QPlatinumStyle::className() const
{
    return "QPlatinumStyle";
}

QMetaObject *QPlatinumStyle::metaObj = 0;

void QPlatinumStyle::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QWindowsStyle::className(), "QWindowsStyle") != 0 )
	badSuperclassWarning("QPlatinumStyle","QWindowsStyle");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QPlatinumStyle::tr(const char* s)
{
    return qApp->translate( "QPlatinumStyle", s, 0 );
}

QString QPlatinumStyle::tr(const char* s, const char * c)
{
    return qApp->translate( "QPlatinumStyle", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QPlatinumStyle::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QWindowsStyle::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    QMetaData::Access *slot_tbl_access = 0;
    metaObj = QMetaObject::new_metaobject(
	"QPlatinumStyle", "QWindowsStyle",
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
