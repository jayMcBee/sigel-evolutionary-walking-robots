/****************************************************************************
** $Id: qdatetm.h,v 1.1.1.1 2001/11/20 12:08:17 root Exp $
**
** Compatibility file - should only be included by legacy code.
** It #includes the file which obsoletes this one.
**
** Copyright (C) 1998-2000 Trolltech AS.  All rights reserved.
**  This file is part of the Qt GUI Toolkit.
**
** This file may be distributed under the terms of the Q Public License
** as defined by Trolltech AS of Norway and appearing in the file
** LICENSE.QPL included in the packaging of this file.
**
** Licensees holding valid Qt Professional Edition licenses may use this
** file in accordance with the Qt Professional Edition License Agreement
** provided with the Qt Professional Edition.
**
** See http://www.trolltech.com/pricing.html or email sales@trolltech.com for
** information about the Professional Edition licensing, or see
** http://www.trolltech.com/qpl/ for QPL licensing information.
**
*****************************************************************************/
#ifndef QDATETM_H
#define QDATETM_H
#include "qdatetime.h"
#endif
