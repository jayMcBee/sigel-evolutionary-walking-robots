/****************************************************************************
** QGLWidget meta object code from reading C++ file 'qgl.h'
**
** Created: Wed May 9 12:29:48 2001
**      by: The Qt MOC ($Id: moc_qgl.cpp,v 1.1.1.1 2001/11/20 12:08:21 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qgl.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QGLWidget::className() const
{
    return "QGLWidget";
}

QMetaObject *QGLWidget::metaObj = 0;

void QGLWidget::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("QGLWidget","QWidget");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QGLWidget::tr(const char* s)
{
    return qApp->translate( "QGLWidget", s, 0 );
}

QString QGLWidget::tr(const char* s, const char * c)
{
    return qApp->translate( "QGLWidget", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QGLWidget::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QWidget::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QGLWidget::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QGLWidget::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    m1_t0 v1_0 = &QGLWidget::updateGL;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QGLWidget::updateOverlayGL;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    QMetaData *slot_tbl = QMetaObject::new_metadata(2);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(2);
    slot_tbl[0].name = "updateGL()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "updateOverlayGL()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    metaObj = QMetaObject::new_metaobject(
	"QGLWidget", "QWidget",
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}
