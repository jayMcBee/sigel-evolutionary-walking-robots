/****************************************************************************
** QWorkspace meta object code from reading C++ file 'qworkspace.h'
**
** Created: Wed May 9 12:23:52 2001
**      by: The Qt MOC ($Id: moc_qworkspace.cpp,v 1.1.1.1 2001/11/20 12:08:26 root Exp $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 9
#elif Q_MOC_OUTPUT_REVISION != 9
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "qworkspace.h"
#include <qmetaobject.h>
#include <qapplication.h>



const char *QWorkspace::className() const
{
    return "QWorkspace";
}

QMetaObject *QWorkspace::metaObj = 0;

void QWorkspace::initMetaObject()
{
    if ( metaObj )
	return;
    if ( qstrcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("QWorkspace","QWidget");
    (void) staticMetaObject();
}

#ifndef QT_NO_TRANSLATION

QString QWorkspace::tr(const char* s)
{
    return qApp->translate( "QWorkspace", s, 0 );
}

QString QWorkspace::tr(const char* s, const char * c)
{
    return qApp->translate( "QWorkspace", s, c );
}

#endif // QT_NO_TRANSLATION

QMetaObject* QWorkspace::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    (void) QWidget::staticMetaObject();
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    typedef void (QWorkspace::*m1_t0)();
    typedef void (QObject::*om1_t0)();
    typedef void (QWorkspace::*m1_t1)();
    typedef void (QObject::*om1_t1)();
    typedef void (QWorkspace::*m1_t2)();
    typedef void (QObject::*om1_t2)();
    typedef void (QWorkspace::*m1_t3)();
    typedef void (QObject::*om1_t3)();
    typedef void (QWorkspace::*m1_t4)();
    typedef void (QObject::*om1_t4)();
    typedef void (QWorkspace::*m1_t5)();
    typedef void (QObject::*om1_t5)();
    typedef void (QWorkspace::*m1_t6)();
    typedef void (QObject::*om1_t6)();
    typedef void (QWorkspace::*m1_t7)(const QPoint&);
    typedef void (QObject::*om1_t7)(const QPoint&);
    typedef void (QWorkspace::*m1_t8)(int);
    typedef void (QObject::*om1_t8)(int);
    typedef void (QWorkspace::*m1_t9)();
    typedef void (QObject::*om1_t9)();
    typedef void (QWorkspace::*m1_t10)();
    typedef void (QObject::*om1_t10)();
    typedef void (QWorkspace::*m1_t11)();
    typedef void (QObject::*om1_t11)();
    typedef void (QWorkspace::*m1_t12)();
    typedef void (QObject::*om1_t12)();
    m1_t0 v1_0 = &QWorkspace::cascade;
    om1_t0 ov1_0 = (om1_t0)v1_0;
    m1_t1 v1_1 = &QWorkspace::tile;
    om1_t1 ov1_1 = (om1_t1)v1_1;
    m1_t2 v1_2 = &QWorkspace::closeActiveWindow;
    om1_t2 ov1_2 = (om1_t2)v1_2;
    m1_t3 v1_3 = &QWorkspace::closeAllWindows;
    om1_t3 ov1_3 = (om1_t3)v1_3;
    m1_t4 v1_4 = &QWorkspace::normalizeActiveWindow;
    om1_t4 ov1_4 = (om1_t4)v1_4;
    m1_t5 v1_5 = &QWorkspace::minimizeActiveWindow;
    om1_t5 ov1_5 = (om1_t5)v1_5;
    m1_t6 v1_6 = &QWorkspace::showOperationMenu;
    om1_t6 ov1_6 = (om1_t6)v1_6;
    m1_t7 v1_7 = &QWorkspace::popupOperationMenu;
    om1_t7 ov1_7 = (om1_t7)v1_7;
    m1_t8 v1_8 = &QWorkspace::operationMenuActivated;
    om1_t8 ov1_8 = (om1_t8)v1_8;
    m1_t9 v1_9 = &QWorkspace::operationMenuAboutToShow;
    om1_t9 ov1_9 = (om1_t9)v1_9;
    m1_t10 v1_10 = &QWorkspace::toolMenuAboutToShow;
    om1_t10 ov1_10 = (om1_t10)v1_10;
    m1_t11 v1_11 = &QWorkspace::activateNextWindow;
    om1_t11 ov1_11 = (om1_t11)v1_11;
    m1_t12 v1_12 = &QWorkspace::activatePreviousWindow;
    om1_t12 ov1_12 = (om1_t12)v1_12;
    QMetaData *slot_tbl = QMetaObject::new_metadata(13);
    QMetaData::Access *slot_tbl_access = QMetaObject::new_metaaccess(13);
    slot_tbl[0].name = "cascade()";
    slot_tbl[0].ptr = (QMember)ov1_0;
    slot_tbl_access[0] = QMetaData::Public;
    slot_tbl[1].name = "tile()";
    slot_tbl[1].ptr = (QMember)ov1_1;
    slot_tbl_access[1] = QMetaData::Public;
    slot_tbl[2].name = "closeActiveWindow()";
    slot_tbl[2].ptr = (QMember)ov1_2;
    slot_tbl_access[2] = QMetaData::Private;
    slot_tbl[3].name = "closeAllWindows()";
    slot_tbl[3].ptr = (QMember)ov1_3;
    slot_tbl_access[3] = QMetaData::Private;
    slot_tbl[4].name = "normalizeActiveWindow()";
    slot_tbl[4].ptr = (QMember)ov1_4;
    slot_tbl_access[4] = QMetaData::Private;
    slot_tbl[5].name = "minimizeActiveWindow()";
    slot_tbl[5].ptr = (QMember)ov1_5;
    slot_tbl_access[5] = QMetaData::Private;
    slot_tbl[6].name = "showOperationMenu()";
    slot_tbl[6].ptr = (QMember)ov1_6;
    slot_tbl_access[6] = QMetaData::Private;
    slot_tbl[7].name = "popupOperationMenu(const QPoint&)";
    slot_tbl[7].ptr = (QMember)ov1_7;
    slot_tbl_access[7] = QMetaData::Private;
    slot_tbl[8].name = "operationMenuActivated(int)";
    slot_tbl[8].ptr = (QMember)ov1_8;
    slot_tbl_access[8] = QMetaData::Private;
    slot_tbl[9].name = "operationMenuAboutToShow()";
    slot_tbl[9].ptr = (QMember)ov1_9;
    slot_tbl_access[9] = QMetaData::Private;
    slot_tbl[10].name = "toolMenuAboutToShow()";
    slot_tbl[10].ptr = (QMember)ov1_10;
    slot_tbl_access[10] = QMetaData::Private;
    slot_tbl[11].name = "activateNextWindow()";
    slot_tbl[11].ptr = (QMember)ov1_11;
    slot_tbl_access[11] = QMetaData::Private;
    slot_tbl[12].name = "activatePreviousWindow()";
    slot_tbl[12].ptr = (QMember)ov1_12;
    slot_tbl_access[12] = QMetaData::Private;
    typedef void (QWorkspace::*m2_t0)(QWidget*);
    typedef void (QObject::*om2_t0)(QWidget*);
    m2_t0 v2_0 = &QWorkspace::windowActivated;
    om2_t0 ov2_0 = (om2_t0)v2_0;
    QMetaData *signal_tbl = QMetaObject::new_metadata(1);
    signal_tbl[0].name = "windowActivated(QWidget*)";
    signal_tbl[0].ptr = (QMember)ov2_0;
    metaObj = QMetaObject::new_metaobject(
	"QWorkspace", "QWidget",
	slot_tbl, 13,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    metaObj->set_slot_access( slot_tbl_access );
#ifndef QT_NO_PROPERTIES
#endif // QT_NO_PROPERTIES
    return metaObj;
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL windowActivated
void QWorkspace::windowActivated( QWidget* t0 )
{
    // No builtin function for signal parameter type QWidget*
    QConnectionList *clist = receivers("windowActivated(QWidget*)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef void (QObject::*RT1)(QWidget*);
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
#ifdef Q_FP_CCAST_BROKEN
		r0 = reinterpret_cast<RT0>(*(c->member()));
#else
		r0 = (RT0)*(c->member());
#endif
		(object->*r0)();
		break;
	    case 1:
#ifdef Q_FP_CCAST_BROKEN
		r1 = reinterpret_cast<RT1>(*(c->member()));
#else
		r1 = (RT1)*(c->member());
#endif
		(object->*r1)(t0);
		break;
	}
    }
}
