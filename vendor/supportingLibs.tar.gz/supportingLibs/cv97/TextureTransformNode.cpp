/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	Node.cpp
*
******************************************************************/

#include "TextureTransformNode.h"

TextureTransformNode::TextureTransformNode() 
{
	setHeaderFlag(false);
	setType(textureTransformNodeString);

	// translation exposed field
	SFVec2f *translation = new SFVec2f(0.0f, 0.0f);
	translation->setName(translationFieldString);
	addExposedField(translation);

	// scale exposed field
	SFVec2f *scale = new SFVec2f(1.0f, 1.0f);
	scale->setName(scaleFieldString);
	addExposedField(scale);

	// center exposed field
	SFVec2f *center = new SFVec2f(0.0f, 0.0f);
	center->setName(centerFieldString);
	addExposedField(center);

	// rotation exposed field
	SFFloat *rotation = new SFFloat(0.0f);
	rotation->setName(rotationFieldString);
	addExposedField(rotation);
}

TextureTransformNode::~TextureTransformNode() 
{
}

////////////////////////////////////////////////
//	Translation
////////////////////////////////////////////////

void TextureTransformNode::setTranslation(float value[]) 
{
	SFVec2f *translation = (SFVec2f *)getExposedField(translationFieldString);
	translation->setValue(value);
}

void TextureTransformNode::setTranslation(float x, float y) 
{
	SFVec2f *translation = (SFVec2f *)getExposedField(translationFieldString);
	translation->setValue(x, y);
}

void TextureTransformNode::getTranslation(float value[]) 
{
	SFVec2f *translation = (SFVec2f *)getExposedField(translationFieldString);
	translation->getValue(value);
}

////////////////////////////////////////////////
//	Scale
////////////////////////////////////////////////

void TextureTransformNode::setScale(float value[]) 
{
	SFVec2f *scale = (SFVec2f *)getExposedField(scaleFieldString);
	scale->setValue(value);
}

void TextureTransformNode::setScale(float x, float y) 
{
	SFVec2f *scale = (SFVec2f *)getExposedField(scaleFieldString);
	scale->setValue(x, y);
}

void TextureTransformNode::getScale(float value[]) 
{
	SFVec2f *scale = (SFVec2f *)getExposedField(scaleFieldString);
	scale->getValue(value);
}

////////////////////////////////////////////////
//	Center
////////////////////////////////////////////////

void TextureTransformNode::setCenter(float value[]) 
{
	SFVec2f *center = (SFVec2f *)getExposedField(centerFieldString);
	center->setValue(value);
}

void TextureTransformNode::setCenter(float x, float y) 
{
	SFVec2f *center = (SFVec2f *)getExposedField(centerFieldString);
	center->setValue(x, y);
}

void TextureTransformNode::getCenter(float value[]) 
{
	SFVec2f *center = (SFVec2f *)getExposedField(centerFieldString);
	center->getValue(value);
}

////////////////////////////////////////////////
//	Rotation
////////////////////////////////////////////////

void TextureTransformNode::setRotation(float value) 
{
	SFFloat *rotation = (SFFloat *)getExposedField(rotationFieldString);
	rotation->setValue(value);
}

float TextureTransformNode::getRotation() 
{
	SFFloat *rotation = (SFFloat *)getExposedField(rotationFieldString);
	return rotation->getValue();
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

TextureTransformNode *TextureTransformNode::next() 
{
	return (TextureTransformNode *)Node::next(getType());
}

TextureTransformNode *TextureTransformNode::nextTraversal() 
{
	return (TextureTransformNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool TextureTransformNode::isChildNodeType(Node *node)
{
	return false;
}

void TextureTransformNode::initialize() 
{
}

void TextureTransformNode::uninitialize() 
{
}

void TextureTransformNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void TextureTransformNode::outputContext(ostream &printStream, String indentString) 
{
	SFVec2f *translation = (SFVec2f *)getExposedField(translationFieldString);
	SFVec2f *center = (SFVec2f *)getExposedField(centerFieldString);
	SFVec2f *scale = (SFVec2f *)getExposedField(scaleFieldString);
	printStream << indentString  <<  "\t"  <<  "translation " << translation << endl;
	printStream << indentString  <<  "\t"  <<  "rotation "  << getRotation() << endl;
	printStream << indentString  <<  "\t"  <<  "scale "  << scale << endl;
	printStream << indentString  <<  "\t"  <<  "center "  << center << endl;
}

////////////////////////////////////////////////
//	Node::getTransformMatrix(SFMatrix *matrix)
////////////////////////////////////////////////

void TextureTransformNode::getSFMatrix(SFMatrix *mOut)
{
	float		center[3];
	float		rotation[4];
	float		scale[3];
	float		translation[3];

	SFMatrix	mSRI;
	SFMatrix	mSR;
	SFMatrix	mCI;
	SFMatrix	mC;
	SFMatrix	mT;
	SFMatrix	mR;
	SFMatrix	mS;

	getTranslation(translation); 
	translation[2] = 0.0f;
	mT.setTranslation(translation);

	getCenter(center); 
	center[2] = 0.0f;
	mC.setTranslation(center);

	rotation[0] = 0.0f;
	rotation[1] = 0.0f;
	rotation[2] = 1.0f;
	rotation[3] = getRotation();
	mR.setRotation(rotation);

	getScale(scale);
	scale[2] = 1.0f;
	mS.setScaling(scale);

	getCenter(center); 
	center[0] = -center[0]; 
	center[1] = -center[1]; 
	center[2] = 0.0f; 
	mCI.setTranslation(center);

	mOut->init();
	mOut->add(&mCI);
	mOut->add(&mS);
	mOut->add(&mR);
	mOut->add(&mC);
	mOut->add(&mT);
}
