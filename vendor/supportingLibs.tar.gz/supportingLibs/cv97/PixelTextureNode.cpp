/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	PixelTextureNode.cpp
*
******************************************************************/

#include "PixelTextureNode.h"

PixelTextureNode::PixelTextureNode() 
{
	setHeaderFlag(false);
	setType(pixelTextureNodeString);

	///////////////////////////
	// Exposed Field 
	///////////////////////////

	// image field
	SFImage *image = new SFImage();
	addExposedField(imageFieldString, image);

	///////////////////////////
	// Field 
	///////////////////////////

	// repeatS field
	SFBool *repeatS = new SFBool(true);
	addField(repeatSFieldString, repeatS);

	// repeatT field
	SFBool *repeatT = new SFBool(true);
	addField(repeatTFieldString, repeatT);
}

PixelTextureNode::~PixelTextureNode() 
{
}

////////////////////////////////////////////////
//	RepeatS
////////////////////////////////////////////////
	
void PixelTextureNode::setRepeatS(bool value) 
{
	SFBool *repeatS = (SFBool *)getField(repeatSFieldString);
	repeatS->setValue(value);
}

void PixelTextureNode::setRepeatS(int value) 
{
	setRepeatS(value ? true : false);
}

bool PixelTextureNode::getRepeatS() 
{
	SFBool *repeatS = (SFBool *)getField(repeatSFieldString);
	return repeatS->getValue();
}

////////////////////////////////////////////////
//	RepeatT
////////////////////////////////////////////////
	
void PixelTextureNode::setRepeatT(bool value) 
{
	SFBool *repeatT = (SFBool *)getField(repeatTFieldString);
	repeatT->setValue(value);
}

void PixelTextureNode::setRepeatT(int value) 
{
	setRepeatT(value ? true : false);
}

bool PixelTextureNode::getRepeatT() 
{
	SFBool *repeatT = (SFBool *)getField(repeatTFieldString);
	return repeatT->getValue();
}

////////////////////////////////////////////////
// Image
////////////////////////////////////////////////

void PixelTextureNode::addImage(int value) 
{
	SFImage *image = (SFImage *)getExposedField(imageFieldString);
	image->addValue(value);
}

int PixelTextureNode::getNImages() 
{
	SFImage *image = (SFImage *)getExposedField(imageFieldString);
	return image->getSize();
}

int PixelTextureNode::getImage(int index) 
{
	SFImage *image = (SFImage *)getExposedField(imageFieldString);
	return image->get1Value(index);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

PixelTextureNode *PixelTextureNode::next() 
{
	return (PixelTextureNode *)Node::next(getType());
}

PixelTextureNode *PixelTextureNode::nextTraversal() 
{
	return (PixelTextureNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool PixelTextureNode::isChildNodeType(Node *node)
{
	return false;
}

void PixelTextureNode::initialize() 
{
}

void PixelTextureNode::uninitialize() 
{
}

void PixelTextureNode::update() 
{
}

////////////////////////////////////////////////
//	Imagemation
////////////////////////////////////////////////

void PixelTextureNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *repeatS = (SFBool *)getField(repeatSFieldString);
	SFBool *repeatT = (SFBool *)getField(repeatTFieldString);
	if (0 < getNImages()) {
		SFImage *image = (SFImage *)getExposedField(imageFieldString);
		printStream << indentString << "\t" << "image " << endl;
		image->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << endl;
	}

	printStream << indentString << "\t" << "repeatS " << repeatS << endl;
	printStream << indentString << "\t" << "repeatT " << repeatT << endl;
}
