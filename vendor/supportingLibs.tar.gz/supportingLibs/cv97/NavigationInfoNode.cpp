/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	NavigationInfoNode.cpp
*
******************************************************************/

#include "NavigationInfoNode.h"

NavigationInfoNode::NavigationInfoNode() 
{
	setHeaderFlag(false);
	setType(navigationInfoNodeString);

	///////////////////////////
	// Exposed Field 
	///////////////////////////

	// visibilityLimit exposed field
	SFFloat *visibilityLimit = new SFFloat(0.0f);
	addExposedField(visibilityLimitFieldString, visibilityLimit);

	// avatarSize exposed field
	MFFloat *avatarSize = new MFFloat();
	addExposedField(avatarSizeFieldString, avatarSize);

	// type exposed field
	MFString *type = new MFString();
	addExposedField(typeFieldString, type);

	// headlight exposed field
	SFBool *headlight = new SFBool(false);
	addExposedField(headlightFieldString, headlight);

	// speed exposed field
	SFFloat *speed = new SFFloat(1.0f);
	addExposedField(speedFieldString, speed);
}

NavigationInfoNode::~NavigationInfoNode() 
{
}

////////////////////////////////////////////////
// Type
////////////////////////////////////////////////

void NavigationInfoNode::addType(String value) 
{
	MFString *type = (MFString *)getExposedField(typeFieldString);
	type->addValue(value);
}

int NavigationInfoNode::getNTypes() 
{
	MFString *type = (MFString *)getExposedField(typeFieldString);
	return type->getSize();
}

String NavigationInfoNode::getType(int index) 
{
	MFString *type = (MFString *)getExposedField(typeFieldString);
	return type->get1Value(index);
}

////////////////////////////////////////////////
// avatarSize
////////////////////////////////////////////////

void NavigationInfoNode::addAvatarSize(float value) 
{
	MFFloat *avatarSize = (MFFloat *)getExposedField(avatarSizeFieldString);
	avatarSize->addValue(value);
}

int NavigationInfoNode::getNAvatarSizes() 
{
	MFFloat *avatarSize = (MFFloat *)getExposedField(avatarSizeFieldString);
	return avatarSize->getSize();
}

float NavigationInfoNode::getAvatarSize(int index) 
{
	MFFloat *avatarSize = (MFFloat *)getExposedField(avatarSizeFieldString);
	return avatarSize->get1Value(index);
}

////////////////////////////////////////////////
//	Headlight
////////////////////////////////////////////////
	
void NavigationInfoNode::setHeadlight(bool value) 
{
	SFBool *headlight = (SFBool *)getExposedField(headlightFieldString);
	headlight->setValue(value);
}

void NavigationInfoNode::setHeadlight(int value) 
{
	setHeadlight(value ? true : false);
}

bool NavigationInfoNode::getHeadlight() 
{
	SFBool *headlight = (SFBool *)getExposedField(headlightFieldString);
	return headlight->getValue();
}

////////////////////////////////////////////////
//	VisibilityLimit
////////////////////////////////////////////////

void NavigationInfoNode::setVisibilityLimit(float value) 
{
	SFFloat *visibilityLimit = (SFFloat *)getExposedField(visibilityLimitFieldString);
	visibilityLimit->setValue(value);
}

float NavigationInfoNode::getVisibilityLimit() 
{
	SFFloat *visibilityLimit = (SFFloat *)getExposedField(visibilityLimitFieldString);
	return visibilityLimit->getValue();
}

////////////////////////////////////////////////
//	Speed
////////////////////////////////////////////////
	
void NavigationInfoNode::setSpeed(float value) 
{
	SFFloat *time = (SFFloat *)getExposedField(speedFieldString);
	time->setValue(value);
}

float NavigationInfoNode::getSpeed() 
{
	SFFloat *time = (SFFloat *)getExposedField(speedFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

bool NavigationInfoNode::isChildNodeType(Node *node)
{
	return false;
}

NavigationInfoNode *NavigationInfoNode::next() 
{
	return (NavigationInfoNode *)Node::next(Node::getType());
}

NavigationInfoNode *NavigationInfoNode::nextTraversal() 
{
	return (NavigationInfoNode *)Node::nextTraversalByType(Node::getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
void NavigationInfoNode::initialize() 
{
}

void NavigationInfoNode::uninitialize() 
{
}

void NavigationInfoNode::update() 
{
}

////////////////////////////////////////////////
//	infomation
////////////////////////////////////////////////

void NavigationInfoNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *headlight = (SFBool *)getExposedField(headlightFieldString);

	printStream << indentString << "\t" << "visibilityLimit " << getVisibilityLimit() << endl;
	printStream << indentString << "\t" << "headlight " << headlight << endl;
	printStream << indentString << "\t" << "speed " << getSpeed() << endl;

	if (0 < getNTypes()) {
		MFString *type = (MFString *)getExposedField(typeFieldString);
		printStream << indentString << "\t" << "type [" << endl;
		type->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNAvatarSizes()) {
		MFFloat *avatarSize = (MFFloat *)getExposedField(avatarSizeFieldString);
		printStream << indentString << "\t" << "avatarSize [" << endl;
		avatarSize->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}
