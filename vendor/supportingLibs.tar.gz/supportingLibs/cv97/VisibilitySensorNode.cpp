/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1999
*
*	File:	VisibilitySensorNode.cpp
*
******************************************************************/

#include "VisibilitySensorNode.h"

VisibilitySensorNode::VisibilitySensorNode() 
{
	setHeaderFlag(false);
	setType(visibilitySensorNodeString);

	// enabled exposed field
	SFBool *enabled = new SFBool(true);
	addExposedField(enabledFieldString, enabled);

	// center exposed field
	SFVec3f *center = new SFVec3f(0.0f, 0.0f, 0.0f);
	addExposedField(centerFieldString, center);

	// size exposed field
	SFVec3f *size = new SFVec3f(0.0f, 0.0f, 0.0f);
	addExposedField(sizeFieldString, size);

	// isActive eventOut field
	SFBool *isActive = new SFBool(false);
	addEventOut(isActiveFieldString, isActive);

	// enterTime eventOut field
	SFTime *enterTime = new SFTime(0.0f);
	addEventOut(enterTimeFieldString, enterTime);

	// exitTime eventOut field
	SFTime *exitTime = new SFTime(0.0f);
	addEventOut(exitTimeFieldString, exitTime);
}

VisibilitySensorNode::~VisibilitySensorNode() 
{
}

////////////////////////////////////////////////
//	Enabled
////////////////////////////////////////////////
	
void VisibilitySensorNode::setEnabled(bool value) 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	bEnabled->setValue(value);
}

void VisibilitySensorNode::setEnabled(int value) 
{
	setEnabled(value ? true : false);
}

bool VisibilitySensorNode::getEnabled() 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	return bEnabled->getValue();
}

bool VisibilitySensorNode::isEnabled() 
{
	return getEnabled();
}

////////////////////////////////////////////////
//	Center
////////////////////////////////////////////////
	
void VisibilitySensorNode::setCenter(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(centerFieldString);
	sfvec3f->setValue(value);
}

void VisibilitySensorNode::setCenter(float x, float y, float z) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(centerFieldString);
	sfvec3f->setValue(x, y, z);
}

void VisibilitySensorNode::getCenter(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(centerFieldString);
	sfvec3f->getValue();
}

////////////////////////////////////////////////
//	Size
////////////////////////////////////////////////
	
void VisibilitySensorNode::setSize(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(sizeFieldString);
	sfvec3f->setValue(value);
}

void VisibilitySensorNode::setSize(float x, float y, float z) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(sizeFieldString);
	sfvec3f->setValue(x, y, z);
}

void VisibilitySensorNode::getSize(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(sizeFieldString);
	sfvec3f->getValue();
}

////////////////////////////////////////////////
//	isActive
////////////////////////////////////////////////
	
void VisibilitySensorNode::setIsActive(bool value) 
{
	SFBool *sfbool = (SFBool *)getExposedField(isActiveFieldString);
	sfbool->setValue(value);
}

void VisibilitySensorNode::setIsActive(int value) 
{
	setIsActive(value ? true : false);
}

bool VisibilitySensorNode::getIsActive() 
{
	SFBool *sfbool = (SFBool *)getExposedField(isActiveFieldString);
	return sfbool->getValue();
}

bool VisibilitySensorNode::isActive() 
{
	return getIsActive();
}

////////////////////////////////////////////////
//	EnterTime
////////////////////////////////////////////////
	
void VisibilitySensorNode::setEnterTime(double value) 
{
	SFTime *time = (SFTime *)getEventOut(enterTimeFieldString);
	time->setValue(value);
}

double VisibilitySensorNode::getEnterTime() 
{
	SFTime *time = (SFTime *)getEventOut(enterTimeFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	ExitTime
////////////////////////////////////////////////
	
void VisibilitySensorNode::setExitTime(double value) 
{
	SFTime *time = (SFTime *)getEventOut(exitTimeFieldString);
	time->setValue(value);
}

double VisibilitySensorNode::getExitTime() 
{
	SFTime *time = (SFTime *)getEventOut(exitTimeFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

VisibilitySensorNode *VisibilitySensorNode::next() 
{
	return (VisibilitySensorNode *)Node::next(getType());
}

VisibilitySensorNode *VisibilitySensorNode::nextTraversal() 
{
	return (VisibilitySensorNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool VisibilitySensorNode::isChildNodeType(Node *node)
{
	return false;
}

void VisibilitySensorNode::initialize() 
{
}

void VisibilitySensorNode::uninitialize() 
{
}

void VisibilitySensorNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void VisibilitySensorNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *enabled = (SFBool *)getExposedField(enabledFieldString);
	SFVec3f *center = (SFVec3f *)getExposedField(centerFieldString);
	SFVec3f *size = (SFVec3f *)getExposedField(sizeFieldString);
	printStream << indentString << "\t" << "enabled " << enabled << endl;
	printStream << indentString << "\t" << "center " << center << endl;
	printStream << indentString << "\t" << "size " << size << endl;
}


