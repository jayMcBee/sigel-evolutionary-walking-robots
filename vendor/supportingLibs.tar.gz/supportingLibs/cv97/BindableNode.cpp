/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	BindableNode.cpp
*
******************************************************************/

#include "BindableNode.h"

BindableNode::BindableNode() 
{
	// set_bind
	SFBool *setBind = new SFBool(true);
	addEventIn(setBindFieldString, setBind);

	// cybleInterval exposed field
	SFTime *bindTime = new SFTime(1.0);
	addEventOut(bindTimeFieldString, bindTime);

	// isBind
	SFBool *isBound = new SFBool(true);
	addEventOut(isBoundFieldString, isBound);
}

BindableNode::~BindableNode() {
}

////////////////////////////////////////////////
//	bind
////////////////////////////////////////////////

void BindableNode::setBind(bool value) 
{
	SFBool *bind = (SFBool *)getEventIn(setBindFieldString);
	bind->setValue(value);
}

bool BindableNode::getBind() 
{
	SFBool *bind = (SFBool *)getEventIn(setBindFieldString);
	return bind->getValue();
}

Field *BindableNode::getBindField() 
{
	return getEventIn(setBindFieldString);
}

////////////////////////////////////////////////
//	bindTime
////////////////////////////////////////////////
	
void BindableNode::setBindTime(double value) 
{
	SFTime *cycle = (SFTime *)getEventOut(bindTimeFieldString);
	cycle->setValue(value);
}

double BindableNode::getBindTime() 
{
	SFTime *cycle = (SFTime *)getEventOut(bindTimeFieldString);
	return cycle->getValue();
}

Field *BindableNode::getBindTimeField() 
{
	return getEventOut(bindTimeFieldString);
}

////////////////////////////////////////////////
//	isBound
////////////////////////////////////////////////

void BindableNode::setIsBound(bool value) 
{
	SFBool *isBound = (SFBool *)getEventOut(isBoundFieldString);
	isBound->setValue(value);
}

bool BindableNode::getIsBound() 
{
	SFBool *isBound = (SFBool *)getEventOut(isBoundFieldString);
	return isBound->getValue();
}

bool BindableNode::isBound() 
{
	return getIsBound();
}

Field *BindableNode::getIsBoundField() 
{
	return getEventOut(isBoundFieldString);
}

