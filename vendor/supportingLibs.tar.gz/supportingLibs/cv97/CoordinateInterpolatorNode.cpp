/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	CoordinateInterpolatorNode.cpp
*
******************************************************************/

#include "vrmlfields.h"
#include "CoordinateInterpolatorNode.h"

CoordinateInterpolatorNode::CoordinateInterpolatorNode() 
{
	setHeaderFlag(false);
	setType(coordinateInterpolatorNodeString);

	// key exposed field
	MFFloat *key = new MFFloat();
	addExposedField(keyFieldString, key);

	// keyValue exposed field
	MFVec3f *keyValue = new MFVec3f();
	addExposedField(keyValueFieldString, keyValue);

	// set_fraction eventIn field
	SFFloat *setFraction = new SFFloat(0.0f);
	addEventIn(fractionFieldString, setFraction);

	// value_changed eventOut field
	SFVec3f *valueChanged = new SFVec3f(0.0f, 0.0f, 0.0f);
	addEventOut(valueFieldString, valueChanged);
}

CoordinateInterpolatorNode::~CoordinateInterpolatorNode() 
{
}

////////////////////////////////////////////////
//	key
////////////////////////////////////////////////
	
void CoordinateInterpolatorNode::addKey(float value) 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	key->addValue(value);
}

int CoordinateInterpolatorNode::getNKeys() 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	return key->getSize();
}

float CoordinateInterpolatorNode::getKey(int index) 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	return key->get1Value(index);
}

Field *CoordinateInterpolatorNode::getKeyField() 
{
	return getExposedField(keyFieldString);
}

////////////////////////////////////////////////
//	keyValue
////////////////////////////////////////////////
	
void CoordinateInterpolatorNode::addKeyValue(float vector[]) 
{
	MFVec3f *keyValue = (MFVec3f *)getExposedField(keyValueFieldString);
	keyValue->addValue(vector);
}

int CoordinateInterpolatorNode::getNKeyValues() 
{
	MFVec3f *keyValue = (MFVec3f *)getExposedField(keyValueFieldString);
	return keyValue->getSize();
}
	
void CoordinateInterpolatorNode::getKeyValue(int index, float vector[]) 
{
	MFVec3f *keyValue = (MFVec3f *)getExposedField(keyValueFieldString);
	keyValue->get1Value(index, vector);
}

Field *CoordinateInterpolatorNode::getKeyValueField() 
{
	return getExposedField(keyValueFieldString);
}

////////////////////////////////////////////////
//	fraction
////////////////////////////////////////////////
	
void CoordinateInterpolatorNode::setFraction(float value) 
{
	SFFloat *fraction = (SFFloat *)getEventIn(fractionFieldString);
	fraction->setValue(value);
}

float CoordinateInterpolatorNode::getFraction() 
{
	SFFloat *fraction = (SFFloat *)getEventIn(fractionFieldString);
	return fraction->getValue();
}

Field *CoordinateInterpolatorNode::getFractionField() 
{
	return getEventIn(fractionFieldString);
}

////////////////////////////////////////////////
//	value
////////////////////////////////////////////////
	
void CoordinateInterpolatorNode::setValue(float vector[]) 
{
	SFVec3f *value = (SFVec3f *)getEventOut(valueFieldString);
	value->setValue(vector);
}

void CoordinateInterpolatorNode::getValue(float vector[]) 
{
	SFVec3f *value = (SFVec3f *)getEventOut(valueFieldString);
	value->getValue(vector);
}

Field *CoordinateInterpolatorNode::getValueField() 
{
	return getEventOut(valueFieldString);
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool CoordinateInterpolatorNode::isChildNodeType(Node *node)
{
	return false;
}

void CoordinateInterpolatorNode::initialize() 
{
}

void CoordinateInterpolatorNode::uninitialize() 
{
}

void CoordinateInterpolatorNode::update() 
{
	int n;

	float fraction = getFraction();
	int index = -1;
	int nKey = getNKeys();
	for (n=0; n<(nKey-1); n++) {
		if (getKey(n) <= fraction && fraction <= getKey(n+1)) {
			index = n;
			break;
		}
	}
	if (index == -1)
		return;

	float scale = (fraction - getKey(index)) / (getKey(index+1) - getKey(index));

	float vector1[3];
	float vector2[3];
	float vectorOut[3];

	getKeyValue(index, vector1);
	getKeyValue(index+1, vector2);
	for (n=0; n<3; n++)
		vectorOut[n] = vector1[n] + (vector2[n] - vector1[n])*scale;

	setValue(vectorOut);
	sendEvent(getValueField());
}

////////////////////////////////////////////////
//	Output
////////////////////////////////////////////////

void CoordinateInterpolatorNode::outputContext(ostream &printStream, String indentString) 
{
	if (0 < getNKeys()) {
		MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
		printStream << indentString << "\tkey [" << endl;
		key->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t]" << endl;
	}

	if (0 < getNKeyValues()) {
		MFVec3f *keyValue = (MFVec3f *)getExposedField(keyValueFieldString);
		printStream << indentString << "\tkeyValue [" << endl;
		keyValue->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t]" << endl;
	}
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

CoordinateInterpolatorNode *CoordinateInterpolatorNode::next() {
	return (CoordinateInterpolatorNode *)Node::next(getType());
}

CoordinateInterpolatorNode *CoordinateInterpolatorNode::nextTraversal() {
	return (CoordinateInterpolatorNode *)Node::nextTraversalByType(getType());
}


