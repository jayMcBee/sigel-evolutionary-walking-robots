/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	WorldInfoNode.cpp
*
******************************************************************/

#include "WorldInfoNode.h"

WorldInfoNode::WorldInfoNode() 
{
	setHeaderFlag(false);
	setType(worldInfoNodeString);

	// title exposed field
	SFString *title = new SFString("");
	addField(titleFieldString, title);

	// info exposed field
	MFString *info = new MFString();
	addField(infoFieldString, info);
}

WorldInfoNode::~WorldInfoNode()
{
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

WorldInfoNode *WorldInfoNode::next() 
{
	return (WorldInfoNode *)Node::next(getType());
}

WorldInfoNode *WorldInfoNode::nextTraversal() 
{
	return (WorldInfoNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	Title
////////////////////////////////////////////////
	
void WorldInfoNode::setTitle(String value) 
{
	SFString *title = (SFString *)getField(titleFieldString);
	title->setValue(value);
}

String WorldInfoNode::getTitle() 
{
	SFString *title = (SFString *)getField(titleFieldString);
	return title->getValue();
}

////////////////////////////////////////////////
// Info
////////////////////////////////////////////////

void WorldInfoNode::addInfo(String value) 
{
	MFString *info = (MFString *)getField(infoFieldString);
	info->addValue(value);
}

int WorldInfoNode::getNInfos() 
{
	MFString *info = (MFString *)getField(infoFieldString);
	return info->getSize();
}

String WorldInfoNode::getInfo(int index) 
{
	MFString *info = (MFString *)getField(infoFieldString);
	return info->get1Value(index);
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool WorldInfoNode::isChildNodeType(Node *node)
{
	return false;
}

void WorldInfoNode::initialize() 
{
}

void WorldInfoNode::uninitialize() 
{
}

void WorldInfoNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void WorldInfoNode::outputContext(ostream& printStream, String indentString) 
{
	SFString *title = (SFString *)getField(titleFieldString);
	printStream << indentString << "\t" << "title " << title << endl;

	if (0 < getNInfos()) {
		MFString *info = (MFString *)getField(infoFieldString);
		printStream <<  indentString << "\t" << "info ["  << endl;
		info->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}
