/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	DefNode.cpp
*
******************************************************************/

#include "DefNode.h"

DefNode::DefNode() 
{
	setHeaderFlag(false);
	setType(defNodeString);
}

DefNode::~DefNode() 
{
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

DefNode *DefNode::next() 
{
	return (DefNode *)Node::next(getType());
}

DefNode *DefNode::nextTraversal() 
{
	return (DefNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool DefNode::isChildNodeType(Node *node)
{
	return false;
}

void DefNode::initialize()
{
}

void DefNode::uninitialize()
{
}

void DefNode::update() 
{
}

void DefNode::outputContext(ostream &printStream, String indentString) 
{
}

