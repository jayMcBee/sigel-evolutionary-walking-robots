/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	ParserNode.h
*
******************************************************************/

#ifndef _PARSERNODE_H_
#define _PARSERNODE_H_

#include "CLinkedList.h"
#include "Node.h"

class ParserNode : public CLinkedListNode<ParserNode> {
	Node		*mNode;
	int			mType;
public:

	ParserNode(Node *node, int type);
	~ParserNode();
	
	Node *getNode(); 
	int getType();
};

#endif

