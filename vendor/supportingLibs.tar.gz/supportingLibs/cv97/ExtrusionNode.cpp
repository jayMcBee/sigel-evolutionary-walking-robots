/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	ExtrusionNode.cpp
*
******************************************************************/

#ifdef SUPPORT_OPENGL
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/gl.h>
#endif

#include "ExtrusionNode.h"
#include "MathUtil.h"

void AddDefaultParameters(ExtrusionNode *ex);

ExtrusionNode::ExtrusionNode() 
{

	setHeaderFlag(false);
	setType(extrusionNodeString);

	///////////////////////////
	// Field 
	///////////////////////////
		
	// beginCap field
	SFBool *beginCap = new SFBool(true);
	addField(beginCapFieldString, beginCap);

	// endCap field
	SFBool *endCap = new SFBool(true);
	addField(endCapFieldString, endCap);

	// ccw field
	SFBool *ccw = new SFBool(true);
	ccw->setName(ccwFieldString);
	addField(ccw);

	// convex field
	SFBool *convex = new SFBool(true);
	convex->setName(convexFieldString);
	addField(convex);

	// creaseAngle field
	SFFloat *creaseAngle = new SFFloat(0.0f);
	creaseAngle->setName(creaseAngleFieldString);
	addField(creaseAngle);

	// solid field
	SFBool *solid = new SFBool(true);
	solid->setName(solidFieldString);
	addField(solid);

	// orientation field
	MFRotation *orientation = new MFRotation();
	orientation->setName(orientationFieldString);
	addField(orientation);

	// scale field
	MFVec2f *scale = new MFVec2f();
	scale->setName(scaleFieldString);
	addField(scale);

	// crossSection field
	MFVec2f *crossSection = new MFVec2f();
	addField(crossSectionFieldString, crossSection);

	// spine field
	MFVec3f *spine = new MFVec3f();
	addField(spineFieldString, spine);

	///////////////////////////
	// EventIn
	///////////////////////////

	// orientation EventIn
	orientation = new MFRotation();
	orientation->setName(orientationFieldString);
	addEventIn(orientation);

	// scale EventIn
	scale = new MFVec2f();
	scale->setName(scaleFieldString);
	addEventIn(scale);

	// crossSection EventIn
	crossSection = new MFVec2f();
	addEventIn(crossSectionFieldString, crossSection);

	// spine EventIn
	spine = new MFVec3f();
	addEventIn(spineFieldString, spine);
}

ExtrusionNode::~ExtrusionNode() 
{
}

////////////////////////////////////////////////
//	BeginCap
////////////////////////////////////////////////
	
void ExtrusionNode::setBeginCap(bool value) 
{
	SFBool *beginCap = (SFBool *)getField(beginCapFieldString);
	beginCap->setValue(value);
}

void ExtrusionNode::setBeginCap(int value) 
{
	setBeginCap(value ? true : false);
}

bool ExtrusionNode::getBeginCap() 
{
	SFBool *beginCap = (SFBool *)getField(beginCapFieldString);
	return beginCap->getValue();
}

////////////////////////////////////////////////
//	EndCap
////////////////////////////////////////////////
	
void ExtrusionNode::setEndCap(bool value) 
{
	SFBool *endCap = (SFBool *)getField(endCapFieldString);
	endCap->setValue(value);
}

void ExtrusionNode::setEndCap(int value) 
{
	setEndCap(value ? true : false);
}

bool ExtrusionNode::getEndCap() 
{
	SFBool *endCap = (SFBool *)getField(endCapFieldString);
	return endCap->getValue();
}

////////////////////////////////////////////////
//	CCW
////////////////////////////////////////////////
	
void ExtrusionNode::setCCW(bool value) 
{
	SFBool *ccw = (SFBool *)getField(ccwFieldString);
	ccw->setValue(value);
}

void ExtrusionNode::setCCW(int value) 
{
	setCCW(value ? true : false);
}

bool ExtrusionNode::getCCW() 
{
	SFBool *ccw = (SFBool *)getField(ccwFieldString);
	return ccw->getValue();
}

////////////////////////////////////////////////
//	Convex
////////////////////////////////////////////////
	
void ExtrusionNode::setConvex(bool value) 
{
	SFBool *convex = (SFBool *)getField(convexFieldString);
	convex->setValue(value);
}

void ExtrusionNode::setConvex(int value) 
{
	setConvex(value ? true : false);
}

bool ExtrusionNode::getConvex() 
{
	SFBool *convex = (SFBool *)getField(convexFieldString);
	return convex->getValue();
}

////////////////////////////////////////////////
//	CreaseAngle
////////////////////////////////////////////////
	
void ExtrusionNode::setCreaseAngle(float value) 
{
	SFFloat *creaseAngle = (SFFloat *)getField(creaseAngleFieldString);
	creaseAngle->setValue(value);
}

float ExtrusionNode::getCreaseAngle() 
{
	SFFloat *creaseAngle = (SFFloat *)getField(creaseAngleFieldString);
	return creaseAngle->getValue();
}

////////////////////////////////////////////////
//	Solid
////////////////////////////////////////////////
	
void ExtrusionNode::setSolid(bool value) 
{
	SFBool *solid = (SFBool *)getField(solidFieldString);
	solid->setValue(value);
}

void ExtrusionNode::setSolid(int value) 
{
	setSolid(value ? true : false);
}

bool ExtrusionNode::getSolid() 
{
	SFBool *solid = (SFBool *)getField(solidFieldString);
	return solid->getValue();
}

////////////////////////////////////////////////
// orientation
////////////////////////////////////////////////

void ExtrusionNode::addOrientation(float value[]) 
{
	MFRotation *orientation = (MFRotation *)getField(orientationFieldString);
	orientation->addValue(value);
}

void ExtrusionNode::addOrientation(float x, float y, float z, float angle) 
{
	MFRotation *orientation = (MFRotation *)getField(orientationFieldString);
	orientation->addValue(x, y, z, angle);
}

int ExtrusionNode::getNOrientations() 
{
	MFRotation *orientation = (MFRotation *)getField(orientationFieldString);
	return orientation->getSize();
}

void ExtrusionNode::getOrientation(int index, float value[]) 
{
	MFRotation *orientation = (MFRotation *)getField(orientationFieldString);
	orientation->get1Value(index, value);
}

////////////////////////////////////////////////
// scale
////////////////////////////////////////////////

void ExtrusionNode::addScale(float value[]) 
{
	MFVec2f *scale = (MFVec2f *)getField(scaleFieldString);
	scale->addValue(value);
}

void ExtrusionNode::addScale(float x, float z) 
{
	MFVec2f *scale = (MFVec2f *)getField(scaleFieldString);
	scale->addValue(x, z);
}

int ExtrusionNode::getNScales() 
{
	MFVec2f *scale = (MFVec2f *)getField(scaleFieldString);
	return scale->getSize();
}

void ExtrusionNode::getScale(int index, float value[]) 
{
	MFVec2f *scale = (MFVec2f *)getField(scaleFieldString);
	scale->get1Value(index, value);
}

////////////////////////////////////////////////
// crossSection
////////////////////////////////////////////////

void ExtrusionNode::addCrossSection(float value[]) 
{
	MFVec2f *crossSection = (MFVec2f *)getField(crossSectionFieldString);
	crossSection->addValue(value);
}

void ExtrusionNode::addCrossSection(float x, float z) 
{
	MFVec2f *crossSection = (MFVec2f *)getField(crossSectionFieldString);
	crossSection->addValue(x, z);
}

int ExtrusionNode::getNCrossSections() 
{
	MFVec2f *crossSection = (MFVec2f *)getField(crossSectionFieldString);
	return crossSection->getSize();
}

void ExtrusionNode::getCrossSection(int index, float value[]) 
{
	MFVec2f *crossSection = (MFVec2f *)getField(crossSectionFieldString);
	crossSection->get1Value(index, value);
}

////////////////////////////////////////////////
// spine
////////////////////////////////////////////////

void ExtrusionNode::addSpine(float value[]) 
{
	MFVec3f *spine = (MFVec3f *)getField(spineFieldString);
	spine->addValue(value);
}

void ExtrusionNode::addSpine(float x, float y, float z) 
{
	MFVec3f *spine = (MFVec3f *)getField(spineFieldString);
	spine->addValue(x, y, z);
}

int ExtrusionNode::getNSpines() 
{
	MFVec3f *spine = (MFVec3f *)getField(spineFieldString);
	return spine->getSize();
}

void ExtrusionNode::getSpine(int index, float value[]) 
{
	MFVec3f *spine = (MFVec3f *)getField(spineFieldString);
	spine->get1Value(index, value);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

ExtrusionNode *ExtrusionNode::next() 
{
	return (ExtrusionNode *)Node::next(getType());
}

ExtrusionNode *ExtrusionNode::nextTraversal() 
{
	return (ExtrusionNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool ExtrusionNode::isChildNodeType(Node *node)
{
	return false;
}

void ExtrusionNode::initialize() 
{
	if (!isInitialized()) {
		AddDefaultParameters(this);
#ifdef SUPPORT_OPENGL
		recomputeDisplayList();
#endif
		recomputeBoundingBox();
		setInitialized(true);
	}
}

void ExtrusionNode::uninitialize() 
{
}

void ExtrusionNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void ExtrusionNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *beginCap = (SFBool *)getField(beginCapFieldString);
	SFBool *endCap = (SFBool *)getField(endCapFieldString);
	SFBool *ccw = (SFBool *)getField(ccwFieldString);
	SFBool *convex = (SFBool *)getField(convexFieldString);
	SFBool *solid = (SFBool *)getField(solidFieldString);

	printStream << indentString << "\t" << "beginCap " << beginCap << endl;
	printStream << indentString << "\t" << "endCap " << endCap << endl;
	printStream << indentString << "\t" << "solid " << solid << endl;
	printStream << indentString << "\t" << "ccw " << ccw << endl;
	printStream << indentString << "\t" << "convex " << convex << endl;
	printStream << indentString << "\t" << "creaseAngle " << getCreaseAngle() << endl;

	if (0 < getNCrossSections()) {
		MFVec2f *crossSection = (MFVec2f *)getField(crossSectionFieldString);
		printStream << indentString << "\t" << "crossSection [" << endl;
		crossSection->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNOrientations()) {
		MFRotation *orientation = (MFRotation *)getField(orientationFieldString);
		printStream << indentString << "\t" << "orientation [" << endl;
		orientation->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNScales()) {
		MFVec2f *scale = (MFVec2f *)getField(scaleFieldString);
		printStream << indentString << "\t" << "scale [" << endl;
		scale->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNSpines()) {
		MFVec3f *spine = (MFVec3f *)getField(spineFieldString);
		printStream << indentString << "\t" << "spine [" << endl;
		spine->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}

////////////////////////////////////////////////
//	GroupingNode::recomputeBoundingBox
////////////////////////////////////////////////

void AddDefaultParameters(ExtrusionNode *ex)
{
	if (ex->getNCrossSections() == 0) {
		ex->addCrossSection(1.0f, 1.0);
		ex->addCrossSection(1.0f, -1.0);
		ex->addCrossSection(-1.0f, -1.0);
		ex->addCrossSection(-1.0f, 1.0);
		ex->addCrossSection(1.0f, 1.0);
	}
	if (ex->getNSpines() == 0) {
		ex->addSpine(0.0f, 0.0f, 0.0f);
		ex->addSpine(0.0f, 1.0f, 0.0f);
	}
}

////////////////////////////////////////////////
//	GroupingNode::recomputeBoundingBox
////////////////////////////////////////////////

void ExtrusionNode::recomputeBoundingBox()
{
}

////////////////////////////////////////////////
//	GroupingNode::recomputeBoundingBox
////////////////////////////////////////////////

#ifdef SUPPORT_OPENGL

static void initializePoint(ExtrusionNode *ex, SFVec3f *point)
{
	int nCrossSections = ex->getNCrossSections();
	for (int n=0; n<nCrossSections; n++) {
		float cs[2];
		ex->getCrossSection(n, cs);
		point[n].setValue(cs[0], 0.0f, cs[1]);
	}
}

static void transformPoint(SFVec3f *point, float scale[2], float scp[3][3], float orientation[4], float spine[3])
{
	point->scale(scale[0], 1.0f, scale[1]);
	
	float value[3];
	point->getValue(value);

	if (0.0f < VectorGetLength(scp[0]) && 0.0f < VectorGetLength(scp[1]) && 0.0f < VectorGetLength(scp[2])) {
		float x = value[0]*scp[0][0]+value[1]*scp[1][0]+value[2]*scp[2][0];
		float y = value[0]*scp[0][1]+value[1]*scp[1][1]+value[2]*scp[2][1];
		float z = value[0]*scp[0][2]+value[1]*scp[1][2]+value[2]*scp[2][2];
		value[0] = x;
		value[1] = y;
		value[2] = z;
	}

	point->setValue(value);

	point->translate(spine);
	point->rotate(orientation);
}

static void DrawExtrusion(ExtrusionNode *ex)
{
	bool ccw = ex->getCCW();
	if (ccw == true)
		glFrontFace(GL_CCW);
	else
		glFrontFace(GL_CW);

	bool solid = ex->getSolid();
//	if (solid == false)
		glDisable(GL_CULL_FACE);
//	else
//		glEnable(GL_CULL_FACE);

	int nCrossSections = ex->getNCrossSections();

	SFVec3f *point[2];
	point[0] = new SFVec3f[nCrossSections];
	point[1] = new SFVec3f[nCrossSections];

	int		nOrientations	= ex->getNOrientations();
	int		nScales			= ex->getNScales();
	int		nSpines			= ex->getNSpines();

	float	spineStart[3];
	float	spineEnd[3];
	bool	bClosed;

	ex->getSpine(0,			spineStart);
	ex->getSpine(nSpines-1, spineEnd);
	bClosed = VectorEquals(spineStart, spineEnd);
	
	float	scale[2];
	float	orientation[4];
	float	spine[3];
	float	scp[3][3];

	for (int n=0; n<(nSpines-1); n++) {
		initializePoint(ex, point[0]);
		initializePoint(ex, point[1]);

		for (int i=0; i<2; i++) {
			
			if (nScales == 1)
				ex->getScale(0, scale);
			else  if ((n+i) < nScales) 
				ex->getScale(n+i, scale);
			else {
				scale[0] = 1.0f; 
				scale[1] = 1.0f;
			}

			if (nOrientations == 1)
				ex->getOrientation(0, orientation);
			else if ((n+i) < nOrientations)
				ex->getOrientation(n+i, orientation);
			else {
				orientation[0] = 0.0f; 
				orientation[1] = 0.0f; 
				orientation[2] = 1.0f; 
				orientation[3] = 0.0f;
			}

			ex->getSpine(n+i, spine);

			// SCP Y
			float spine0[3], spine1[3], spine2[3];
			if (nSpines <= 2) {
				ex->getSpine(1, spine1);
				ex->getSpine(0, spine2);
			}
			else if (bClosed && (n+i == 0 || n+i == (nSpines-1))) {
				ex->getSpine(1,			spine1);
				ex->getSpine(nSpines-2,	spine2);
			}
			else if (n+i == 0) {
				ex->getSpine(1, spine1);
				ex->getSpine(0, spine2);
			}
			else if (n+i == (nSpines-1)) {
				ex->getSpine(nSpines-1, spine1);
				ex->getSpine(nSpines-2, spine2);
			}
			else {
				ex->getSpine(n+i+1, spine1);
				ex->getSpine(n+i-1, spine2);
			}
			VectorGetDirection(spine1, spine2, scp[1]);
			VectorNormalize(scp[1]);

			// SCP Z
			float v1[3], v2[3];
			if (nSpines <= 2) {
				ex->getSpine(0, spine0);
				ex->getSpine(1, spine1);
				ex->getSpine(1, spine2);
			}
			else if (bClosed && (n+i == 0 || n+i == (nSpines-1))) {
				ex->getSpine(0,			spine0);
				ex->getSpine(1,			spine1);
				ex->getSpine(nSpines-2,	spine2);
			}
			else if (n+i == 0) {
				ex->getSpine(1,	spine0);
				ex->getSpine(2,	spine1);
				ex->getSpine(0,	spine2);
			}
			else if (n+i == (nSpines-1)) {
				ex->getSpine(nSpines-2, spine1);
				ex->getSpine(nSpines-1, spine1);
				ex->getSpine(nSpines-3, spine2);
			}
			else {
				ex->getSpine(n+i,	spine0);
				ex->getSpine(n+i+1,	spine1);
				ex->getSpine(n+i-1,	spine2);
			}
			VectorGetDirection(spine1, spine0, v1);
			VectorGetDirection(spine2, spine0, v2);
			VectorGetCross(v1, v2, scp[2]);

			// SCP X
			VectorGetCross(scp[1], scp[2], scp[0]);

			for (int j=0; j<nCrossSections; j++)  
				transformPoint(&point[i][j], scale, scp, orientation, spine);
		}

		for (int k=0; k<nCrossSections-1; k++) {

			float	vpoint[3][3];
			float	normal[3];
			
			point[1][k].getValue(vpoint[0]); 
			point[0][k].getValue(vpoint[1]);
			point[1][(k+1)%nCrossSections].getValue(vpoint[2]);
			GetNormalFromVertices(vpoint, normal);
			glNormal3fv(normal);
			
			SFVec3f	*vertex;

			glBegin(GL_POLYGON);
			vertex = &point[1][(k+1)%nCrossSections];	glVertex3f(vertex->getX(), vertex->getY(), vertex->getZ());
			vertex = &point[1][k];						glVertex3f(vertex->getX(), vertex->getY(), vertex->getZ());
			vertex = &point[0][k];						glVertex3f(vertex->getX(), vertex->getY(), vertex->getZ());
			glEnd();

			glBegin(GL_POLYGON);
			vertex = &point[0][(k+1)%nCrossSections];	glVertex3f(vertex->getX(), vertex->getY(), vertex->getZ());
			vertex = &point[1][(k+1)%nCrossSections];	glVertex3f(vertex->getX(), vertex->getY(), vertex->getZ());
			vertex = &point[0][k];						glVertex3f(vertex->getX(), vertex->getY(), vertex->getZ());
			glEnd();
		}

		if (n==0 && ex->getBeginCap() == true) {
			glBegin(GL_POLYGON);
			for (int k=0; k<nCrossSections; k++)
				glVertex3f(point[0][k].getX(), point[0][k].getY(), point[0][k].getZ());
			glEnd();
		}

		if (n==(nSpines-1)-1 && ex->getEndCap() == true) {
			glBegin(GL_POLYGON);
			for (int k=0; k<nCrossSections; k++)
				glVertex3f(point[1][k].getX(), point[1][k].getY(), point[1][k].getZ());
			glEnd();
		}
	}

	if (ccw == false)
		glFrontFace(GL_CCW);

//	if (solid == false)
		glEnable(GL_CULL_FACE);

	delete []point[0];
	delete []point[1];
}		

void ExtrusionNode::recomputeDisplayList()
{
	unsigned int nCurrentDisplayList = getDisplayList();
	if (0 < nCurrentDisplayList)
		glDeleteLists(nCurrentDisplayList, 1);

	unsigned int nNewDisplayList = glGenLists(1);
	glNewList(nNewDisplayList, GL_COMPILE);
		DrawExtrusion(this);
	glEndList();

	setDisplayList(nNewDisplayList);
}

#endif

