/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	JString.cpp
*
******************************************************************/

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "JString.h"

JString::JString() 
{
	mValue = NULL;
}

JString::JString(char value[]) 
{
	mValue = NULL;
	setValue(value);
}

JString::JString(char value[], int offset, int count) 
{
	mValue = NULL;
	setValue(value, offset, count);
}

JString::~JString() 
{
	deleteValue();
}

void JString::setValue(char value[]) 
{
	deleteValue();
	if (!value)
		return;
	if (strlen(value) <= 0)
		return;
	mValue = new char[strlen(value)+1];
	strcpy(mValue, value);
}

void JString::setValue(char value[], int offset, int count) 
{ 
	deleteValue();
	if (!value && (int)strlen(value) < (offset + count)) 
		return;
	mValue = new char[count+1];
	strncpy(mValue, &value[offset], count);
}

char *JString::getValue() 
{
	return mValue;
}

void JString::deleteValue() 
{
	delete[] mValue;
	mValue = NULL;
}

int JString::length() 
{
	if (!mValue)
		return 0;
	return strlen(mValue);
}

char JString::charAt(int  index) 
{
	return mValue[index];
}

int JString::compareTo(char *anotherString) 
{
	if (!mValue || !anotherString)
		return -1;
	return strcmp(mValue, anotherString);
}

int JString::compareToIgnoreCase(char *anotherString) 
{
	if (!mValue || !anotherString)
		return -1;
	
	int n;

	char *value1 = new char[strlen(mValue)+1]; 
	strcpy(value1, mValue);
	for (n=0; n<(int)strlen(mValue); n++)
		value1[n] = (char)toupper(value1[n]);

	char *value2 = new char[strlen(anotherString)+1]; 
	strcpy(value2, anotherString);
	for (n=0; n<(int)strlen(anotherString); n++)
		value2[n] = (char)toupper(value2[n]);
		
	int ret = strcmp(value1, value2);

	delete value1;
	delete value2;

	return ret;
}

void JString::concat(char *str) 
{
	if (!str)
		return;
	char *value = new char [length()+strlen(str)+1];
	if (mValue) {
		strcpy(value, mValue);
		strcat(value, str);
	}
	else
		strcpy(value, str);
	delete mValue;
	mValue = value;
}

void JString::copyValueOf(char data[]) 
{
	if (!data || !mValue)
		return;
	strcpy(data, mValue);
}

void JString::copyValueOf(char  data[], int  offset, int count) 
{
	if (!data || !mValue)
		return;
	strncpy(data, &mValue[offset], count);
}

int JString::regionMatches(int toffset, char *other, int ooffset, int len) 
{
	if (!mValue || !other)
		return -1;
	if (length() < toffset)
		return -1;
	if ((int)strlen(other) < ooffset + len)
		return -1;
	return strncmp(&mValue[toffset], &other[ooffset], len);
}

int JString::regionMatchesIgnoreCase(int toffset, char *other, int ooffset, int len)
{
	if (!mValue || !other)
		return -1;
	
	int n;

	char *value1 = new char[strlen(mValue)+1]; 
	strcpy(value1, mValue);
	for (n=0; n<(int)strlen(mValue); n++)
		value1[n] = (char)toupper(value1[n]);

	char *value2 = new char[strlen(other)+1]; 
	strcpy(value2, other);
	for (n=0; n<(int)strlen(other); n++)
		value2[n] = (char)toupper(value2[n]);
		
	int ret = regionMatches(toffset, other, ooffset, len);

	delete value1;
	delete value2;

	return ret;
}

int JString::startsWith(char *prefix) 
{
	if (!prefix || !mValue)
		return -1;
	return regionMatches(0, prefix, 0, strlen(prefix));
}

int JString::endsWith(char *suffix) 
{
	if (!suffix || !mValue)
		return -1;
	return regionMatches(strlen(mValue)-strlen(suffix), suffix, 0, strlen(suffix));
}
