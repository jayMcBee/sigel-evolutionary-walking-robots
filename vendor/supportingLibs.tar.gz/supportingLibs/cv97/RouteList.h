/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	RouteList.h
*
******************************************************************/

#ifndef _ROUTELIST_H_
#define _ROUTELIST_H_

#include "CLinkedList.h"
#include "Route.h"

class RouteList : public CLinkedList<Route> {

public:

	RouteList();
	~RouteList();

	void addRoute(Route *route);
	Route *getRoutes();
	Route *getRoute(int n);
	int getNRoutes();
};

#endif
