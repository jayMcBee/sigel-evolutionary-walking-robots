/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	DirectionalLightNode.h
*
******************************************************************/

#include "DirectionalLightNode.h"

DirectionalLightNode::DirectionalLightNode() 
{
	setType(directionalLightNodeString);

	// ambient intensity exposed field
	SFFloat *ambientIntensity = new SFFloat(0.0f);
	ambientIntensity->setName(ambientIntensityFieldString);
	addExposedField(ambientIntensity);

	// direction exposed field
	SFVec3f *direction = new SFVec3f(0.0f, 0.0f, -1.0f);
	direction->setName(directionFieldString);
	addExposedField(direction);
}

DirectionalLightNode::~DirectionalLightNode() 
{
}

////////////////////////////////////////////////
//	AmbientIntensity
////////////////////////////////////////////////
	
void DirectionalLightNode::setAmbientIntensity(float value) 
{
	SFFloat *intensity = (SFFloat *)getExposedField(ambientIntensityFieldString);
	intensity->setValue(value);
}

float DirectionalLightNode::getAmbientIntensity() 
{
	SFFloat *intensity = (SFFloat *)getExposedField(ambientIntensityFieldString);
	return intensity->getValue();
}

////////////////////////////////////////////////
//	Direction
////////////////////////////////////////////////

void DirectionalLightNode::setDirection(float value[]) 
{
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	direction->setValue(value);
}

void DirectionalLightNode::setDirection(float x, float y, float z) 
{
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	direction->setValue(x, y, z);
}

void DirectionalLightNode::getDirection(float value[]) 
{
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	direction->getValue(value);
}

////////////////////////////////////////////////
//	Diffuse Color
////////////////////////////////////////////////

void DirectionalLightNode::getDiffuseColor(float value[]) 
{
	getColor(value);
	float	intensity = getIntensity();
	value[0] *= intensity;
	value[1] *= intensity;
	value[2] *= intensity;
}

////////////////////////////////////////////////
//	Ambient Color
////////////////////////////////////////////////

void DirectionalLightNode::getAmbientColor(float value[]) 
{
	getColor(value);
	float	intensity = getIntensity();
	float	ambientIntensity = getAmbientIntensity();
	value[0] *= intensity * ambientIntensity;
	value[1] *= intensity * ambientIntensity;
	value[2] *= intensity * ambientIntensity;
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

DirectionalLightNode *DirectionalLightNode::next() 
{
	return (DirectionalLightNode *)Node::next(getType());
}

DirectionalLightNode *DirectionalLightNode::nextTraversal() 
{
	return (DirectionalLightNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool DirectionalLightNode::isChildNodeType(Node *node)
{
	return false;
}

void DirectionalLightNode::initialize() 
{
}

void DirectionalLightNode::uninitialize() 
{
}

void DirectionalLightNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void DirectionalLightNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *bon = (SFBool *)getExposedField(onFieldString);
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	SFColor *color = (SFColor *)getExposedField(colorFieldString);

	printStream << indentString << "\t" << "on " << bon  << endl;
	printStream << indentString << "\t" << "intensity " << getIntensity()  << endl;
	printStream << indentString << "\t" << "ambientIntensity " << getAmbientIntensity()  << endl;
	printStream << indentString << "\t" << "color " << color  << endl;
	printStream << indentString << "\t" << "direction " << direction  << endl;
}
