/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	ElevationGridNode.cpp
*
******************************************************************/

#ifdef SUPPORT_OPENGL
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/gl.h>
#endif

#include "ElevationGridNode.h"
#include "MathUtil.h"

ElevationGridNode::ElevationGridNode() 
{
	setHeaderFlag(false);
	setType(elevationGridNodeString);

	// xSpacing field
	SFFloat *xSpacing = new SFFloat(0.0f);
	addField(xSpacingFieldString, xSpacing);

	// zSpacing field
	SFFloat *zSpacing = new SFFloat(0.0f);
	addField(zSpacingFieldString, zSpacing);

	// xDimension field
	SFInt32 *xDimension = new SFInt32(0);
	addField(xDimensionFieldString, xDimension);

	// zDimension field
	SFInt32 *zDimension = new SFInt32(0);
	addField(zDimensionFieldString, zDimension);

	// colorPerVertex exposed field
	SFBool *colorPerVertex = new SFBool(true);
	colorPerVertex->setName(colorPerVertexFieldString);
	addField(colorPerVertex);

	// normalPerVertex exposed field
	SFBool *normalPerVertex = new SFBool(true);
	normalPerVertex->setName(normalPerVertexFieldString);
	addField(normalPerVertex);

	// ccw exposed field
	SFBool *ccw = new SFBool(true);
	ccw->setName(ccwFieldString);
	addField(ccw);

	// solid exposed field
	SFBool *solid = new SFBool(true);
	solid->setName(solidFieldString);
	addField(solid);

	// creaseAngle exposed field
	SFFloat *creaseAngle = new SFFloat(0.0f);
	creaseAngle->setName(creaseAngleFieldString);
	addField(creaseAngle);

	// height exposed field
	MFFloat *height = new MFFloat();
	addField(heightFieldString, height);

	// height eventIn
	MFFloat *setHeight = new MFFloat();
	addEventIn(heightFieldString, setHeight);
}

ElevationGridNode::~ElevationGridNode() 
{
}

////////////////////////////////////////////////
//	xSpacing
////////////////////////////////////////////////

void ElevationGridNode::setXSpacing(float value) 
{
	SFFloat *space = (SFFloat *)getField(xSpacingFieldString);
	space->setValue(value);
}

float ElevationGridNode::getXSpacing() 
{
	SFFloat *space = (SFFloat *)getField(xSpacingFieldString);
	return space->getValue();
}

////////////////////////////////////////////////
//	zSpacing
////////////////////////////////////////////////

void ElevationGridNode::setZSpacing(float value) 
{
	SFFloat *space = (SFFloat *)getField(zSpacingFieldString);
	space->setValue(value);
}

float ElevationGridNode::getZSpacing() 
{
	SFFloat *space = (SFFloat *)getField(zSpacingFieldString);
	return space->getValue();
}

////////////////////////////////////////////////
//	xDimension
////////////////////////////////////////////////

void ElevationGridNode::setXDimension(int value) 
{
	SFInt32 *dimension = (SFInt32 *)getField(xDimensionFieldString);
	dimension->setValue(value);
}

int ElevationGridNode::getXDimension() 
{
	SFInt32 *dimension = (SFInt32 *)getField(xDimensionFieldString);
	return dimension->getValue();
}

////////////////////////////////////////////////
//	zDimension
////////////////////////////////////////////////

void ElevationGridNode::setZDimension(int value) 
{
	SFInt32 *dimension = (SFInt32 *)getField(zDimensionFieldString);
	dimension->setValue(value);
}

int ElevationGridNode::getZDimension() 
{
	SFInt32 *dimension = (SFInt32 *)getField(zDimensionFieldString);
	return dimension->getValue();
}

////////////////////////////////////////////////
//	ColorPerVertex
////////////////////////////////////////////////
	
void ElevationGridNode::setColorPerVertex(bool  value) 
{
	SFBool *colorPerVertex = (SFBool *)getField(colorPerVertexFieldString);
	colorPerVertex->setValue(value);
}

void ElevationGridNode::setColorPerVertex(int value) 
{
	setColorPerVertex(value ? true : false);
}

bool ElevationGridNode::getColorPerVertex() 
{
	SFBool *colorPerVertex = (SFBool *)getField(colorPerVertexFieldString);
	return colorPerVertex->getValue();
}

////////////////////////////////////////////////
//	NormalPerVertex
////////////////////////////////////////////////
	
void ElevationGridNode::setNormalPerVertex(bool  value) 
{
	SFBool *normalPerVertex = (SFBool *)getField(normalPerVertexFieldString);
	normalPerVertex->setValue(value);
}

void ElevationGridNode::setNormalPerVertex(int value) 
{
	setNormalPerVertex(value ? true : false);
}

bool ElevationGridNode::getNormalPerVertex() 
{
	SFBool *normalPerVertex = (SFBool *)getField(normalPerVertexFieldString);
	return normalPerVertex->getValue();
}

////////////////////////////////////////////////
//	CCW
////////////////////////////////////////////////
	
void ElevationGridNode::setCCW(bool  value) {
	SFBool *ccw = (SFBool *)getField(ccwFieldString);
	ccw->setValue(value);
}

void ElevationGridNode::setCCW(int value) {
	setCCW(value ? true : false);
}

bool  ElevationGridNode::getCCW() {
	SFBool *ccw = (SFBool *)getField(ccwFieldString);
	return ccw->getValue();
}

////////////////////////////////////////////////
//	Solid
////////////////////////////////////////////////
	
void ElevationGridNode::setSolid(bool  value) {
	SFBool *solid = (SFBool *)getField(solidFieldString);
	solid->setValue(value);
}

void ElevationGridNode::setSolid(int value) {
	setSolid(value ? true : false);
}

bool ElevationGridNode::getSolid() {
	SFBool *solid = (SFBool *)getField(solidFieldString);
	return solid->getValue();
}

////////////////////////////////////////////////
//	CreaseAngle
////////////////////////////////////////////////
	
void ElevationGridNode::setCreaseAngle(float value) {
	SFFloat *creaseAngle = (SFFloat *)getField(creaseAngleFieldString);
	creaseAngle->setValue(value);
}

float ElevationGridNode::getCreaseAngle() {
	SFFloat *creaseAngle = (SFFloat *)getField(creaseAngleFieldString);
	return creaseAngle->getValue();
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

ElevationGridNode *ElevationGridNode::next() {
	return (ElevationGridNode *)Node::next(getType());
}

ElevationGridNode *ElevationGridNode::nextTraversal() {
	return (ElevationGridNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
// height
////////////////////////////////////////////////

void ElevationGridNode::addHeight(float value) {
	MFFloat *height = (MFFloat *)getField(heightFieldString);
	height->addValue(value);
}

int ElevationGridNode::getNHeights() {
	MFFloat *height = (MFFloat *)getField(heightFieldString);
	return height->getSize();
}
float ElevationGridNode::getHeight(int index) {
	MFFloat *height = (MFFloat *)getField(heightFieldString);
	return height->get1Value(index);
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool ElevationGridNode::isChildNodeType(Node *node){
	if (node->isColorNode() || node->isNormalNode() || node->isTextureCoordinateNode())
		return true;
	else
		return false;
}

void ElevationGridNode::uninitialize() {
}

void ElevationGridNode::update() {
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void ElevationGridNode::outputContext(ostream &printStream, String indentString) {
	SFBool *ccw = (SFBool *)getField(ccwFieldString);
	SFBool *solid = (SFBool *)getField(solidFieldString);
	SFBool *colorPerVertex = (SFBool *)getField(colorPerVertexFieldString);
	SFBool *normalPerVertex = (SFBool *)getField(normalPerVertexFieldString);

	printStream << indentString << "\t" << "xDimension " << getXDimension() << endl;
	printStream << indentString << "\t" << "xSpacing " << getXSpacing() << endl;
	printStream << indentString << "\t" << "zDimension " << getZDimension() << endl;
	printStream << indentString << "\t" << "zSpacing " << getZSpacing() << endl;

	if (0 < getNHeights()) {
		MFFloat *height = (MFFloat *)getField(heightFieldString);
		printStream << indentString << "\t" << "height [" << endl;
		height->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	printStream << indentString << "\t" << "colorPerVertex " << colorPerVertex << endl;
	printStream << indentString << "\t" << "normalPerVertex " << normalPerVertex << endl;
	printStream << indentString << "\t" << "ccw " << ccw << endl;
	printStream << indentString << "\t" << "solid " << solid << endl;
	printStream << indentString << "\t" << "creaseAngle " << getCreaseAngle() << endl;
		
	NormalNode *normal = getNormalNodes();
	if (normal != NULL) {
		if (normal->isInstanceNode() == false) {
			if (normal->getName() != NULL && strlen(normal->getName()))
				printStream << indentString << "\t" << "normal " << "DEF " << normal->getName() << " Normal {" << endl;
			else
				printStream << indentString << "\t" << "normal Normal {" << endl;
			normal->Node::outputContext(printStream, indentString, "\t");
			printStream << indentString << "\t" << "}" << endl;
		}
		else 
			printStream << indentString << "\t" << "normal USE " << normal->getName() << endl;
	}

	ColorNode *color = getColorNodes();
	if (color != NULL) {
		if (color->isInstanceNode() == false) {
			if (color->getName() != NULL && strlen(color->getName()))
				printStream << indentString << "\t" << "color " << "DEF " << color->getName() << " Color {" << endl;
			else
				printStream << indentString << "\t" << "color Color {" << endl;
			color->Node::outputContext(printStream, indentString, "\t");
			printStream << indentString << "\t" << "}" << endl;
		}
		else 
			printStream << indentString << "\t" << "color USE " << color->getName() << endl;
	}

	TextureCoordinateNode *texCoord = getTextureCoordinateNodes();
	if (texCoord != NULL) {
		if (texCoord->isInstanceNode() == false) {
			if (texCoord->getName() != NULL && strlen(texCoord->getName()))
				printStream << indentString << "\t" << "texCoord " << "DEF " << texCoord->getName() << " TextureCoordinate {" << endl;
			else
				printStream << indentString << "\t" << "texCoord TextureCoordinate {" << endl;
			texCoord->Node::outputContext(printStream, indentString, "\t");
			printStream << indentString << "\t" << "}" << endl;
		}
		else 
			printStream << indentString << "\t" << "texCoord USE " << texCoord->getName() << endl;
	}
}

////////////////////////////////////////////////
//	GroupingNode::recomputeBoundingBox
////////////////////////////////////////////////

void ElevationGridNode::initialize() 
{
	if (!isInitialized()) {
#ifdef SUPPORT_OPENGL
		recomputeDisplayList();
#endif
		recomputeBoundingBox();
		setInitialized(true);
	}
}

////////////////////////////////////////////////
//	GroupingNode::recomputeBoundingBox
////////////////////////////////////////////////

void ElevationGridNode::recomputeBoundingBox()
{
	float xSize = getXDimension()*getXSpacing();
	float zSize = getZDimension()*getZSpacing();

	setBoundingBoxCenter(xSize/2.0f, 0.0f, zSize/2.0f);
	setBoundingBoxSize(xSize, 0.0f, zSize);
}

////////////////////////////////////////////////
//	GroupingNode::recomputeDisplayList
////////////////////////////////////////////////

#ifdef SUPPORT_OPENGL

static void DrawElevationGrid(ElevationGridNode *eg)
{
	int xDimension = eg->getXDimension();
	int zDimension = eg->getZDimension();

	int nPoints = xDimension * zDimension;

	float xSpacing = eg->getXSpacing();
	float zSpacing = eg->getZSpacing();

	int x, z;

	SFVec3f *point = new SFVec3f[nPoints];
	for (x=0; x<xDimension; x++) {
		for (z=0; z<zDimension; z++) {
			float xpos = xSpacing * x;
			float ypos = eg->getHeight(x + z*zDimension);
			float zpos = zSpacing * z;
			point[x + z*xDimension].setValue(xpos, ypos, zpos);
		}
	}
	
	ColorNode				*color		= eg->getColorNodes();
	NormalNode				*normal		= eg->getNormalNodes();
	TextureCoordinateNode	*texCoord	= eg->getTextureCoordinateNodes();

	bool	bColorPerVertex		= eg->getColorPerVertex();
	bool	bNormalPerVertex	= eg->getNormalPerVertex();

	bool ccw = eg->getCCW();
	if (ccw == true)
		glFrontFace(GL_CCW);
	else
		glFrontFace(GL_CW);

	bool solid = eg->getSolid();
	if (solid == false)
		glDisable(GL_CULL_FACE);
	else
		glEnable(GL_CULL_FACE);

	glNormal3f(0.0f, 1.0f, 0.0f);
	for (x=0; x<xDimension-1; x++) {
		for (z=0; z<zDimension-1; z++) {

			int n;

			if (bColorPerVertex == false && color) {
				float	egColor[4]; egColor[3] = 1.0f;
				color->getColor(x + z*zDimension, egColor);
				glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, egColor);
//				glColor3fv(egColor);
			}
			if (bNormalPerVertex == false && normal) {
				float egNormal[3];
				normal->getVector(x + z*zDimension, egNormal);
				glNormal3fv(egNormal);
			}

			float	egPoint[4][3]; 
			float	egColor[4][4]; 
			float	egNormal[4][3];
			float	egTexCoord[4][2];

			egColor[0][3] = egColor[1][3] = egColor[2][3] = egColor[3][3] = 1.0f;

			for (n=0; n<4; n++) {
				
				int xIndex = x + ((n < 2) ? 0 : 1);
				int zIndex = z + (n%2);
				int index = xIndex + zIndex*xDimension;

				if (bColorPerVertex == true && color)
					color->getColor(index, egColor[n]);

				if (bNormalPerVertex == true && normal)
					normal->getVector(index, egNormal[n]);

				if (texCoord)
					texCoord->getPoint(index, egTexCoord[n]);
				else {
					egTexCoord[n][0] = (float)xIndex / (float)(xDimension-1);
					egTexCoord[n][1] = (float)zIndex / (float)(zDimension-1);
				}

				point[index].getValue(egPoint[n]);
			}
	
			glBegin(GL_POLYGON);
			for (n=0; n<3; n++) {
				if (bColorPerVertex == true && color) {
					glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, egColor[n]);
//					glColor3fv(egColor);
				}
				if (bNormalPerVertex == true && normal)
					glNormal3fv(egNormal[n]);
				glTexCoord2fv(egTexCoord[n]);
				glVertex3fv(egPoint[n]);
			}
 			glEnd();

			glBegin(GL_POLYGON);
			for (n=3; 0<n; n--) {
				if (bColorPerVertex == true && color) {
					glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, egColor[n]);
//					glColor3fv(egColor);
				}
				if (bNormalPerVertex == true && normal)
					glNormal3fv(egNormal[n]);
				glTexCoord2fv(egTexCoord[n]);
				glVertex3fv(egPoint[n]);
			}
 			glEnd();
		}
	}

	if (ccw == false)
		glFrontFace(GL_CCW);

	if (solid == false)
		glEnable(GL_CULL_FACE);

	delete []point;
}

void ElevationGridNode::recomputeDisplayList()
{
	unsigned int nCurrentDisplayList = getDisplayList();
	if (0 < nCurrentDisplayList)
		glDeleteLists(nCurrentDisplayList, 1);

	unsigned int nNewDisplayList = glGenLists(1);
	glNewList(nNewDisplayList, GL_COMPILE);
		DrawElevationGrid(this);
	glEndList();

	setDisplayList(nNewDisplayList);
}

#endif
