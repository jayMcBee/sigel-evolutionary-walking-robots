/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	vrmlfields.h
*
******************************************************************/

#ifndef _VRMLFIELD_H_
#define _VRMLFIELD_H_

#include "Field.h"
#include "SFBool.h"
#include "SFVec2f.h"
#include "SFVec3f.h"
#include "SFColor.h"
#include "SFRotation.h"
#include "SFMatrix.h"
#include "SFString.h"
#include "SFTime.h"
#include "SFInt32.h"
#include "SFFloat.h"
#include "SFImage.h"
#include "SFNode.h"

#include "MField.h"
#include "MFVec2f.h"
#include "MFVec3f.h"
#include "MFColor.h"
#include "MFRotation.h"
#include "MFInt32.h"
#include "MFTime.h"
#include "MFFloat.h"
#include "MFString.h"

#endif

