/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	BackgroundNode.cpp
*
******************************************************************/

#include "BackgroundNode.h"

BackgroundNode::BackgroundNode() 
{
	setHeaderFlag(false);
	setType(backgroundNodeString);

	// groundColor exposed field
	MFColor *groundColor = new MFColor();
	addExposedField(groundColorFieldString, groundColor);

	// skyColor exposed field
	MFColor *skyColor = new MFColor();
	addExposedField(skyColorFieldString, skyColor);

	// groundAngle exposed field
	MFFloat *groundAngle = new MFFloat();
	addExposedField(groundAngleFieldString, groundAngle);

	// skyAngle exposed field
	MFFloat *skyAngle = new MFFloat();
	addExposedField(skyAngleFieldString, skyAngle);

	// url exposed field
	MFString *frontUrl = new MFString();
	addExposedField(frontUrlFieldString, frontUrl);

	// url exposed field
	MFString *backUrl = new MFString();
	addExposedField(backUrlFieldString, backUrl);

	// url exposed field
	MFString *leftUrl = new MFString();
	addExposedField(leftUrlFieldString, leftUrl);

	// url exposed field
	MFString *rightUrl = new MFString();
	addExposedField(rightUrlFieldString, rightUrl);

	// url exposed field
	MFString *topUrl = new MFString();
	addExposedField(topUrlFieldString, topUrl);

	// url exposed field
	MFString *bottomUrl = new MFString();
	addExposedField(bottomUrlFieldString, bottomUrl);
}

BackgroundNode::~BackgroundNode() 
{
}

////////////////////////////////////////////////
// groundColor
////////////////////////////////////////////////

void BackgroundNode::addGroundColor(float value[]) 
{
	MFColor *groundColor = (MFColor *)getExposedField(groundColorFieldString);
	groundColor->addValue(value);
}

int BackgroundNode::getNGroundColors() 
{
	MFColor *groundColor = (MFColor *)getExposedField(groundColorFieldString);
	return groundColor->getSize();
}

void BackgroundNode::getGroundColor(int index, float value[]) 
{
	MFColor *groundColor = (MFColor *)getExposedField(groundColorFieldString);
	groundColor->get1Value(index, value);
}

////////////////////////////////////////////////
// skyColor
////////////////////////////////////////////////

void BackgroundNode::addSkyColor(float value[]) 
{
	MFColor *skyColor = (MFColor *)getExposedField(skyColorFieldString);
	skyColor->addValue(value);
}

int BackgroundNode::getNSkyColors() 
{
	MFColor *skyColor = (MFColor *)getExposedField(skyColorFieldString);
	return skyColor->getSize();
}

void BackgroundNode::getSkyColor(int index, float value[]) 
{
	MFColor *skyColor = (MFColor *)getExposedField(skyColorFieldString);
	skyColor->get1Value(index, value);
}

////////////////////////////////////////////////
// groundAngle
////////////////////////////////////////////////

void BackgroundNode::addGroundAngle(float value) 
{
	MFFloat *groundAngle = (MFFloat *)getExposedField(groundAngleFieldString);
	groundAngle->addValue(value);
}

int BackgroundNode::getNGroundAngles() 
{
	MFFloat *groundAngle = (MFFloat *)getExposedField(groundAngleFieldString);
	return groundAngle->getSize();
}

float BackgroundNode::getGroundAngle(int index) 
{
	MFFloat *groundAngle = (MFFloat *)getExposedField(groundAngleFieldString);
	return groundAngle->get1Value(index);
}

////////////////////////////////////////////////
// skyAngle
////////////////////////////////////////////////

void BackgroundNode::addSkyAngle(float value) 
{
	MFFloat *skyAngle = (MFFloat *)getExposedField(skyAngleFieldString);
	skyAngle->addValue(value);
}

int BackgroundNode::getNSkyAngles() 
{
	MFFloat *skyAngle = (MFFloat *)getExposedField(skyAngleFieldString);
	return skyAngle->getSize();
}

float BackgroundNode::getSkyAngle(int index) 
{
	MFFloat *skyAngle = (MFFloat *)getExposedField(skyAngleFieldString);
	return skyAngle->get1Value(index);
}

////////////////////////////////////////////////
// frontUrl
////////////////////////////////////////////////

void BackgroundNode::addFrontUrl(String value) 
{
	MFString *frontUrl = (MFString *)getExposedField(frontUrlFieldString);
	frontUrl->addValue(value);
}

int BackgroundNode::getNFrontUrls() 
{
	MFString *frontUrl = (MFString *)getExposedField(frontUrlFieldString);
	return frontUrl->getSize();
}

String BackgroundNode::getFrontUrl(int index) 
{
	MFString *frontUrl = (MFString *)getExposedField(frontUrlFieldString);
	return frontUrl->get1Value(index);
}

////////////////////////////////////////////////
// backUrl
////////////////////////////////////////////////

void BackgroundNode::addBackUrl(String value) 
{
	MFString *backUrl = (MFString *)getExposedField(backUrlFieldString);
	backUrl->addValue(value);
}

int BackgroundNode::getNBackUrls() 
{
	MFString *backUrl = (MFString *)getExposedField(backUrlFieldString);
	return backUrl->getSize();
}

String BackgroundNode::getBackUrl(int index) 
{
	MFString *backUrl = (MFString *)getExposedField(backUrlFieldString);
	return backUrl->get1Value(index);
}

////////////////////////////////////////////////
// leftUrl
////////////////////////////////////////////////

void BackgroundNode::addLeftUrl(String value) 
{
	MFString *leftUrl = (MFString *)getExposedField(leftUrlFieldString);
	leftUrl->addValue(value);
}

int BackgroundNode::getNLeftUrls() 
{
	MFString *leftUrl = (MFString *)getExposedField(leftUrlFieldString);
	return leftUrl->getSize();
}

String BackgroundNode::getLeftUrl(int index) 
{
	MFString *leftUrl = (MFString *)getExposedField(leftUrlFieldString);
	return leftUrl->get1Value(index);
}

////////////////////////////////////////////////
// rightUrl
////////////////////////////////////////////////

void BackgroundNode::addRightUrl(String value) 
{
	MFString *rightUrl = (MFString *)getExposedField(rightUrlFieldString);
	rightUrl->addValue(value);
}

int BackgroundNode::getNRightUrls() 
{
	MFString *rightUrl = (MFString *)getExposedField(rightUrlFieldString);
	return rightUrl->getSize();
}

String BackgroundNode::getRightUrl(int index) 
{
	MFString *rightUrl = (MFString *)getExposedField(rightUrlFieldString);
	return rightUrl->get1Value(index);
}

////////////////////////////////////////////////
// topUrl
////////////////////////////////////////////////

void BackgroundNode::addTopUrl(String value) 
{
	MFString *topUrl = (MFString *)getExposedField(topUrlFieldString);
	topUrl->addValue(value);
}

int BackgroundNode::getNTopUrls() 
{
	MFString *topUrl = (MFString *)getExposedField(topUrlFieldString);
	return topUrl->getSize();
}

String BackgroundNode::getTopUrl(int index) 
{
	MFString *topUrl = (MFString *)getExposedField(topUrlFieldString);
	return topUrl->get1Value(index);
}

////////////////////////////////////////////////
// bottomUrl
////////////////////////////////////////////////

void BackgroundNode::addBottomUrl(String value) 
{
	MFString *bottomUrl = (MFString *)getExposedField(bottomUrlFieldString);
	bottomUrl->addValue(value);
}

int BackgroundNode::getNBottomUrls() 
{
	MFString *bottomUrl = (MFString *)getExposedField(bottomUrlFieldString);
	return bottomUrl->getSize();
}

String BackgroundNode::getBottomUrl(int index) 
{
	MFString *bottomUrl = (MFString *)getExposedField(bottomUrlFieldString);
	return bottomUrl->get1Value(index);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

BackgroundNode *BackgroundNode::next() 
{
	return (BackgroundNode *)Node::next(getType());
}

BackgroundNode *BackgroundNode::nextTraversal() 
{
	return (BackgroundNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	Virtual functions
////////////////////////////////////////////////
	
bool BackgroundNode::isChildNodeType(Node *node)
{
	return false;
}

void BackgroundNode::initialize() 
{
}

void BackgroundNode::uninitialize() 
{
}

void BackgroundNode::update() 
{
}

void BackgroundNode::outputContext(ostream &printStream, String indentString) 
{
	if (0 < getNGroundColors()) {
		MFColor *groundColor = (MFColor *)getExposedField(groundColorFieldString);
		printStream << indentString << "\t" << "groundColor [" << endl;
		groundColor->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNSkyColors()) {
		MFColor *skyColor = (MFColor *)getExposedField(skyColorFieldString);
		printStream << indentString << "\t" << "skyColor [" << endl;
		skyColor->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNGroundAngles()) {
		MFFloat *groundAngle = (MFFloat *)getExposedField(groundAngleFieldString);
		printStream << indentString << "\t" << "groundAngle [" << endl;
		groundAngle->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNSkyAngles()) {
		MFFloat *skyAngle = (MFFloat *)getExposedField(skyAngleFieldString);
		printStream << indentString << "\t" << "skyAngle [" << endl;
		skyAngle->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNFrontUrls()) {
		MFString *frontUrl = (MFString *)getExposedField(frontUrlFieldString);
		printStream << indentString << "\t" << "frontUrl [" << endl;
		frontUrl->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNBackUrls()) {
		MFString *backUrl = (MFString *)getExposedField(backUrlFieldString);
		printStream << indentString << "\t" << "backUrl [" << endl;
		backUrl->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNLeftUrls()) {
		MFString *leftUrl = (MFString *)getExposedField(leftUrlFieldString);
		printStream << indentString << "\t" << "leftUrl [" << endl;
		leftUrl->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNRightUrls()) {
		MFString *rightUrl = (MFString *)getExposedField(rightUrlFieldString);
		printStream << indentString << "\t" << "rightUrl [" << endl;
		rightUrl->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNTopUrls()) {
		MFString *topUrl = (MFString *)getExposedField(topUrlFieldString);
		printStream << indentString << "\t" << "topUrl [" << endl;
		topUrl->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNBottomUrls()) {
		MFString *bottomUrl = (MFString *)getExposedField(bottomUrlFieldString);
		printStream << indentString << "\t" << "bottomUrl [" << endl;
		bottomUrl->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}
