/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	ScalarInterpolatorNode.cpp
*
******************************************************************/

#include "ScalarInterpolatorNode.h"
#include "Node.h"

ScalarInterpolatorNode::ScalarInterpolatorNode() 
{
	setHeaderFlag(false);
	setType(scalarInterpolatorNodeString);

	// key exposed field
	MFFloat *key = new MFFloat();
	addExposedField(keyFieldString, key);

	// keyValue exposed field
	MFFloat *keyValue = new MFFloat();
	addExposedField(keyValueFieldString, keyValue);

	// set_fraction eventIn field
	SFFloat *setFraction = new SFFloat(0.0f);
	addEventIn(fractionFieldString, setFraction);

	// value_changed eventOut field
	SFFloat *valueChanged = new SFFloat(0.0f);
	addEventOut(valueFieldString, valueChanged);
}

ScalarInterpolatorNode::~ScalarInterpolatorNode() 
{
}

////////////////////////////////////////////////
//	key
////////////////////////////////////////////////
	
void ScalarInterpolatorNode::addKey(float value) 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	key->addValue(value);
}

int ScalarInterpolatorNode::getNKeys() 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	return key->getSize();
}

float ScalarInterpolatorNode::getKey(int index) 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	return key->get1Value(index);
}

Field *ScalarInterpolatorNode::getKeyField() 
{
	return getExposedField(keyFieldString);
}

////////////////////////////////////////////////
//	keyValue
////////////////////////////////////////////////
	
void ScalarInterpolatorNode::addKeyValue(float value) 
{
	MFFloat *keyValue = (MFFloat *)getExposedField(keyValueFieldString);
	keyValue->addValue(value);
}

int ScalarInterpolatorNode::getNKeyValues() 
{
	MFFloat *keyValue = (MFFloat *)getExposedField(keyValueFieldString);
	return keyValue->getSize();
}
	
float ScalarInterpolatorNode::getKeyValue(int index) 
{
	MFFloat *keyValue = (MFFloat *)getExposedField(keyValueFieldString);
	return keyValue->get1Value(index);
}

Field *ScalarInterpolatorNode::getKeyValueField() 
{
	return getExposedField(keyValueFieldString);
}

////////////////////////////////////////////////
//	fraction
////////////////////////////////////////////////
	
void ScalarInterpolatorNode::setFraction(float value) 
{
	SFFloat *fraction = (SFFloat *)getEventIn(fractionFieldString);
	fraction->setValue(value);
}

float ScalarInterpolatorNode::getFraction() 
{
	SFFloat *fraction = (SFFloat *)getEventIn(fractionFieldString);
	return fraction->getValue();
}

Field *ScalarInterpolatorNode::getFractionField() 
{
	return getEventIn(fractionFieldString);
}

Field *ScalarInterpolatorNode::getValueField() 
{
	return getEventOut(valueFieldString);
}

////////////////////////////////////////////////
//	value
////////////////////////////////////////////////
	
void ScalarInterpolatorNode::setValue(float vector) 
{
	SFFloat *value = (SFFloat *)getEventOut(valueFieldString);
	value->setValue(vector);
}

float ScalarInterpolatorNode::getValue() 
{
	SFFloat *value = (SFFloat *)getEventOut(valueFieldString);
	return value->getValue();
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool ScalarInterpolatorNode::isChildNodeType(Node *node)
{
	return false;
}

void ScalarInterpolatorNode::initialize() 
{
}

void ScalarInterpolatorNode::uninitialize() 
{
}

void ScalarInterpolatorNode::update() 
{

	float fraction = getFraction();
	int index = -1;
	int nKey = getNKeys();
	for (int n=0; n<(nKey-1); n++) {
		if (getKey(n) <= fraction && fraction <= getKey(n+1)) {
			index = n;
			break;
		}
	}
	if (index == -1)
		return;

	float scale = (fraction - getKey(index)) / (getKey(index+1) - getKey(index));

	float value1 = getKeyValue(index);
	float value2 = getKeyValue(index+1);
	float valueOut = value1 + (value2 - value1)*scale;

	setValue(valueOut);
	sendEvent(getValueField());
}

////////////////////////////////////////////////
//	Output
////////////////////////////////////////////////

void ScalarInterpolatorNode::outputContext(ostream &printStream, String indentString) 
{
	if (0 < getNKeys()) {
		MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
		printStream << indentString << "\tkey [" << endl;
		key->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t]" << endl;
	}

	if (0 < getNKeyValues()) {
		MFFloat *keyValue = (MFFloat *)getExposedField(keyValueFieldString);
		printStream << indentString << "\tkeyValue [" << endl;
		keyValue->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t]" << endl;
	}
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

ScalarInterpolatorNode *ScalarInterpolatorNode::next() 
{
	return (ScalarInterpolatorNode *)Node::next(getType());
}

ScalarInterpolatorNode *ScalarInterpolatorNode::nextTraversal() 
{
	return (ScalarInterpolatorNode *)Node::nextTraversalByType(getType());
}
