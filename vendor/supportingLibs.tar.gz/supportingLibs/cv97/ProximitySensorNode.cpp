/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	ProximitySensorNode.cpp
*
******************************************************************/

#include "SceneGraph.h"

ProximitySensorNode::ProximitySensorNode() 
{
	setHeaderFlag(false);
	setType(proximitySensorNodeString);

	// enabled exposed field
	SFBool *enabled = new SFBool(true);
	addExposedField(enabledFieldString, enabled);

	// center exposed field
	SFVec3f *center = new SFVec3f(0.0f, 0.0f, 0.0f);
	addExposedField(centerFieldString, center);

	// size exposed field
	SFVec3f *size = new SFVec3f(0.0f, 0.0f, 0.0f);
	addExposedField(sizeFieldString, size);

		
	// isActive eventOut field
	SFBool *isActive = new SFBool(false);
	addEventOut(isActiveFieldString, isActive);

	// position eventOut field
	SFVec3f *position = new SFVec3f(0.0f, 0.0f, 0.0f);
	addEventOut(positionFieldString, position);

	// orientation eventOut field
	SFRotation *orientation = new SFRotation(0.0f, 0.0f, 1.0f, 0.0f);
	addEventOut(orientationFieldString, orientation);

	// enterTime eventOut field
	SFTime *enterTime = new SFTime(0.0f);
	addEventOut(enterTimeFieldString, enterTime);

	// exitTime eventOut field
	SFTime *exitTime = new SFTime(0.0f);
	addEventOut(exitTimeFieldString, exitTime);

	
	// display list field
	SFBool *inRegion = new SFBool(false);
	inRegion->setName(inRegionPrivateFieldString);
	addPrivateField(inRegion);
}

ProximitySensorNode::~ProximitySensorNode() 
{
}

////////////////////////////////////////////////
//	Enabled
////////////////////////////////////////////////
	
void ProximitySensorNode::setEnabled(bool value) 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	bEnabled->setValue(value);
}

void ProximitySensorNode::setEnabled(int value) 
{
	setEnabled(value ? true : false);
}

bool ProximitySensorNode::getEnabled() 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	return bEnabled->getValue();
}

bool ProximitySensorNode::isEnabled() 
{
	return getEnabled();
}

////////////////////////////////////////////////
//	Center
////////////////////////////////////////////////
	
void ProximitySensorNode::setCenter(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(centerFieldString);
	sfvec3f->setValue(value);
}

void ProximitySensorNode::setCenter(float x, float y, float z) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(centerFieldString);
	sfvec3f->setValue(x, y, z);
}

void ProximitySensorNode::getCenter(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(centerFieldString);
	sfvec3f->getValue(value);
}

////////////////////////////////////////////////
//	Size
////////////////////////////////////////////////
	
void ProximitySensorNode::setSize(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(sizeFieldString);
	sfvec3f->setValue(value);
}

void ProximitySensorNode::setSize(float x, float y, float z) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(sizeFieldString);
	sfvec3f->setValue(x, y, z);
}

void ProximitySensorNode::getSize(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getExposedField(sizeFieldString);
	sfvec3f->getValue(value);
}

////////////////////////////////////////////////
//	isActive
////////////////////////////////////////////////
	
void ProximitySensorNode::setIsActive(bool  value) 
{
	SFBool *sfbool = (SFBool *)getEventOut(isActiveFieldString);
	sfbool->setValue(value);
}

void ProximitySensorNode::setIsActive(int value) 
{
	setIsActive(value ? true : false);
}

bool ProximitySensorNode::getIsActive() 
{
	SFBool *sfbool = (SFBool *)getEventOut(isActiveFieldString);
	return sfbool->getValue();
}

bool ProximitySensorNode::isActive() 
{
	return getIsActive();
}

////////////////////////////////////////////////
//	Position
////////////////////////////////////////////////
	
void ProximitySensorNode::setPositionChanged(float value[]) 
{
	SFVec3f *position = (SFVec3f *)getEventOut(positionFieldString);
	position->setValue(value);
}

void ProximitySensorNode::setPositionChanged(float x, float y, float z) 
{
	SFVec3f *position = (SFVec3f *)getEventOut(positionFieldString);
	position->setValue(x, y, z);
}

void ProximitySensorNode::getPositionChanged(float value[]) 
{
	SFVec3f *position = (SFVec3f *)getEventOut(positionFieldString);
	position->getValue(value);
}

////////////////////////////////////////////////
//	Orientation
////////////////////////////////////////////////
	
void ProximitySensorNode::setOrientationChanged(float value[]) 
{
	SFRotation *orientation = (SFRotation *)getEventOut(orientationFieldString);
	orientation->setValue(value);
}

void ProximitySensorNode::setOrientationChanged(float x, float y, float z, float rot) 
{
	SFRotation *orientation = (SFRotation *)getEventOut(orientationFieldString);
	orientation->setValue(x, y, z, rot);
}

void ProximitySensorNode::getOrientationChanged(float value[]) 
{
	SFRotation *orientation = (SFRotation *)getEventOut(orientationFieldString);
	orientation->getValue(value);
}

////////////////////////////////////////////////
//	EnterTime
////////////////////////////////////////////////
	
void ProximitySensorNode::setEnterTime(double value) 
{
	SFTime *time = (SFTime *)getEventOut(enterTimeFieldString);
	time->setValue(value);
}

double ProximitySensorNode::getEnterTime() 
{
	SFTime *time = (SFTime *)getEventOut(enterTimeFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	ExitTime
////////////////////////////////////////////////
	
void ProximitySensorNode::setExitTime(double value) 
{
	SFTime *time = (SFTime *)getEventOut(exitTimeFieldString);
	time->setValue(value);
}

double ProximitySensorNode::getExitTime() 
{
	SFTime *time = (SFTime *)getEventOut(exitTimeFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	inRegion
////////////////////////////////////////////////

void ProximitySensorNode::setInRegion(bool value) 
{
	SFBool *inRegion = (SFBool *)getPrivateField(inRegionPrivateFieldString);
	inRegion->setValue(value);
}

bool ProximitySensorNode::inRegion() 
{
	SFBool *inRegion = (SFBool *)getPrivateField(inRegionPrivateFieldString);
	return inRegion->getValue();
} 

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

ProximitySensorNode *ProximitySensorNode::next() 
{
	return (ProximitySensorNode *)Node::next(getType());
}

ProximitySensorNode *ProximitySensorNode::nextTraversal() 
{
	return (ProximitySensorNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool ProximitySensorNode::isChildNodeType(Node *node)
{
	return false;
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void ProximitySensorNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *enabled = (SFBool *)getExposedField(enabledFieldString);
	SFVec3f *center = (SFVec3f *)getExposedField(centerFieldString);
	SFVec3f *size = (SFVec3f *)getExposedField(sizeFieldString);

	printStream << indentString << "\t" << "enabled " << enabled << endl;
	printStream << indentString << "\t" << "center " << center << endl;
	printStream << indentString << "\t" << "size " << size << endl;
}

////////////////////////////////////////////////
//	ProximitySensorNode::initialize
////////////////////////////////////////////////

void ProximitySensorNode::initialize() 
{
	setInRegion(false);
}

////////////////////////////////////////////////
//	ProximitySensorNode::uninitialize
////////////////////////////////////////////////

void ProximitySensorNode::uninitialize() 
{
}

////////////////////////////////////////////////
//	ProximitySensorNode::update
////////////////////////////////////////////////

static bool isRegion(float vpos[], float center[], float size[])
{
	for (int n=0; n<3; n++) {
		if (vpos[n] < center[n] - size[n]/2.0f)
			return false;
		if (center[n] + size[n]/2.0f < vpos[n])
			return false;
	}

	return true;
}

void ProximitySensorNode::update() 
{
	if (!isEnabled())
		return;

	SceneGraph *sg = getSceneGraph();
	if (!sg)
		return;

	ViewpointNode *vpoint = sg->getViewpointNode();
	if (vpoint == NULL)
		vpoint = sg->getDefaultViewpointNode();

	float vpos[3];
	vpoint->getPosition(vpos);

	float center[3];
	getCenter(center);

	float size[3];
	getSize(size);

	if (inRegion() == false) {
		if (isRegion(vpos, center, size) == true) {
			setInRegion(true);
			double time = GetCurrentSystemTime();
			setEnterTime(time);
			sendEvent(getEventOut(enterTimeFieldString));
			setIsActive(true);
			sendEvent(getEventOut(isActiveFieldString));
		}
	}
	else {
		if (isRegion(vpos, center, size) == false) {
			setInRegion(false);
			double time = GetCurrentSystemTime();
			setExitTime(time);
			sendEvent(getEventOut(exitTimeFieldString));
			setIsActive(false);
			sendEvent(getEventOut(isActiveFieldString));
		}
	}
}

