/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	OrientationInterpolatorNode.cpp
*
******************************************************************/

#include "OrientationInterpolatorNode.h"

OrientationInterpolatorNode::OrientationInterpolatorNode() 
{
	setHeaderFlag(false);
	setType(orientationInterpolatorNodeString);

	// key exposed field
	MFFloat *key = new MFFloat();
	addExposedField(keyFieldString, key);

	// keyValue exposed field
	MFRotation *keyValue = new MFRotation();
	addExposedField(keyValueFieldString, keyValue);

	// set_fraction eventIn field
	SFFloat *setFraction = new SFFloat(0.0f);
	addEventIn(fractionFieldString, setFraction);

	// value_changed eventOut field
	SFRotation *valueChanged = new SFRotation(0.0f, 0.0f, 1.0f, 0.0f);
	addEventOut(valueFieldString, valueChanged);
}

OrientationInterpolatorNode::~OrientationInterpolatorNode() 
{
}

////////////////////////////////////////////////
//	key
////////////////////////////////////////////////
	
void OrientationInterpolatorNode::addKey(float value) 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	key->addValue(value);
}

int OrientationInterpolatorNode::getNKeys() 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	return key->getSize();
}

float OrientationInterpolatorNode::getKey(int index) 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	return key->get1Value(index);
}

Field *OrientationInterpolatorNode::getKeyField() 
{
	return getExposedField(keyFieldString);
}

////////////////////////////////////////////////
//	keyValue
////////////////////////////////////////////////
	
void OrientationInterpolatorNode::addKeyValue(float rotation[]) 
{
	MFRotation *keyValue = (MFRotation *)getExposedField(keyValueFieldString);
	keyValue->addValue(rotation);
}

int OrientationInterpolatorNode::getNKeyValues() 
{
	MFRotation *keyValue = (MFRotation *)getExposedField(keyValueFieldString);
	return keyValue->getSize();
}
	
void OrientationInterpolatorNode::getKeyValue(int index, float rotation[]) 
{
	MFRotation *keyValue = (MFRotation *)getExposedField(keyValueFieldString);
	keyValue->get1Value(index, rotation);
}

Field *OrientationInterpolatorNode::getKeyValueField() 
{
	return getExposedField(keyValueFieldString);
}

////////////////////////////////////////////////
//	fraction
////////////////////////////////////////////////
	
void OrientationInterpolatorNode::setFraction(float value) 
{
	SFFloat *fraction = (SFFloat *)getEventIn(fractionFieldString);
	fraction->setValue(value);
}

float OrientationInterpolatorNode::getFraction() 
{
	SFFloat *fraction = (SFFloat *)getEventIn(fractionFieldString);
	return fraction->getValue();
}

Field *OrientationInterpolatorNode::getFractionField() 
{
	return getEventIn(fractionFieldString);
}

////////////////////////////////////////////////
//	value
////////////////////////////////////////////////
	
void OrientationInterpolatorNode::setValue(float rotation[]) 
{
	SFRotation *value = (SFRotation *)getEventOut(valueFieldString);
	value->setValue(rotation);
}

void OrientationInterpolatorNode::getValue(float rotation[]) 
{
	SFRotation *value = (SFRotation *)getEventOut(valueFieldString);
	value->getValue(rotation);
}

Field *OrientationInterpolatorNode::getValueField() 
{
	return getEventOut(valueFieldString);
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool OrientationInterpolatorNode::isChildNodeType(Node *node)
{
	return false;
}

void OrientationInterpolatorNode::initialize() 
{
}

void OrientationInterpolatorNode::uninitialize() 
{
}

void OrientationInterpolatorNode::update() 
{
	int	n;

	float fraction = getFraction();
	int index = -1;
	int nKey = getNKeys();
	for (n=0; n<(nKey-1); n++) {
		if (getKey(n) <= fraction && fraction <= getKey(n+1)) {
			index = n;
			break;
		}
	}
	if (index == -1)
		return;

	float scale = (fraction - getKey(index)) / (getKey(index+1) - getKey(index));

	float rotation1[4];
	float rotation2[4];
	float rotationOut[4];

	getKeyValue(index, rotation1);
	getKeyValue(index+1, rotation2);

	for (n=0; n<4; n++)
		rotationOut[n] = rotation1[n] + (rotation2[n] - rotation1[n])*scale;

	setValue(rotationOut);
	sendEvent(getValueField());
}

////////////////////////////////////////////////
//	Output
////////////////////////////////////////////////

void OrientationInterpolatorNode::outputContext(ostream& printStream, String indentString) 
{
	if (0 < getNKeys()) {
		MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
		printStream << indentString << "\tkey [" << endl;
		key->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t]" << endl;
	}

	if (0 < getNKeyValues()) {
		MFRotation *keyValue = (MFRotation *)getExposedField(keyValueFieldString);
		printStream << indentString << "\tkeyValue [" << endl;
		keyValue->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t]" << endl;
	}
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

OrientationInterpolatorNode *OrientationInterpolatorNode::next() 
{
	return (OrientationInterpolatorNode *)Node::next(getType());
}

OrientationInterpolatorNode *OrientationInterpolatorNode::nextTraversal() 
{
	return (OrientationInterpolatorNode *)Node::nextTraversalByType(getType());
}

