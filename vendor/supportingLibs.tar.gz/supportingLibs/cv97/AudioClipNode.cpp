/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	AudioClipNode.cpp
*
******************************************************************/

#ifdef WIN32
#include <windows.h>
#endif

#include "AudioClipNode.h"

AudioClipNode::AudioClipNode() 
{
	setHeaderFlag(false);
	setType(audioClipNodeString);

	// description exposed field
	SFString *description = new SFString("");
	addExposedField(descriptionFieldString, description);

	// loop exposed field
	SFBool *loop = new SFBool(false);
	addExposedField(loopFieldString, loop);

	// startTime exposed field
	SFTime *startTime = new SFTime(0.0f);
	addExposedField(startTimeFieldString, startTime);

	// stopTime exposed field
	SFTime *stopTime = new SFTime(0.0f);
	addExposedField(stopTimeFieldString, stopTime);

	// pitch exposed field
	SFFloat *pitch = new SFFloat(1.0f);
	addExposedField(pitchFieldString, pitch);

	// url exposed field
	MFString *url = new MFString();
	addExposedField(urlFieldString, url);

	// isActive eventOut field
	SFBool *isActive = new SFBool(false);
	addEventOut(isActiveFieldString, isActive);

	// time eventOut field
	SFTime *durationChanged = new SFTime(-1.0f);
	addEventOut(durationFieldString, durationChanged);
}

AudioClipNode::~AudioClipNode() 
{
}

////////////////////////////////////////////////
//	Description
////////////////////////////////////////////////

void AudioClipNode::setDescription(String value) 
{
	SFString *description = (SFString *)getExposedField(descriptionFieldString);
	description->setValue(value);
}

String AudioClipNode::getDescription() 
{
	SFString *description = (SFString *)getExposedField(descriptionFieldString);
	return description->getValue();
}

////////////////////////////////////////////////
//	Loop
////////////////////////////////////////////////
	
void AudioClipNode::setLoop(bool value) 
{
	SFBool *loop = (SFBool *)getExposedField(loopFieldString);
	loop->setValue(value);
}

void AudioClipNode::setLoop(int value) 
{
	setLoop(value ? true : false);
}

bool AudioClipNode::getLoop() 
{
	SFBool *loop = (SFBool *)getExposedField(loopFieldString);
	return loop->getValue();
}

bool AudioClipNode::isLoop() 
{
	return getLoop();
}

////////////////////////////////////////////////
//	Pitch
////////////////////////////////////////////////
	
void AudioClipNode::setPitch(float value) 
{
	SFFloat *pitch = (SFFloat *)getExposedField(pitchFieldString);
	pitch->setValue(value);
}

float AudioClipNode::getPitch() 
{
	SFFloat *pitch = (SFFloat *)getExposedField(pitchFieldString);
	return pitch->getValue();
}

////////////////////////////////////////////////
//	Start time
////////////////////////////////////////////////
	
void AudioClipNode::setStartTime(double value) 
{
	SFTime *time = (SFTime *)getExposedField(startTimeFieldString);
	time->setValue(value);
}

double AudioClipNode::getStartTime() 
{
	SFTime *time = (SFTime *)getExposedField(startTimeFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	Stop time
////////////////////////////////////////////////
	
void AudioClipNode::setStopTime(double value) 
{
	SFTime *time = (SFTime *)getExposedField(stopTimeFieldString);
	time->setValue(value);
}

double AudioClipNode::getStopTime() 
{
	SFTime *time = (SFTime *)getExposedField(stopTimeFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	isActive
////////////////////////////////////////////////
	
void AudioClipNode::setIsActive(bool  value) 
{
	SFBool *field = (SFBool *)getEventOut(isActiveFieldString);
	field->setValue(value);
}

bool AudioClipNode::getIsActive() 
{
	SFBool *field = (SFBool *)getEventOut(isActiveFieldString);
	return field->getValue();
}

bool AudioClipNode::isActive() 
{
	SFBool *field = (SFBool *)getEventOut(isActiveFieldString);
	return field->getValue();
}

Field *AudioClipNode::getIsActiveField() 
{
	return getEventOut(isActiveFieldString);
}

////////////////////////////////////////////////
//	duration_changed
////////////////////////////////////////////////
	
void AudioClipNode::setDurationChanged(double value) 
{
	SFTime *time = (SFTime *)getEventOut(durationFieldString);
	time->setValue(value);
}

double AudioClipNode::getDurationChanged() 
{
	SFTime *time = (SFTime *)getEventOut(durationFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
// Url
////////////////////////////////////////////////

void AudioClipNode::addUrl(String value) 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	url->addValue(value);
}

int AudioClipNode::getNUrls() 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	return url->getSize();
}

String AudioClipNode::getUrl(int index) 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	return url->get1Value(index);
}

void AudioClipNode::setUrl(int index, char *urlString) 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	url->set1Value(index, urlString);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

AudioClipNode *AudioClipNode::next() 
{
	return (AudioClipNode *)Node::next(getType());
}

AudioClipNode *AudioClipNode::nextTraversal() 
{
	return (AudioClipNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	Virutual functions
////////////////////////////////////////////////
	
bool AudioClipNode::isChildNodeType(Node *node)
{
	return false;
}

void AudioClipNode::outputContext(ostream &printStream, String indentString) 
{
	SFString *description = (SFString *)getExposedField(descriptionFieldString);
	printStream << indentString << "\t" << "description " << description << endl;
	
	printStream << indentString << "\t" << "pitch " << getPitch() << endl;
	printStream << indentString << "\t" << "startTime " << getStartTime() << endl;
	printStream << indentString << "\t" << "stopTime " << getStopTime() << endl;

	SFBool *loop = (SFBool *)getExposedField(loopFieldString);
	printStream << indentString << "\t" << "loop " << loop << endl;

	if (0 < getNUrls()) {
		MFString *url = (MFString *)getExposedField(urlFieldString);
		printStream << indentString << "\t" << "url [" << endl;
		url->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}

////////////////////////////////////////////////
//	Time
////////////////////////////////////////////////

void AudioClipNode::setCurrentTime(double time) 
{
	mCurrentTime = time;
}

double AudioClipNode::getCurrentTime() 
{
	return mCurrentTime;
}

////////////////////////////////////////////////
//	PlayAudioClip
////////////////////////////////////////////////

static void PlayAudioClip(AudioClipNode *ac)
{
#ifdef SUPPORT_SOUND
	if (0 < ac->getNUrls()) {
		char *filename = ac->getUrl(0);
		if (filename) {
#ifdef WIN32
			PlaySound(filename, NULL, SND_FILENAME | SND_ASYNC);
#endif
		}
	}
#endif
}

////////////////////////////////////////////////
//	StopAudioClip
////////////////////////////////////////////////

static void StopAudioClip(AudioClipNode *ac)
{
}

////////////////////////////////////////////////
//	AudioClipNode::initialize
////////////////////////////////////////////////

void AudioClipNode::initialize() 
{
	setIsActive(false);
	StopAudioClip(this);
	setCurrentTime(-1.0);
}

////////////////////////////////////////////////
//	AudioClipNode::uninitialize
////////////////////////////////////////////////

void AudioClipNode::uninitialize() 
{
	StopAudioClip(this);
}

////////////////////////////////////////////////
//	AudioClipNode::update
////////////////////////////////////////////////

void AudioClipNode::update() 
{
	double currentTime = getCurrentTime();

	if (currentTime < 0.0)
		currentTime = GetCurrentSystemTime();

	double startTime = getStartTime();
	double stopTime = getStopTime();

	bool bActive	= isActive();
	bool bLoop		= isLoop();

	if (bActive == false) {
		if (currentTime <= startTime) {
			if (bLoop == true && stopTime <= startTime)
				bActive = true;
			else if	(bLoop == true && startTime < stopTime)
				bActive = true;
			else if (bLoop == false && startTime < stopTime)
				bActive = true;

			if (bActive == true) {
				setIsActive(true);
				sendEvent(getIsActiveField());
				PlayAudioClip(this);
				setIsActive(false);
			}
		}
	}

	currentTime = GetCurrentSystemTime();
	setCurrentTime(currentTime);

/*	
	if (bActive == true) {
		if (bLoop == true && startTime < stopTime) {
			if (stopTime < currentTime)
				bActive = false;
		}
		else if (bLoop == false && stopTime <= startTime) {
			if (startTime + cycleInterval < currentTime)
				bActive = false;
		}

		if (bActive == false) {
			setIsActive(false);
			sendEvent(getIsActiveField());
		}
	}
*/
}

