/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	BindableNode.h
*
******************************************************************/

#ifndef _BINDABLENODE_H_
#define _BINDABLENODE_H_

#include "vrmlfields.h"
#include "Node.h"

class BindableNode : public Node {

public:

	BindableNode();
	virtual ~BindableNode();

	////////////////////////////////////////////////
	//	bind
	////////////////////////////////////////////////

	void setBind(bool value);
	bool  getBind();
	Field *getBindField();

	////////////////////////////////////////////////
	//	bindTime
	////////////////////////////////////////////////
	
	void setBindTime(double value);
	double getBindTime();
	Field *getBindTimeField();

	////////////////////////////////////////////////
	//	isBound
	////////////////////////////////////////////////

	void setIsBound(bool  value);
	bool  getIsBound();
	bool  isBound();
	Field *getIsBoundField();
};

#endif

