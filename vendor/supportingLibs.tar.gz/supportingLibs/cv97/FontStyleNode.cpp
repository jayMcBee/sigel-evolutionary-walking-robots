/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	FontStyleNode.cpp
*
******************************************************************/

#include <string.h>
#include "FontStyleNode.h"

FontStyleNode::FontStyleNode() 
{
	setHeaderFlag(false);
	setType(fontStyleNodeString);

	///////////////////////////
	// Field 
	///////////////////////////

	// family field
	SFString *family = new SFString("SERIF");
	family->setName(familyFieldString);
	addField(family);

	// style field
	SFString *style = new SFString("PLAIN");
	style->setName(styleFieldString);
	addField(style);

	// language field
	SFString *language = new SFString("");
	language->setName(languageFieldString);
	addField(language);

	// justify field
	MFString *justify = new MFString();
	justify->setName(justifyFieldString);
	addField(justify);

	// size field
	SFFloat *size = new SFFloat(1.0f);
	addField(sizeFieldString, size);

	// spacing field
	SFFloat *spacing = new SFFloat(1.0f);
	addField(spacingFieldString, spacing);

	// horizontal field
	SFBool *horizontal = new SFBool(true);
	addField(horizontalFieldString, horizontal);

	// leftToRight field
	SFBool *leftToRight = new SFBool(true);
	addField(leftToRightFieldString, leftToRight);

	// topToBottom field
	SFBool *topToBottom = new SFBool(true);
	addField(topToBottomFieldString, topToBottom);
}

FontStyleNode::~FontStyleNode() 
{
}

////////////////////////////////////////////////
//	Size
////////////////////////////////////////////////

void FontStyleNode::setSize(float value) 
{
	SFFloat *size = (SFFloat *)getField(sizeFieldString);
	size->setValue(value);
}

float FontStyleNode::getSize() 
{
	SFFloat *size = (SFFloat *)getField(sizeFieldString);
	return size->getValue();
}

////////////////////////////////////////////////
//	Family
////////////////////////////////////////////////
	
void FontStyleNode::setFamily(String value) 
{
	SFString *family = (SFString *)getField(familyFieldString);
	family->setValue(value);
}

String FontStyleNode::getFamily() 
{
	SFString *family = (SFString *)getField(familyFieldString);
	return family->getValue();
}

////////////////////////////////////////////////
//	Style
////////////////////////////////////////////////
	
void FontStyleNode::setStyle(String value) 
{
	SFString *style = (SFString *)getField(styleFieldString);
	style->setValue(value);
}

String FontStyleNode::getStyle() 
{
	SFString *style = (SFString *)getField(styleFieldString);
	return style->getValue();
}

////////////////////////////////////////////////
//	Language
////////////////////////////////////////////////
	
void FontStyleNode::setLanguage(String value) 
{
	SFString *language = (SFString *)getField(languageFieldString);
	language->setValue(value);
}

String FontStyleNode::getLanguage() 
{
	SFString *language = (SFString *)getField(languageFieldString);
	return language->getValue();
}

////////////////////////////////////////////////
//	Horizontal
////////////////////////////////////////////////
	
void FontStyleNode::setHorizontal(bool value) 
{
	SFBool *horizontal = (SFBool *)getField(horizontalFieldString);
	horizontal->setValue(value);
}

void FontStyleNode::setHorizontal(int value) 
{
	setHorizontal(value ? true : false);
}

bool FontStyleNode::getHorizontal() 
{
	SFBool *horizontal = (SFBool *)getField(horizontalFieldString);
	return horizontal->getValue();
}

////////////////////////////////////////////////
//	LeftToRight
////////////////////////////////////////////////
	
void FontStyleNode::setLeftToRight(bool value) 
{
	SFBool *leftToRight = (SFBool *)getField(leftToRightFieldString);
	leftToRight->setValue(value);
}

void FontStyleNode::setLeftToRight(int value) 
{
	setLeftToRight(value ? true : false);
}

bool FontStyleNode::getLeftToRight() 
{
	SFBool *leftToRight = (SFBool *)getField(leftToRightFieldString);
	return leftToRight->getValue();
}

////////////////////////////////////////////////
//	TopToBottom
////////////////////////////////////////////////
	
void FontStyleNode::setTopToBottom(bool value) 
{
	SFBool *topToBottom = (SFBool *)getField(topToBottomFieldString);
	topToBottom->setValue(value);
}

void FontStyleNode::setTopToBottom(int value) 
{
	setTopToBottom(value ? true : false);
}

bool FontStyleNode::getTopToBottom() 
{
	SFBool *topToBottom = (SFBool *)getField(topToBottomFieldString);
	return topToBottom->getValue();
}

////////////////////////////////////////////////
// Justify
////////////////////////////////////////////////

void FontStyleNode::addJustify(String value) 
{
	MFString *justify = (MFString *)getField(justifyFieldString);
	justify->addValue(value);
}

int FontStyleNode::getNJustifys() 
{
	MFString *justify = (MFString *)getField(justifyFieldString);
	return justify->getSize();
}

String FontStyleNode::getJustify(int index) 
{
	MFString *justify = (MFString *)getField(justifyFieldString);
	return justify->get1Value(index);
}

////////////////////////////////////////////////
//	Spacing
////////////////////////////////////////////////

void FontStyleNode::setSpacing(float value) 
{
	SFFloat *spacing = (SFFloat *)getField(spacingFieldString);
	spacing->setValue(value);
}

float FontStyleNode::getSpacing() 
{
	SFFloat *spacing = (SFFloat *)getField(spacingFieldString);
	return spacing->getValue();
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

FontStyleNode *FontStyleNode::next() 
{
	return (FontStyleNode *)Node::next(getType());
}

FontStyleNode *FontStyleNode::nextTraversal() 
{
	return (FontStyleNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool FontStyleNode::isChildNodeType(Node *node)
{
	return false;
}

void FontStyleNode::initialize() 
{
	Node *parentNode = getParentNode();
	if (parentNode != NULL) {
		if (parentNode->isTextNode())
			parentNode->initialize();
	}
}

void FontStyleNode::uninitialize() 
{
}

void FontStyleNode::update() 
{
}

////////////////////////////////////////////////
//	Justifymation
////////////////////////////////////////////////

void FontStyleNode::outputContext(ostream &printStream, String indentString) 
{
	SFString *family = (SFString *)getField(familyFieldString);
	SFBool *horizontal = (SFBool *)getField(horizontalFieldString);
	SFBool *leftToRight = (SFBool *)getField(leftToRightFieldString);
	SFBool *topToBottom = (SFBool *)getField(topToBottomFieldString);
	SFString *style = (SFString *)getField(styleFieldString);
	SFString *language = (SFString *)getField(languageFieldString);

	printStream << indentString << "\t" << "size " << getSize() << endl;
	printStream << indentString << "\t" << "family " << family << endl;
	printStream << indentString << "\t" << "style " << style << endl;
	printStream << indentString << "\t" << "horizontal " << horizontal << endl;
	printStream << indentString << "\t" << "leftToRight " << leftToRight << endl;
	printStream << indentString << "\t" << "topToBottom " << topToBottom << endl;
	printStream << indentString << "\t" << "language " << language << endl;
	printStream << indentString << "\t" << "spacing " << getSpacing() << endl;

	if (0 < getNJustifys()) { 
		MFString *justify = (MFString *)getField(justifyFieldString);
		printStream << indentString << "\t" << "justify [" << endl;
		justify->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}

////////////////////////////////////////////////
//	Text::getFamilyNumber
////////////////////////////////////////////////

int FontStyleNode::getFamilyNumber()
{
	char *family = getFamily();

	if (family == NULL)
		return FONTSTYLE_FAMILY_SERIF;

	if (strcmp(family, "SERIF") == 0)
		return FONTSTYLE_FAMILY_SERIF;

	if (strcmp(family, "SANS") == 0)
		return FONTSTYLE_FAMILY_SANS;

	if (strcmp(family, "TYPEWRITER") == 0)
		return FONTSTYLE_FAMILY_TYPEWRITER;

	return FONTSTYLE_FAMILY_SERIF;
}

////////////////////////////////////////////////
//	Text::getStyleNumber
////////////////////////////////////////////////

int FontStyleNode::getStyleNumber()
{
	char *style = getStyle();

	if (style == NULL)
		return FONTSTYLE_STYLE_PLAIN;

	if (strcmp(style, "PLAIN") == 0)
		return FONTSTYLE_STYLE_PLAIN;

	if (strcmp(style, "BOLD") == 0)
		return FONTSTYLE_STYLE_BOLD;

	if (strcmp(style, "ITALIC") == 0)
		return FONTSTYLE_STYLE_ITALIC;

	if (strcmp(style, "BOLD ITALIC") == 0)
		return FONTSTYLE_STYLE_BOLDITALIC;

	return FONTSTYLE_STYLE_PLAIN;
}

