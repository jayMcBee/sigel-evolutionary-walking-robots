/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	GroupNode.h
*
******************************************************************/

#ifndef _GROUP_H_
#define _GROUP_H_

#include "GroupingNode.h"

class GroupNode : public GroupingNode {

public:

	GroupNode();
	~GroupNode();

	////////////////////////////////////////////////
	//	Output
	////////////////////////////////////////////////

	void outputContext(ostream &printStream, String indentString);

	////////////////////////////////////////////////
	//	functions
	////////////////////////////////////////////////
	
	bool isChildNodeType(Node *node);
	void initialize();
	void uninitialize();
	void update();

	////////////////////////////////////////////////
	//	List
	////////////////////////////////////////////////

	GroupNode *next();
	GroupNode *nextTraversal();

};

#endif

