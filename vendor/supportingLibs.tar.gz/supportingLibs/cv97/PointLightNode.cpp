/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	PointLightNode.h
*
******************************************************************/

#include "PointLightNode.h"

PointLightNode::PointLightNode() 
{
	setHeaderFlag(false);
	setType(pointLightNodeString);

	// ambient intensity exposed field
	SFFloat *ambientIntensity = new SFFloat(0.0f);
	ambientIntensity->setName(ambientIntensityFieldString);
	addExposedField(ambientIntensity);

	// location exposed field
	SFVec3f *location = new SFVec3f(0.0f, 0.0f, 0.0f);
	location->setName(locationFieldString);
	addExposedField(location);

	// radius exposed field
	SFFloat *radius = new SFFloat(100.0f);
	radius->setName(radiusFieldString);
	addExposedField(radius);

	// attenuation exposed field
	SFVec3f *attenuation = new SFVec3f(1.0f, 0.0f, 0.0f);
	attenuation->setName(attenuationFieldString);
	addExposedField(attenuation);
}

PointLightNode::~PointLightNode() 
{
}

////////////////////////////////////////////////
//	AmbientIntensity
////////////////////////////////////////////////
	
void PointLightNode::setAmbientIntensity(float value) 
{
	SFFloat *intensity = (SFFloat *)getExposedField(ambientIntensityFieldString);
	intensity->setValue(value);
}

float PointLightNode::getAmbientIntensity() 
{
	SFFloat *intensity = (SFFloat *)getExposedField(ambientIntensityFieldString);
	return intensity->getValue();
}

////////////////////////////////////////////////
//	Location
////////////////////////////////////////////////

void PointLightNode::setLocation(float value[]) 
{
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	location->setValue(value);
}

void PointLightNode::setLocation(float x, float y, float z) 
{
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	location->setValue(x, y, z);
}

void PointLightNode::getLocation(float value[]) 
{
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	location->getValue(value);
}

////////////////////////////////////////////////
//	Radius
////////////////////////////////////////////////
	
void PointLightNode::setRadius(float value) 
{
	SFFloat *radius = (SFFloat *)getExposedField(radiusFieldString);
	radius->setValue(value);
}

float PointLightNode::getRadius() 
{
	SFFloat *radius = (SFFloat *)getExposedField(radiusFieldString);
	return radius->getValue();
}

////////////////////////////////////////////////
//	Attenuation
////////////////////////////////////////////////

void PointLightNode::setAttenuation(float value[]) 
{
	SFVec3f *attenuation = (SFVec3f *)getExposedField(attenuationFieldString);
	attenuation->setValue(value);
}

void PointLightNode::setAttenuation(float x, float y, float z) 
{
	SFVec3f *attenuation = (SFVec3f *)getExposedField(attenuationFieldString);
	attenuation->setValue(x, y, z);
}

void PointLightNode::getAttenuation(float value[]) 
{
	SFVec3f *attenuation = (SFVec3f *)getExposedField(attenuationFieldString);
	attenuation->getValue(value);
}

////////////////////////////////////////////////
//	Diffuse Color
////////////////////////////////////////////////

void PointLightNode::getDiffuseColor(float value[]) 
{
	getColor(value);
	float	intensity = getIntensity();
	value[0] *= intensity;
	value[1] *= intensity;
	value[2] *= intensity;
}

////////////////////////////////////////////////
//	Ambient Color
////////////////////////////////////////////////

void PointLightNode::getAmbientColor(float value[]) 
{
	getColor(value);
	float	intensity = getIntensity();
	float	ambientIntensity = getAmbientIntensity();
	value[0] *= intensity * ambientIntensity;
	value[1] *= intensity * ambientIntensity;
	value[2] *= intensity * ambientIntensity;
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

PointLightNode *PointLightNode::next() 
{
	return (PointLightNode *)Node::next(getType());
}

PointLightNode *PointLightNode::nextTraversal() 
{
	return (PointLightNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool PointLightNode::isChildNodeType(Node *node)
{
	return false;
}

void PointLightNode::initialize() 
{
}

void PointLightNode::uninitialize() 
{
}

void PointLightNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void PointLightNode::outputContext(ostream &printStream, String indentString) 
{
	SFColor *color = (SFColor *)getExposedField(colorFieldString);
	SFVec3f *attenuation = (SFVec3f *)getExposedField(attenuationFieldString);
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	SFBool *bon = (SFBool *)getExposedField(onFieldString);

	printStream << indentString << "\t" << "on " << bon  << endl;
	printStream << indentString << "\t" << "intensity " << getIntensity()  << endl;
	printStream << indentString << "\t" << "ambientIntensity " << getAmbientIntensity()  << endl;
	printStream << indentString << "\t" << "color " << color  << endl;
	printStream << indentString << "\t" << "location " << location  << endl;
	printStream << indentString << "\t" << "radius " << getRadius()  << endl;
	printStream << indentString << "\t" << "attenuation " << attenuation  << endl;
}
