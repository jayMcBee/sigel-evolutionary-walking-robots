/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	TouchSensorNode.cpp
*
******************************************************************/

#include "TouchSensorNode.h"

TouchSensorNode::TouchSensorNode() 
{
	setHeaderFlag(false);
	setType(touchSensorNodeString);

	// enabled exposed field
	SFBool *enabled = new SFBool(true);
	addExposedField(enabledFieldString, enabled);

	// isActive eventOut field
	SFBool *isActive = new SFBool(false);
	addEventOut(isActiveFieldString, isActive);

	// hitNormal eventOut field
	SFVec3f *hitNormal = new SFVec3f(0.0f, 0.0f, 0.0f);
	addEventOut(hitNormalFieldString, hitNormal);

	// hitTexCoord eventOut field
	SFVec2f *hitTexCoord = new SFVec2f(0.0f, 0.0f);
	addEventOut(hitTexCoordFieldString, hitTexCoord);

	// hitPoint eventOut field
	SFVec3f *hitPoint = new SFVec3f(0.0f, 0.0f, 0.0f);
	addEventOut(hitPointFieldString, hitPoint);

	// isOver eventOut field
	SFBool *isOver = new SFBool(false);
	addEventOut(isOverFieldString, isOver);

	// exitTime eventOut field
	SFTime *time = new SFTime(0.0f);
	addEventOut(touchTimeFieldString, time);
}

TouchSensorNode::~TouchSensorNode() 
{
}

////////////////////////////////////////////////
//	Enabled
////////////////////////////////////////////////
	
void TouchSensorNode::setEnabled(bool value) 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	bEnabled->setValue(value);
}

void TouchSensorNode::setEnabled(int value) 
{
	setEnabled(value ? true : false);
}

bool TouchSensorNode::getEnabled() 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	return bEnabled->getValue();
}

bool TouchSensorNode::isEnabled() 
{
	return getEnabled();
}

SFBool *TouchSensorNode::getEnabledField() 
{
	return (SFBool *)getExposedField(enabledFieldString);
}

////////////////////////////////////////////////
//	isActive
////////////////////////////////////////////////
	
void TouchSensorNode::setIsActive(bool value) 
{
	SFBool *sfbool = (SFBool *)getEventOut(isActiveFieldString);
	sfbool->setValue(value);
}

bool TouchSensorNode::getIsActive() 
{
	SFBool *sfbool = (SFBool *)getEventOut(isActiveFieldString);
	return sfbool->getValue();
}

bool TouchSensorNode::isActive() 
{
	return getIsActive();
}

SFBool *TouchSensorNode::getIsActiveField() 
{
	return (SFBool *)getEventOut(isActiveFieldString);
}

////////////////////////////////////////////////
//	isOver
////////////////////////////////////////////////
	
void TouchSensorNode::setIsOver(bool  value) 
{
	SFBool *sfbool = (SFBool *)getEventOut(isOverFieldString);
	sfbool->setValue(value);
}

void TouchSensorNode::setIsOver(int value) 
{
	setIsOver(value ? true : false);
}

bool  TouchSensorNode::getIsOver() 
{
	SFBool *sfbool = (SFBool *)getEventOut(isOverFieldString);
	return sfbool->getValue();
}

bool  TouchSensorNode::isOver() 
{
	return getIsOver();
}

SFBool *TouchSensorNode::getIsOverField() 
{
	return (SFBool *)getEventOut(isOverFieldString);
}

////////////////////////////////////////////////
//	hitNormal
////////////////////////////////////////////////
	
void TouchSensorNode::setHitNormalChanged(float value[]) 
{
	SFVec3f *normal = (SFVec3f *)getEventOut(hitNormalFieldString);
	normal->setValue(value);
}

void TouchSensorNode::setHitNormalChanged(float x, float y, float z) 
{
	SFVec3f *normal = (SFVec3f *)getEventOut(hitNormalFieldString);
	normal->setValue(x, y, z);
}

void TouchSensorNode::getHitNormalChanged(float value[]) 
{
	SFVec3f *normal = (SFVec3f *)getEventOut(hitNormalFieldString);
	normal->getValue(value);
}

SFVec3f *TouchSensorNode::getHitNormalChanged() 
{
	return (SFVec3f *)getEventOut(hitNormalFieldString);
}

////////////////////////////////////////////////
//	hitPoint
////////////////////////////////////////////////
	
void TouchSensorNode::setHitPointChanged(float value[]) 
{
	SFVec3f *point = (SFVec3f *)getEventOut(hitPointFieldString);
	point->setValue(value);
}

void TouchSensorNode::setHitPointChanged(float x, float y, float z) 
{
	SFVec3f *point = (SFVec3f *)getEventOut(hitPointFieldString);
	point->setValue(x, y, z);
}

void TouchSensorNode::getHitPointChanged(float value[]) 
{
	SFVec3f *point = (SFVec3f *)getEventOut(hitPointFieldString);
	point->getValue(value);
}

SFVec3f *TouchSensorNode::getHitPointChanged() 
{
	return (SFVec3f *)getEventOut(hitPointFieldString);
}

////////////////////////////////////////////////
//	hitTexCoord
////////////////////////////////////////////////
	
void TouchSensorNode::setHitTexCoord(float value[]) 
{
	SFVec2f *point = (SFVec2f *)getEventOut(hitTexCoordFieldString);
	point->setValue(value);
}

void TouchSensorNode::setHitTexCoord(float x, float y) 
{
	SFVec2f *point = (SFVec2f *)getEventOut(hitTexCoordFieldString);
	point->setValue(x, y);
}

void TouchSensorNode::getHitTexCoord(float value[]) 
{
	SFVec2f *point = (SFVec2f *)getEventOut(hitTexCoordFieldString);
	point->getValue(value);
}

SFVec2f *TouchSensorNode::getHitTexCoord() 
{
	return (SFVec2f *)getEventOut(hitTexCoordFieldString);
}

////////////////////////////////////////////////
//	ExitTime
////////////////////////////////////////////////
	
void TouchSensorNode::setTouchTime(double value) 
{
	SFTime *time = (SFTime *)getEventOut(touchTimeFieldString);
	time->setValue(value);
}

double TouchSensorNode::getTouchTime() 
{
	SFTime *time = (SFTime *)getEventOut(touchTimeFieldString);
	return time->getValue();
}

SFTime *TouchSensorNode::getTouchTimeField() 
{
	return (SFTime *)getEventOut(touchTimeFieldString);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

TouchSensorNode *TouchSensorNode::next() 
{
	return (TouchSensorNode *)Node::next(getType());
}

TouchSensorNode *TouchSensorNode::nextTraversal() 
{
	return (TouchSensorNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool TouchSensorNode::isChildNodeType(Node *node)
{
	return false;
}

void TouchSensorNode::initialize() 
{
}

void TouchSensorNode::uninitialize() 
{
}

void TouchSensorNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void TouchSensorNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *enabled = (SFBool *)getExposedField(enabledFieldString);
	printStream << indentString << "\t" << "enabled " << enabled << endl;
}

