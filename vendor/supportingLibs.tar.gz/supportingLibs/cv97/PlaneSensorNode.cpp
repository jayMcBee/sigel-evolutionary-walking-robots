/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	PlaneSensorNode.cpp
*
******************************************************************/

#include "PlaneSensorNode.h"

PlaneSensorNode::PlaneSensorNode() 
{
	setHeaderFlag(false);
	setType(planeSensorNodeString);

	// enabled exposed field
	SFBool *enabled = new SFBool(true);
	addExposedField(enabledFieldString, enabled);

	// autoOffset exposed field
	SFBool *autoOffset = new SFBool(true);
	addExposedField(autoOffsetFieldString, autoOffset);

	// minPosition exposed field
	SFVec2f *minPosition = new SFVec2f(0.0f, 0.0f);
	addExposedField(minPositionFieldString, minPosition);

	// maxAngle exposed field
	SFVec2f *maxPosition = new SFVec2f(-1.0f, -1.0f);
	addExposedField(maxPositionFieldString, maxPosition);

	// offset exposed field
	SFVec3f *offset = new SFVec3f(0.0f, 0.0f, 0.0f);
	addExposedField(offsetFieldString, offset);
	
	// isActive eventOut field
	SFBool *isActive = new SFBool(false);
	addEventOut(isActiveFieldString, isActive);

	// translation eventOut field
	SFVec3f *translation = new SFVec3f(0.0f, 0.0f, 0.0f);
	addEventOut(translationFieldString, translation);

	// trackPoint eventOut field
	SFVec3f *trackPoint = new SFVec3f(0.0f, 0.0f, 0.0f);
	addEventOut(trackPointFieldString, trackPoint);
}

PlaneSensorNode::~PlaneSensorNode() 
{
}

////////////////////////////////////////////////
//	Enabled
////////////////////////////////////////////////
	
void PlaneSensorNode::setEnabled(bool  value) 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	bEnabled->setValue(value);
}

void PlaneSensorNode::setEnabled(int value) 
{
	setEnabled(value ? true : false);
}

bool PlaneSensorNode::getEnabled() 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	return bEnabled->getValue();
}

bool PlaneSensorNode::isEnabled() 
{
	return getEnabled();
}

SFBool *PlaneSensorNode::getEnabledField() 
{
	return (SFBool *)getExposedField(enabledFieldString);
}

////////////////////////////////////////////////
//	AutoOffset
////////////////////////////////////////////////
	
void PlaneSensorNode::setAutoOffset(bool value) 
{
	SFBool *sfbool = (SFBool *)getExposedField(autoOffsetFieldString);
	sfbool->setValue(value);
}

void PlaneSensorNode::setAutoOffset(int value) 
{
	setAutoOffset(value ? true : false);
}

bool PlaneSensorNode::getAutoOffset() 
{
	SFBool *sfbool = (SFBool *)getExposedField(autoOffsetFieldString);
	return sfbool->getValue();
}

bool PlaneSensorNode::isAutoOffset() 
{
	return getAutoOffset();
}

SFBool *PlaneSensorNode::getAutoOffsetField() 
{
	return (SFBool *)getExposedField(autoOffsetFieldString);
}

////////////////////////////////////////////////
//	MinPosition
////////////////////////////////////////////////
	
void PlaneSensorNode::setMinPosition(float value[]) 
{
	SFVec2f *sfvec2f = (SFVec2f *)getExposedField(minPositionFieldString);
	sfvec2f->setValue(value);
}

void PlaneSensorNode::setMinPosition(float x, float y) 
{
	SFVec2f *sfvec2f = (SFVec2f *)getExposedField(minPositionFieldString);
	sfvec2f->setValue(x, y);
}

void PlaneSensorNode::getMinPosition(float value[]) 
{
	SFVec2f *sfvec2f = (SFVec2f *)getExposedField(minPositionFieldString);
	sfvec2f->getValue(value);
}

void PlaneSensorNode::getMinPosition(float *x, float *y) 
{
	SFVec2f *sfvec2f = (SFVec2f *)getExposedField(minPositionFieldString);
	*x = sfvec2f->getX();
	*y = sfvec2f->getY();
}

SFVec2f *PlaneSensorNode::getMinPositionField() 
{
	return (SFVec2f *)getExposedField(minPositionFieldString);
}

////////////////////////////////////////////////
//	MaxPosition
////////////////////////////////////////////////
	
void PlaneSensorNode::setMaxPosition(float value[]) 
{
	SFVec2f *sfvec2f = (SFVec2f *)getExposedField(maxPositionFieldString);
	sfvec2f->setValue(value);
}

void PlaneSensorNode::setMaxPosition(float x, float y) 
{
	SFVec2f *sfvec2f = (SFVec2f *)getExposedField(maxPositionFieldString);
	sfvec2f->setValue(x, y);
}

void PlaneSensorNode::getMaxPosition(float value[]) 
{
	SFVec2f *sfvec2f = (SFVec2f *)getExposedField(maxPositionFieldString);
	sfvec2f->getValue(value);
}

void PlaneSensorNode::getMaxPosition(float *x, float *y) 
{
	SFVec2f *sfvec2f = (SFVec2f *)getExposedField(maxPositionFieldString);
	*x = sfvec2f->getX();
	*y = sfvec2f->getY();
}

SFVec2f *PlaneSensorNode::getMaxPositionField() 
{
	return (SFVec2f *)getExposedField(maxPositionFieldString);
}

////////////////////////////////////////////////
//	Offset
////////////////////////////////////////////////
	
void PlaneSensorNode::setOffset(float value[]) 
{
	SFVec3f *vector = (SFVec3f *)getExposedField(offsetFieldString);
	vector->setValue(value);
}

void PlaneSensorNode::getOffset(float value[]) 
{
	SFVec3f *vector = (SFVec3f *)getExposedField(offsetFieldString);
	vector->getValue(value);
}

SFVec3f *PlaneSensorNode::getOffsetField() 
{
	return (SFVec3f *)getExposedField(offsetFieldString);
}

////////////////////////////////////////////////
//	isActive
////////////////////////////////////////////////
	
void PlaneSensorNode::setIsActive(bool value) 
{
	SFBool *sfbool = (SFBool *)getEventOut(isActiveFieldString);
	sfbool->setValue(value);
}

bool PlaneSensorNode::getIsActive() 
{
	SFBool *sfbool = (SFBool *)getEventOut(isActiveFieldString);
	return sfbool->getValue();
}

bool PlaneSensorNode::isActive() 
{
	return getAutoOffset();
}

SFBool *PlaneSensorNode::getIsActiveField() 
{
	return (SFBool *)getEventOut(isActiveFieldString);
}

////////////////////////////////////////////////
//	Translation
////////////////////////////////////////////////
	
void PlaneSensorNode::setTranslationChanged(float value[]) 
{
	SFVec3f *translation = (SFVec3f *)getEventOut(translationFieldString);
	translation->setValue(value);
}

void PlaneSensorNode::setTranslationChanged(float x, float y, float z) 
{
	SFVec3f *translation = (SFVec3f *)getEventOut(translationFieldString);
	translation->setValue(x, y, z);
}

void PlaneSensorNode::getTranslationChanged(float value[]) 
{
	SFVec3f *translation = (SFVec3f *)getEventOut(translationFieldString);
	translation->getValue(value);
}

SFVec3f *PlaneSensorNode::getTranslationChangedField() 
{
	return (SFVec3f *)getEventOut(translationFieldString);
}

////////////////////////////////////////////////
//	TrackPoint
////////////////////////////////////////////////
	
void PlaneSensorNode::setTrackPointChanged(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getEventOut(trackPointFieldString);
	sfvec3f->setValue(value);
}

void PlaneSensorNode::setTrackPointChanged(float x, float y, float z) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getEventOut(trackPointFieldString);
	sfvec3f->setValue(x, y, z);
}

void PlaneSensorNode::getTrackPointChanged(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getEventOut(trackPointFieldString);
	sfvec3f->getValue(value);
}

SFVec3f *PlaneSensorNode::getTrackPointChangedField() 
{
	return (SFVec3f *)getEventOut(trackPointFieldString);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

PlaneSensorNode *PlaneSensorNode::next() 
{
	return (PlaneSensorNode *)Node::next(getType());
}

PlaneSensorNode *PlaneSensorNode::nextTraversal() 
{
	return (PlaneSensorNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool PlaneSensorNode::isChildNodeType(Node *node)
{
	return false;
}

void PlaneSensorNode::initialize() 
{
	setIsActive(false);
}

void PlaneSensorNode::uninitialize() 
{
}

void PlaneSensorNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void PlaneSensorNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *autoOffset = (SFBool *)getExposedField(autoOffsetFieldString);
	SFBool *enabled = (SFBool *)getExposedField(enabledFieldString);
	SFVec2f *maxpos = (SFVec2f *)getExposedField(maxPositionFieldString);
	SFVec2f *minpos = (SFVec2f *)getExposedField(maxPositionFieldString);
	SFVec3f *offset = (SFVec3f *)getExposedField(offsetFieldString);

	printStream << indentString << "\t" << "autoOffset " << autoOffset  << endl;
	printStream << indentString << "\t" << "enabled " << enabled  << endl;
	printStream << indentString << "\t" << "maxPosition " << maxpos  << endl;
	printStream << indentString << "\t" << "minPosition " << minpos  << endl;
	printStream << indentString << "\t" << "offset " << offset << endl;
}	
