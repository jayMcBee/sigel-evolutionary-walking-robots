/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	MovieTextureNode.cpp
*
******************************************************************/

#include "MovieTextureNode.h"

MovieTextureNode::MovieTextureNode() 
{
	setHeaderFlag(false);
	setType(movieTextureNodeString);

	///////////////////////////
	// Exposed Field 
	///////////////////////////

	// url field
	MFString *url = new MFString();
	addExposedField(urlFieldString, url);

	// loop exposed field
	SFBool *loop = new SFBool(false);
	addExposedField(loopFieldString, loop);

	// startTime exposed field
	SFTime *startTime = new SFTime(0.0f);
	addExposedField(startTimeFieldString, startTime);

	// stopTime exposed field
	SFTime *stopTime = new SFTime(0.0f);
	addExposedField(stopTimeFieldString, stopTime);

	// speed exposed field
	SFFloat *speed = new SFFloat(1.0f);
	addExposedField(speedTimeFieldString, speed);

	///////////////////////////
	// Field 
	///////////////////////////

	// repeatS field
	SFBool *repeatS = new SFBool(true);
	addField(repeatSFieldString, repeatS);

	// repeatT field
	SFBool *repeatT = new SFBool(true);
	addField(repeatTFieldString, repeatT);

	///////////////////////////
	// EventOut
	///////////////////////////

	// isActive eventOut field
	SFBool *isActive = new SFBool(false);
	addEventOut(isActiveFieldString, isActive);

	// time eventOut field
	SFTime *durationChanged = new SFTime(-1.0f);
	addEventOut(durationFieldString, durationChanged);
}

MovieTextureNode::~MovieTextureNode() 
{
}

////////////////////////////////////////////////
//	RepeatS
////////////////////////////////////////////////
	
void MovieTextureNode::setRepeatS(bool value) 
{
	SFBool *repeatS = (SFBool *)getField(repeatSFieldString);
	repeatS->setValue(value);
}

void MovieTextureNode::setRepeatS(int value) 
{
	setRepeatS(value ? true : false);
}

bool MovieTextureNode::getRepeatS() 
{
	SFBool *repeatS = (SFBool *)getField(repeatSFieldString);
	return repeatS->getValue();
}

////////////////////////////////////////////////
//	RepeatT
////////////////////////////////////////////////
	
void MovieTextureNode::setRepeatT(bool value) 
{
	SFBool *repeatT = (SFBool *)getField(repeatTFieldString);
	repeatT->setValue(value);
}

void MovieTextureNode::setRepeatT(int value) 
{
	setRepeatT(value ? true : false);
}

bool MovieTextureNode::getRepeatT() 
{
	SFBool *repeatT = (SFBool *)getField(repeatTFieldString);
	return repeatT->getValue();
}

////////////////////////////////////////////////
// Url
////////////////////////////////////////////////

void MovieTextureNode::addUrl(String value) 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	url->addValue(value);
}

int MovieTextureNode::getNUrls() 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	return url->getSize();
}

String MovieTextureNode::getUrl(int index) 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	return url->get1Value(index);
}

void MovieTextureNode::setUrl(int index, char *urlString) 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	url->set1Value(index, urlString);
}

////////////////////////////////////////////////
//	Loop
////////////////////////////////////////////////
	
void MovieTextureNode::setLoop(bool value) 
{
	SFBool *loop = (SFBool *)getExposedField(loopFieldString);
	loop->setValue(value);
}

void MovieTextureNode::setLoop(int value) 
{
	setLoop(value ? true : false);
}

bool MovieTextureNode::getLoop() 
{
	SFBool *loop = (SFBool *)getExposedField(loopFieldString);
	return loop->getValue();
}

bool MovieTextureNode::isLoop() 
{
	return getLoop();
}

////////////////////////////////////////////////
//	Speed
////////////////////////////////////////////////
	
void MovieTextureNode::setSpeed(float value) 
{
	SFFloat *time = (SFFloat *)getExposedField(speedTimeFieldString);
	time->setValue(value);
}

float MovieTextureNode::getSpeed() 
{
	SFFloat *time = (SFFloat *)getExposedField(speedTimeFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	Start time
////////////////////////////////////////////////
	
void MovieTextureNode::setStartTime(double value) 
{
	SFTime *time = (SFTime *)getExposedField(startTimeFieldString);
	time->setValue(value);
}

double MovieTextureNode::getStartTime() 
{
	SFTime *time = (SFTime *)getExposedField(startTimeFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	Stop time
////////////////////////////////////////////////
	
void MovieTextureNode::setStopTime(double value) 
{
	SFTime *time = (SFTime *)getExposedField(stopTimeFieldString);
	time->setValue(value);
}

double MovieTextureNode::getStopTime() 
{
	SFTime *time = (SFTime *)getExposedField(stopTimeFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	isActive
////////////////////////////////////////////////
	
void MovieTextureNode::setIsActive(bool value) 
{
	SFBool *field = (SFBool *)getEventOut(isActiveFieldString);
	field->setValue(value);
}

bool MovieTextureNode::getIsActive() 
{
	SFBool *field = (SFBool *)getEventOut(isActiveFieldString);
	return field->getValue();
}

bool MovieTextureNode::isActive() 
{
	SFBool *field = (SFBool *)getEventOut(isActiveFieldString);
	return field->getValue();
}

////////////////////////////////////////////////
//	duration_changed
////////////////////////////////////////////////
	
void MovieTextureNode::setDurationChanged(double value) 
{
	SFTime *time = (SFTime *)getEventOut(durationFieldString);
	time->setValue(value);
}

double MovieTextureNode::getDurationChanged() 
{
	SFTime *time = (SFTime *)getEventOut(durationFieldString);
	return time->getValue();
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

MovieTextureNode *MovieTextureNode::next() 
{
	return (MovieTextureNode *)Node::next(getType());
}

MovieTextureNode *MovieTextureNode::nextTraversal() 
{
	return (MovieTextureNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool MovieTextureNode::isChildNodeType(Node *node)
{
	return false;
}

void MovieTextureNode::initialize() 
{
}

void MovieTextureNode::uninitialize() 
{
}

void MovieTextureNode::update() 
{
}

////////////////////////////////////////////////
//	infomation
////////////////////////////////////////////////

void MovieTextureNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *loop = (SFBool *)getExposedField(loopFieldString);
	SFBool *repeatS = (SFBool *)getField(repeatSFieldString);
	SFBool *repeatT = (SFBool *)getField(repeatTFieldString);

	printStream << indentString << "\t" << "loop " << loop << endl;
	printStream << indentString << "\t" << "speed " << getSpeed() << endl;
	printStream << indentString << "\t" << "startTime " << getStartTime() << endl;
	printStream << indentString << "\t" << "stopTime " << getStopTime() << endl;
	printStream << indentString << "\t" << "repeatS " << repeatS << endl;
	printStream << indentString << "\t" << "repeatT " << repeatT << endl;

	if (0 < getNUrls()) {
		MFString *url = (MFString *)getExposedField(urlFieldString);
		printStream << indentString << "\t" << "url [" << endl;
		url->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}
