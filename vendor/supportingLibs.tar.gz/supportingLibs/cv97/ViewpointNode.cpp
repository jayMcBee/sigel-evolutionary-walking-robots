/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	ViewpointNode.h
*
******************************************************************/

#include "ViewpointNode.h"

ViewpointNode::ViewpointNode() 
{
	setHeaderFlag(false);
	setType(viewpointNodeString);

	// position exposed field
	SFVec3f *position = new SFVec3f(0.0f, 0.0f, 0.0f);
	position->setName(positionFieldString);
	addExposedField(position);

	// orientation exposed field
	SFRotation *orientation = new SFRotation(0.0f, 0.0f, 1.0f, 0.0f);
	orientation->setName(orientationFieldString);
	addExposedField(orientation);

	// description exposed field
	SFString *description = new SFString("");
	description->setName(descriptionFieldString);
	addField(description);

	// fov exposed field
	SFFloat *fov = new SFFloat(0.785398f);
	fov->setName(fieldOfViewFieldString);
	addExposedField(fov);

	// jump exposed field
	SFBool *jump = new SFBool(true);
	jump->setName(jumpFieldString);
	addExposedField(jump);
}

ViewpointNode::~ViewpointNode() 
{
}

////////////////////////////////////////////////
//	Jump
////////////////////////////////////////////////
	
void ViewpointNode::setJump(bool value) 
{
	SFBool *jump = (SFBool *)getExposedField(jumpFieldString);
	jump->setValue(value);
}

void ViewpointNode::setJump(int value) 
{
	setJump(value ? true : false);
}

bool ViewpointNode::getJump() 
{
	SFBool *jump = (SFBool *)getExposedField(jumpFieldString);
	return jump->getValue();
}

////////////////////////////////////////////////
//	FieldOfView
////////////////////////////////////////////////
	
void ViewpointNode::setFieldOfView(float value) 
{
	SFFloat *fov = (SFFloat *)getExposedField(fieldOfViewFieldString);
	fov->setValue(value);
}

float ViewpointNode::getFieldOfView() 
{
	SFFloat *fov = (SFFloat *)getExposedField(fieldOfViewFieldString);
	return fov->getValue();
}

////////////////////////////////////////////////
//	Description
////////////////////////////////////////////////
	
void ViewpointNode::setDescription(String value) 
{
	SFString *description = (SFString *)getField(descriptionFieldString);
	description->setValue(value);
}

String ViewpointNode::getDescription() 
{
	SFString *description = (SFString *)getField(descriptionFieldString);
	return description->getValue();
}
////////////////////////////////////////////////
//	Position
////////////////////////////////////////////////

void ViewpointNode::setPosition(float value[]) 
{
	SFVec3f *position = (SFVec3f *)getExposedField(positionFieldString);
	position->setValue(value);
}

void ViewpointNode::setPosition(float x, float y, float z) 
{
	SFVec3f *position = (SFVec3f *)getExposedField(positionFieldString);
	position->setValue(x, y, z);
}

void ViewpointNode::getPosition(float value[]) 
{
	SFVec3f *position = (SFVec3f *)getExposedField(positionFieldString);
	position->getValue(value);
}

SFVec3f *ViewpointNode::getPosition() 
{
	SFVec3f *position = (SFVec3f *)getExposedField(positionFieldString);
	return position;
}

////////////////////////////////////////////////
//	Orientation
////////////////////////////////////////////////

void ViewpointNode::setOrientation(float value[]) 
{
	SFRotation *orientation = (SFRotation *)getExposedField(orientationFieldString);
	orientation->setValue(value);
}

void ViewpointNode::setOrientation(float x, float y, float z, float w) 
{
	SFRotation *orientation = (SFRotation *)getExposedField(orientationFieldString);
	orientation->setValue(x, y, z, w);
}

void ViewpointNode::getOrientation(float value[]) 
{
	SFRotation *orientation = (SFRotation *)getExposedField(orientationFieldString);
	orientation->getValue(value);
}

SFRotation *ViewpointNode::getOrientation() 
{
	SFRotation *orientation = (SFRotation *)getExposedField(orientationFieldString);
	return orientation;
}

////////////////////////////////////////////////
//	Add position
////////////////////////////////////////////////

void ViewpointNode::addPosition(float worldTranslation[3]) 
{ 
	SFVec3f *position = (SFVec3f *)getExposedField(positionFieldString);
	position->add(worldTranslation);
}

void ViewpointNode::addPosition(float worldx, float worldy, float worldz) 
{ 
	SFVec3f *position = (SFVec3f *)getExposedField(positionFieldString);
	position->add(worldx, worldy, worldz);
}

void ViewpointNode::addPosition(float localTranslation[3], float frame[3][3]) 
{ 
	SFVec3f *position = (SFVec3f *)getExposedField(positionFieldString);
	float	translation[3];
	for (int axis=0; axis<3; axis++) {
		SFVec3f vector(frame[axis]);
		vector.scale(localTranslation[axis]);
		vector.getValue(translation);
		position->add(translation);
	}
}

void ViewpointNode::addPosition(float x, float y, float z, float frame[3][3]) 
{ 
	float localTranslation[3];
	localTranslation[0] = x;
	localTranslation[1] = y;
	localTranslation[2] = z;
	addPosition(localTranslation, frame);
}

////////////////////////////////////////////////
//	Add orientation
////////////////////////////////////////////////

void ViewpointNode::addOrientation(SFRotation *rot) 
{
	SFRotation *orientation = (SFRotation *)getExposedField(orientationFieldString);
	orientation->add(rot);
}

void ViewpointNode::addOrientation(float rotationValue[4]) 
{
	SFRotation *orientation = (SFRotation *)getExposedField(orientationFieldString);
	orientation->add(rotationValue);
}

void ViewpointNode::addOrientation(float x, float y, float z, float rot) 
{
	SFRotation *orientation = (SFRotation *)getExposedField(orientationFieldString);
	orientation->add(x, y, z, rot);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

ViewpointNode *ViewpointNode::next() 
{
	return (ViewpointNode *)Node::next(getType());
}

ViewpointNode *ViewpointNode::nextTraversal() 
{
	return (ViewpointNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool ViewpointNode::isChildNodeType(Node *node)
{
	return false;
}

void ViewpointNode::initialize() 
{
}

void ViewpointNode::uninitialize() 
{
}

void ViewpointNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void ViewpointNode::outputContext(ostream& printStream, String indentString) 
{
	SFVec3f *position = (SFVec3f *)getExposedField(positionFieldString);
	SFRotation *orientation = (SFRotation *)getExposedField(orientationFieldString);
	SFBool *jump = (SFBool *)getExposedField(jumpFieldString);
	SFString *description = (SFString *)getField(descriptionFieldString);
	printStream << indentString << "\t" << "fieldOfView " << getFieldOfView() << endl;
	printStream << indentString << "\t" << "jump " << jump << endl;
	printStream << indentString << "\t" << "position " << position << endl;
	printStream << indentString << "\t" << "orientation " << orientation << endl;
	printStream << indentString << "\t" << "description " << description << endl;
}

////////////////////////////////////////////////
//	Local frame
////////////////////////////////////////////////

void ViewpointNode::getFrame(float frame[3][3]) 
{
	SFRotation *orientation = getOrientation();
	// local x frame
	frame[0][0] = 1.0f;
	frame[0][1] = 0.0f;
	frame[0][2] = 0.0f;
	orientation->multi(frame[0]);
	// local 0 frame
	frame[1][0] = 0.0f;
	frame[1][1] = 1.0f;
	frame[1][2] = 0.0f;
	orientation->multi(frame[1]);
	// local 0 frame
	frame[2][0] = 0.0f;
	frame[2][1] = 0.0f;
	frame[2][2] = 1.0f;
	orientation->multi(frame[2]);
}

void ViewpointNode::translate(float vector[3]) 
{
	float frame[3][3];
	getFrame(frame);
	addPosition(vector, frame);
}

void ViewpointNode::translate(SFVec3f vec) 
{
	float frame[3][3];
	float vector[3];
	getFrame(frame);
	vec.getValue(vector);
	addPosition(vector, frame);
}

void ViewpointNode::rotate(float rotation[4]) 
{
	addOrientation(rotation);
}

void ViewpointNode::rotate(SFRotation rot) 
{
	float rotation[4];
	rot.getValue(rotation);
	addOrientation(rotation);
}

////////////////////////////////////////////////
//	ViewpointNode Matrix
////////////////////////////////////////////////

void ViewpointNode::getMatrix(SFMatrix *matrix) 
{
	float	position[3];
	float	rotation[4];
	
	getPosition(position);
	SFVec3f	transView(position);
	transView.invert();

	getOrientation(rotation);
	SFRotation rotView(rotation);
	rotView.invert();

	SFMatrix	mxTrans, mxRot;
	mxTrans.setTranslation(&transView);
	mxRot.setRotation(&rotView);

	matrix->init();
	matrix->add(&mxRot);
	matrix->add(&mxTrans);
}

void ViewpointNode::getMatrix(float value[4][4]) 
{
	SFMatrix	mx;
	getMatrix(&mx);
	mx.getValue(value);
}

void ViewpointNode::getTranslationMatrix(SFMatrix *matrix) 
{
	float	position[3];
	
	getPosition(position);
	SFVec3f	transView(position);
	transView.invert();

	SFMatrix	mxTrans;
	mxTrans.setTranslation(&transView);

	matrix->init();
	matrix->add(&mxTrans);
}

void ViewpointNode::getTranslationMatrix(float value[4][4]) 
{
	SFMatrix	mx;
	getTranslationMatrix(&mx);
	mx.getValue(value);
}
