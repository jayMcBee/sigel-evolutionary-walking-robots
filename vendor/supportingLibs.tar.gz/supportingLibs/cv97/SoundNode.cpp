/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	SoundNode.cpp
*
******************************************************************/

#include "SoundNode.h"
#include "AudioClipNode.h"
#include "MovieTextureNode.h"

SoundNode::SoundNode() 
{
	setHeaderFlag(false);
	setType(soundNodeString);

	///////////////////////////
	// Exposed Field 
	///////////////////////////

	// minFront exposed field
	SFFloat *minFront = new SFFloat(1.0f);
	addExposedField(minFrontFieldString, minFront);

	// maxFront exposed field
	SFFloat *maxFront = new SFFloat(10.0f);
	addExposedField(maxFrontFieldString, maxFront);

	// minBack exposed field
	SFFloat *minBack = new SFFloat(1.0f);
	addExposedField(minBackFieldString, minBack);

	// maxBack exposed field
	SFFloat *maxBack = new SFFloat(10.0f);
	addExposedField(maxBackFieldString, maxBack);

	// intensity exposed field
	SFFloat *intensity = new SFFloat(10.0f);
	addExposedField(intensityFieldString, intensity);

	// priority exposed field
	SFFloat *priority = new SFFloat(0.0f);
	addExposedField(priorityFieldString, priority);

	// direction exposed field
	SFVec3f *direction = new SFVec3f(0.0f, 0.0f, 1.0f);
	addExposedField(directionFieldString, direction);

	// location exposed field
	SFVec3f *location = new SFVec3f(0.0f, 0.0f, 0.0f);
	addExposedField(locationFieldString, location);

	///////////////////////////
	// Field 
	///////////////////////////

	// spatialize exposed field
	SFBool *spatialize = new SFBool(true);
	addField(spatializeFieldString, spatialize);
}

SoundNode::~SoundNode() 
{
}

////////////////////////////////////////////////
//	Direction
////////////////////////////////////////////////

void SoundNode::setDirection(float value[]) 
{
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	direction->setValue(value);
}

void SoundNode::setDirection(float x, float y, float z) 
{
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	direction->setValue(x, y, z);
}

void SoundNode::getDirection(float value[]) 
{
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	direction->getValue(value);
}

////////////////////////////////////////////////
//	Location
////////////////////////////////////////////////

void SoundNode::setLocation(float value[]) 
{
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	location->setValue(value);
}

void SoundNode::setLocation(float x, float y, float z) 
{
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	location->setValue(x, y, z);
}

void SoundNode::getLocation(float value[]) 
{
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	location->getValue(value);
}

////////////////////////////////////////////////
//	MinFront
////////////////////////////////////////////////
	
void SoundNode::setMinFront(float value) 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(minFrontFieldString);
	sffloat->setValue(value);
}

float SoundNode::getMinFront() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(minFrontFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	MaxFront
////////////////////////////////////////////////
	
void SoundNode::setMaxFront(float value) 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(maxFrontFieldString);
	sffloat->setValue(value);
}

float SoundNode::getMaxFront() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(maxFrontFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	MinBack
////////////////////////////////////////////////
	
void SoundNode::setMinBack(float value) 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(minBackFieldString);
	sffloat->setValue(value);
}

float SoundNode::getMinBack() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(minBackFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	MaxBack
////////////////////////////////////////////////
	
void SoundNode::setMaxBack(float value) 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(maxBackFieldString);
	sffloat->setValue(value);
}

float SoundNode::getMaxBack() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(maxBackFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	Intensity
////////////////////////////////////////////////
	
void SoundNode::setIntensity(float value) 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(intensityFieldString);
	sffloat->setValue(value);
}

float SoundNode::getIntensity() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(intensityFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	Priority
////////////////////////////////////////////////
	
void SoundNode::setPriority(float value) 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(priorityFieldString);
	sffloat->setValue(value);
}

float SoundNode::getPriority() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(priorityFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

SoundNode *SoundNode::next() 
{
	return (SoundNode *)Node::next(getType());
}

SoundNode *SoundNode::nextTraversal() 
{
	return (SoundNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	Spatialize
////////////////////////////////////////////////
	
void SoundNode::setSpatialize(bool value) 
{
	SFBool *bSpatialize = (SFBool *)getField(spatializeFieldString);
	bSpatialize->setValue(value);
}

void SoundNode::setSpatialize(int value) 
{
	setSpatialize(value ? true : false);
}

bool SoundNode::getSpatialize() 
{
	SFBool *bSpatialize = (SFBool *)getField(spatializeFieldString);
	return bSpatialize->getValue();
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool SoundNode::isChildNodeType(Node *node){
	if (node->isAudioClipNode() || node->isMovieTextureNode())
		return true;
	else
		return false;
}

void SoundNode::initialize() {
}

void SoundNode::uninitialize() {
}

void SoundNode::update() {
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void SoundNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *spatialize = (SFBool *)getField(spatializeFieldString);
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);

	printStream << indentString << "\t" << "direction " << direction << endl;
	printStream << indentString << "\t" << "location " << location << endl;
	printStream << indentString << "\t" << "maxFront " << getMaxFront() << endl;
	printStream << indentString << "\t" << "minFront " << getMinFront() << endl;
	printStream << indentString << "\t" << "maxBack " << getMaxBack() << endl;
	printStream << indentString << "\t" << "minBack " << getMinBack() << endl;
	printStream << indentString << "\t" << "intensity " << getIntensity() << endl;
	printStream << indentString << "\t" << "priority " << getPriority() << endl;
	printStream << indentString << "\t" << "spatialize " << spatialize << endl;

	AudioClipNode *aclip = getAudioClipNodes();
	if (aclip != NULL) {
		if (aclip->isInstanceNode() == false) {
			if (aclip->getName() != NULL && strlen(aclip->getName()))
				printStream << indentString << "\t" << "source " << "DEF " << aclip->getName() << " AudioClip {" << endl;
			else
				printStream << indentString << "\t" << "source AudioClip {" << endl;
			aclip->Node::outputContext(printStream, indentString, "\t");
			printStream << indentString << "\t" << "}" << endl;
		}
		else 
			printStream << indentString << "\t" << "source USE " << aclip->getName() << endl;
	}

	MovieTextureNode *mtexture = getMovieTextureNodes();
	if (mtexture != NULL) {
		if (mtexture->isInstanceNode() == false) {
			if (mtexture->getName() != NULL && strlen(mtexture->getName()))
				printStream << indentString << "\t" << "source " << "DEF " << mtexture->getName() << " MovieTexture {" << endl;
			else
				printStream << indentString << "\t" << "source MovieTexture {" << endl;
			mtexture->Node::outputContext(printStream, indentString, "\t");
			printStream << indentString << "\t" << "}" << endl;
		}
		else 
			printStream << indentString << "\t" << "source USE " << mtexture->getName() << endl;
	}
}
