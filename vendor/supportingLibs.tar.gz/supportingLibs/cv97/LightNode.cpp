/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	LightNode.cpp
*
******************************************************************/

#include "LightNode.h"

LightNode::LightNode() 
{
	setHeaderFlag(false);

	// on exposed field
	SFBool *bon = new SFBool(true);
	bon->setName(onFieldString);
	addExposedField(bon);

	// intensity exposed field
	SFFloat *intensity = new SFFloat(1.0f);
	intensity->setName(intensityFieldString);
	addExposedField(intensity);

	// color exposed field
	SFColor *color = new SFColor(1.0f, 1.0f, 1.0f);
	color->setName(colorFieldString);
	addExposedField(color);
}

LightNode::~LightNode() 
{
}

////////////////////////////////////////////////
//	On
////////////////////////////////////////////////
	
void LightNode::setOn(bool on) 
{
	SFBool *bon = (SFBool *)getExposedField(onFieldString);
	bon->setValue(on);
}

void LightNode::setOn(int value) 
{
	setOn(value ? true : false);
}

bool LightNode::isOn() 
{
	SFBool *bon = (SFBool *)getExposedField(onFieldString);
	return bon->getValue();
}

////////////////////////////////////////////////
//	Intensity
////////////////////////////////////////////////
	
void LightNode::setIntensity(float value) 
{
	SFFloat *intensity = (SFFloat *)getExposedField(intensityFieldString);
	intensity->setValue(value);
}

float LightNode::getIntensity() 
{
	SFFloat *intensity = (SFFloat *)getExposedField(intensityFieldString);
	return intensity->getValue();
}

////////////////////////////////////////////////
//	Color
////////////////////////////////////////////////

void LightNode::setColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(colorFieldString);
	color->setValue(value);
}

void LightNode::setColor(float r, float g, float b) 
{
	SFColor *color = (SFColor *)getExposedField(colorFieldString);
	color->setValue(r, g, b);
}

void LightNode::getColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(colorFieldString);
	color->getValue(value);
}

