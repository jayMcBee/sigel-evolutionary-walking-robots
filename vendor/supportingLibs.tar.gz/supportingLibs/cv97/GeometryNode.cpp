/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	GeometryNode.cpp
*
******************************************************************/

#ifdef SUPPORT_OPENGL
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/gl.h>
#endif

#include "GeometryNode.h"

GeometryNode::GeometryNode() 
{
	// bboxCenter field
	SFVec3f *bboxCenter = new SFVec3f(0.0f, 0.0f, 0.0f);
	bboxCenter->setName(bboxCenterPrivateFieldName);
	addPrivateField(bboxCenter);

	// bboxSize field
	SFVec3f *bboxSize = new SFVec3f(-1.0f, -1.0f, -1.0f);
	bboxSize->setName(bboxSizePrivateFieldName);
	addPrivateField(bboxSize);

	setBoundingBoxCenter(0.0f, 0.0f, 0.0f);
	setBoundingBoxSize(-1.0f, -1.0f, -1.0f);

#ifdef SUPPORT_OPENGL
	// display list field
	SFInt32 *dispList = new SFInt32(0);
	dispList->setName(displayListPrivateFieldString);
	addPrivateField(dispList);

	setDisplayList(0);
#endif
}

GeometryNode::~GeometryNode() 
{
}

////////////////////////////////////////////////
//	BoundingBoxSize
////////////////////////////////////////////////

void GeometryNode::setBoundingBoxSize(float value[]) 
{
	SFVec3f *bboxSize = (SFVec3f *)getPrivateField(bboxSizePrivateFieldName);
	bboxSize->setValue(value);
}

void GeometryNode::setBoundingBoxSize(float x, float y, float z) 
{
	SFVec3f *bboxSize = (SFVec3f *)getPrivateField(bboxSizePrivateFieldName);
	bboxSize->setValue(x, y, z);
}

void GeometryNode::getBoundingBoxSize(float value[]) 
{
	SFVec3f *bboxSize = (SFVec3f *)getPrivateField(bboxSizePrivateFieldName);
	bboxSize->getValue(value);
}

////////////////////////////////////////////////
//	BoundingBoxCenter
////////////////////////////////////////////////

void GeometryNode::setBoundingBoxCenter(float value[]) 
{
	SFVec3f *bboxCenter = (SFVec3f *)getPrivateField(bboxCenterPrivateFieldName);
	bboxCenter->setValue(value);
}

void GeometryNode::setBoundingBoxCenter(float x, float y, float z) 
{
	SFVec3f *bboxCenter = (SFVec3f *)getPrivateField(bboxCenterPrivateFieldName);
	bboxCenter->setValue(x, y, z);
}

void GeometryNode::getBoundingBoxCenter(float value[]) 
{
	SFVec3f *bboxCenter = (SFVec3f *)getPrivateField(bboxCenterPrivateFieldName);
	bboxCenter->getValue(value);
}

////////////////////////////////////////////////
//	BoundingBox
////////////////////////////////////////////////

void GeometryNode::setBoundingBox(BoundingBox *bbox) 
{
	float center[3];
	float size[3];
	bbox->getCenter(center);
	bbox->getSize(size);
	setBoundingBoxCenter(center);
	setBoundingBoxSize(size);
}

////////////////////////////////////////////////
//	OpenGL
////////////////////////////////////////////////

#ifdef SUPPORT_OPENGL

void GeometryNode::setDisplayList(unsigned int n) 
{
	SFInt32 *dispList = (SFInt32 *)getPrivateField(displayListPrivateFieldString);
	dispList->setValue((int)n);
}

unsigned int GeometryNode::getDisplayList() 
{
	SFInt32 *dispList = (SFInt32 *)getPrivateField(displayListPrivateFieldString);
	return (unsigned int)dispList->getValue();
} 

void GeometryNode::draw()
{
	unsigned int nDisplayList = getDisplayList();
	if (0 < nDisplayList)
		glCallList(nDisplayList);
}

#endif