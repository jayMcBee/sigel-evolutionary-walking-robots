/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	TextureCoordinateNode.cpp
*
******************************************************************/

#include "TextureCoordinateNode.h"

TextureCoordinateNode::TextureCoordinateNode() 
{
	setHeaderFlag(false);
	setType(textureCoordinateNodeString);

	// point exposed field
	MFVec2f *mfpoint = new MFVec2f();
	mfpoint->setName(pointFieldString);
	addExposedField(mfpoint);
}

TextureCoordinateNode::~TextureCoordinateNode() 
{
}

////////////////////////////////////////////////
//	point 
////////////////////////////////////////////////

void TextureCoordinateNode::addPoint(float point[]) 
{
	MFVec2f *mfpoint = (MFVec2f *)getExposedField(pointFieldString);
	mfpoint->addValue(point);
}

int TextureCoordinateNode::getNPoints() 
{
	MFVec2f *mfpoint = (MFVec2f *)getExposedField(pointFieldString);
	return mfpoint->getSize();
}

void TextureCoordinateNode::getPoint(int index, float point[]) 
{
	MFVec2f *mfpoint = (MFVec2f *)getExposedField(pointFieldString);
	mfpoint->get1Value(index, point);
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool TextureCoordinateNode::isChildNodeType(Node *node)
{
	return false;
}

void TextureCoordinateNode::initialize() 
{
}

void TextureCoordinateNode::uninitialize() 
{
}

void TextureCoordinateNode::update() 
{
}

////////////////////////////////////////////////
//	Output
////////////////////////////////////////////////

void TextureCoordinateNode::outputContext(ostream &printStream, String indentString) 
{
	if (0 < getNPoints()) {
		MFVec2f *mfpoint = (MFVec2f *)getExposedField(pointFieldString);
		printStream <<  indentString << "\t" << "point ["  << endl;
		mfpoint->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

TextureCoordinateNode *TextureCoordinateNode::next() 
{
	return (TextureCoordinateNode *)Node::next(getType());
}

TextureCoordinateNode *TextureCoordinateNode::nextTraversal() 
{
	return (TextureCoordinateNode *)Node::nextTraversalByType(getType());
}
