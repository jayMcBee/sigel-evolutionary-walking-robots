/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	CollisionNode.cpp
*
******************************************************************/

#include "vrmlfields.h"
#include "CollisionNode.h"

CollisionNode::CollisionNode() 
{
	setHeaderFlag(false);
	setType(collisionNodeString);

	// collide exposed field
	SFBool *collide = new SFBool(true);
	addExposedField(collideFieldString, collide);

	// collide event out
	SFTime *collideTime = new SFTime(-1.0);
	addEventOut(collideTimeFieldString, collideTime);
}

CollisionNode::~CollisionNode() 
{
}

////////////////////////////////////////////////
//	collide
////////////////////////////////////////////////

void CollisionNode::setCollide(bool  value) 
{
	SFBool *collide = (SFBool *)getExposedField(collideFieldString);
	collide->setValue(value);
}

void CollisionNode::setCollide(int value) 
{
	setCollide(value ? true : false);
}

bool CollisionNode::getCollide() 
{
	SFBool *collide = (SFBool *)getExposedField(collideFieldString);
	return collide->getValue();
}

////////////////////////////////////////////////
//	collideTime
////////////////////////////////////////////////

void CollisionNode::setcollideTime(double value) 
{
	SFTime *collideTime = (SFTime *)getEventOut(collideTimeFieldString);
	collideTime->setValue(value);
}

double CollisionNode::getcollideTime() 
{
	SFTime *collideTime = (SFTime *)getEventOut(collideTimeFieldString);
	return collideTime->getValue();
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

CollisionNode *CollisionNode::next() 
{
	return (CollisionNode *)Node::next(getType());
}

CollisionNode *CollisionNode::nextTraversal() 
{
	return (CollisionNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool CollisionNode::isChildNodeType(Node *node)
{
	if (node->isCommonNode() || node->isBindableNode() ||node->isInterpolatorNode() || node->isSensorNode() || node->isGroupingNode() || node->isSpecialGroupNode())
		return true;
	else
		return false;
}

void CollisionNode::initialize() 
{
	recomputeBoundingBox();
}

void CollisionNode::uninitialize() 
{
}

void CollisionNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void CollisionNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *collide = (SFBool *)getExposedField(collideFieldString);
	printStream << indentString << "\t" << "collide " << collide << endl;
}
