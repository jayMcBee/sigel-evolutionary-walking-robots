/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	ColorInterpolatorNode.cpp
*
******************************************************************/

#include "vrmlfields.h"
#include "ColorInterpolatorNode.h"

ColorInterpolatorNode::ColorInterpolatorNode() 
{
	setHeaderFlag(false);
	setType(colorInterpolatorNodeString);

	// key exposed field
	MFFloat *key = new MFFloat();
	addExposedField(keyFieldString, key);

	// keyValue exposed field
	MFColor *keyValue = new MFColor();
	addExposedField(keyValueFieldString, keyValue);

	// set_fraction eventIn field
	SFFloat *setFraction = new SFFloat(0.0f);
	addEventIn(fractionFieldString, setFraction);

	// value_changed eventOut field
	SFColor *valueChanged = new SFColor(0.0f, 0.0f, 0.0f);
	addEventOut(valueFieldString, valueChanged);
}

ColorInterpolatorNode::~ColorInterpolatorNode() 
{
}

////////////////////////////////////////////////
//	key
////////////////////////////////////////////////
	
void ColorInterpolatorNode::addKey(float value) 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	key->addValue(value);
}

int ColorInterpolatorNode::getNKeys() 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	return key->getSize();
}

float ColorInterpolatorNode::getKey(int index) 
{
	MFFloat *key = (MFFloat *)getExposedField(keyFieldString);
	return key->get1Value(index);
}

Field *ColorInterpolatorNode::getKeyField() 
{
	return getExposedField(keyFieldString);
}

////////////////////////////////////////////////
//	keyValue
////////////////////////////////////////////////
	
void ColorInterpolatorNode::addKeyValue(float color[]) 
{
	MFColor *keyValue = (MFColor *)getExposedField(keyValueFieldString);
	keyValue->addValue(color);
}

int ColorInterpolatorNode::getNKeyValues() 
{
	MFColor *keyValue = (MFColor *)getExposedField(keyValueFieldString);
	return keyValue->getSize();
}
	
void ColorInterpolatorNode::getKeyValue(int index, float color[]) 
{
	MFColor *keyValue = (MFColor *)getExposedField(keyValueFieldString);
	keyValue->get1Value(index, color);
}

Field *ColorInterpolatorNode::getKeyValueField() 
{
	return getExposedField(keyValueFieldString);
}

////////////////////////////////////////////////
//	fraction
////////////////////////////////////////////////
	
void ColorInterpolatorNode::setFraction(float value) 
{
	SFFloat *fraction = (SFFloat *)getEventIn(fractionFieldString);
	fraction->setValue(value);
}

float ColorInterpolatorNode::getFraction() 
{
	SFFloat *fraction = (SFFloat *)getEventIn(fractionFieldString);
	return fraction->getValue();
}

Field *ColorInterpolatorNode::getFractionField() 
{
	return getEventIn(fractionFieldString);
}

////////////////////////////////////////////////
//	value
////////////////////////////////////////////////
	
void ColorInterpolatorNode::setValue(float color[]) 
{
	SFColor *value = (SFColor *)getEventOut(valueFieldString);
	value->setValue(color);
}

void ColorInterpolatorNode::getValue(float color[]) 
{
	SFColor *value = (SFColor *)getEventOut(valueFieldString);
	value->getValue(color);
}

Field *ColorInterpolatorNode::getValueField() 
{
	return getEventOut(valueFieldString);
}

////////////////////////////////////////////////
//	Virtual functions
////////////////////////////////////////////////
	
bool ColorInterpolatorNode::isChildNodeType(Node *node)
{
	return false;
}

void ColorInterpolatorNode::initialize() 
{
}

void ColorInterpolatorNode::uninitialize() 
{
}

void ColorInterpolatorNode::update() 
{
	int n;

	float fraction = getFraction();
	int index = -1;
	int nKey = getNKeys();
	for (n=0; n<(nKey-1); n++) {
		if (getKey(n) <= fraction && fraction <= getKey(n+1)) {
			index = n;
			break;
		}
	}
	if (index == -1)
		return;

	float scale = (fraction - getKey(index)) / (getKey(index+1) - getKey(index));	
	float color1[3];
	float color2[3];
	float colorOut[3];

	getKeyValue(index, color1);
	getKeyValue(index+1, color2);
	for (n=0; n<3; n++)
		colorOut[n] = color1[n] + (color2[n] - color1[n])*scale;

	setValue(colorOut);
	sendEvent(getValueField());
}

void ColorInterpolatorNode::outputContext(ostream &printStream, String indentString) 
{
	if (0 < getNKeys()) {
		MFFloat *key = (MFFloat *)getExposedField(keyFieldString);	
		printStream << indentString << "\tkey [" << endl;
		key->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t]" << endl;
	}

	if (0 < getNKeyValues()) {
		MFColor *keyValue = (MFColor *)getExposedField(keyValueFieldString);
		printStream << indentString << "\tkeyValue [" << endl;
		keyValue->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t]" << endl;
	}
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

ColorInterpolatorNode *ColorInterpolatorNode::next() 
{
	return (ColorInterpolatorNode *)Node::next(getType());
}

ColorInterpolatorNode *ColorInterpolatorNode::nextTraversal() 
{
	return (ColorInterpolatorNode *)Node::nextTraversalByType(getType());
}

