/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	AudioClip.cpp
*
******************************************************************/

#include "TimeSensorNode.h"

TimeSensorNode::TimeSensorNode() 
{
	setHeaderFlag(false);
	setType(timeSensorNodeString);

	// enabled exposed field
	SFBool *enabled = new SFBool(true);
	addExposedField(enabledFieldString, enabled);

	// loop exposed field
	SFBool *loop = new SFBool(false);
	addExposedField(loopFieldString, loop);

	// cybleInterval exposed field
	SFTime *cybleInterval = new SFTime(1.0);
	addExposedField(cybleIntervalFieldString, cybleInterval);

	// startTime exposed field
	SFTime *startTime = new SFTime(0.0f);
	addExposedField(startTimeFieldString, startTime);

	// stopTime exposed field
	SFTime *stopTime = new SFTime(0.0f);
	addExposedField(stopTimeFieldString, stopTime);

	// cycleTime eventOut field
	SFTime *cycleTime = new SFTime(-1.0f);
	addEventOut(cycleTimeFieldString, cycleTime);

	// time eventOut field
	SFTime *time = new SFTime(-1.0f);
	addEventOut(timeFieldString, time);

	// isActive eventOut field
	SFBool *isActive = new SFBool(false);
	addEventOut(isActiveFieldString, isActive);

	// fraction_changed eventOut field
	SFFloat *fractionChanged = new SFFloat(0.0f);
	addEventOut(fractionFieldString, fractionChanged);
}

TimeSensorNode::~TimeSensorNode() 
{
}

////////////////////////////////////////////////
//	Enabled
////////////////////////////////////////////////
	
void TimeSensorNode::setEnabled(bool value) 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	bEnabled->setValue(value);
}

void TimeSensorNode::setEnabled(int value) 
{

	setEnabled(value ? true : false);
}

bool TimeSensorNode::getEnabled() 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	return bEnabled->getValue();
}

bool TimeSensorNode::isEnabled()
{
	return getEnabled();
}

Field *TimeSensorNode::getEnabledField() 
{
	return getExposedField(enabledFieldString);
}

////////////////////////////////////////////////
//	Loop
////////////////////////////////////////////////
	
void TimeSensorNode::setLoop(bool value) 
{
	SFBool *loop = (SFBool *)getExposedField(loopFieldString);
	loop->setValue(value);
}

void TimeSensorNode::setLoop(int value) 
{
	setLoop(value ? true : false);
}

bool TimeSensorNode::getLoop() 
{
	SFBool *loop = (SFBool *)getExposedField(loopFieldString);
	return loop->getValue();
}

bool TimeSensorNode::isLoop() 
{
	return getLoop();
}

Field *TimeSensorNode::getLoopField() 
{
	return getExposedField(loopFieldString);
}

////////////////////////////////////////////////
//	Cyble Interval
////////////////////////////////////////////////
	
void TimeSensorNode::setCycleInterval(double value) 
{
	SFTime *cycle = (SFTime *)getExposedField(cybleIntervalFieldString);
	cycle->setValue(value);
}

double TimeSensorNode::getCycleInterval() 
{
	SFTime *cycle = (SFTime *)getExposedField(cybleIntervalFieldString);
	return cycle->getValue();
}

Field *TimeSensorNode::getCycleIntervalField() 
{
	return getExposedField(cybleIntervalFieldString);
}

////////////////////////////////////////////////
//	Start time
////////////////////////////////////////////////
	
void TimeSensorNode::setStartTime(double value) 
{
	SFTime *time = (SFTime *)getExposedField(startTimeFieldString);
	time->setValue(value);
}

double TimeSensorNode::getStartTime() 
{
	SFTime *time = (SFTime *)getExposedField(startTimeFieldString);
	return time->getValue();
}

Field *TimeSensorNode::getStartTimeField() 
{
	return getExposedField(startTimeFieldString);
}

////////////////////////////////////////////////
//	Stop time
////////////////////////////////////////////////
	
void TimeSensorNode::setStopTime(double value) 
{
	SFTime *time = (SFTime *)getExposedField(stopTimeFieldString);
	time->setValue(value);
}

double TimeSensorNode::getStopTime() 
{
	SFTime *time = (SFTime *)getExposedField(stopTimeFieldString);
	return time->getValue();
}

Field *TimeSensorNode::getStopTimeField() 
{
	return getExposedField(stopTimeFieldString);
}

////////////////////////////////////////////////
//	isActive
////////////////////////////////////////////////
	
void TimeSensorNode::setIsActive(bool  value) 
{
	SFBool *field = (SFBool *)getEventOut(isActiveFieldString);
	field->setValue(value);
}

bool  TimeSensorNode::getIsActive() 
{
	SFBool *field = (SFBool *)getEventOut(isActiveFieldString);
	return field->getValue();
}

bool  TimeSensorNode::isActive() 
{
	SFBool *field = (SFBool *)getEventOut(isActiveFieldString);
	return field->getValue();
}

Field *TimeSensorNode::getIsActiveField() 
{
	return getEventOut(isActiveFieldString);
}

////////////////////////////////////////////////
//	fraction_changed
////////////////////////////////////////////////
	
void TimeSensorNode::setFractionChanged(float value) 
{
	SFFloat *field = (SFFloat *)getEventOut(fractionFieldString);
	field->setValue(value);
}

float TimeSensorNode::getFractionChanged() 
{
	SFFloat *field = (SFFloat *)getEventOut(fractionFieldString);
		return field->getValue();
}

Field *TimeSensorNode::getFractionChangedField() 
{
	return getEventOut(fractionFieldString);
}

////////////////////////////////////////////////
//	Cycle time
////////////////////////////////////////////////
	
void TimeSensorNode::setCycleTime(double value) 
{
	SFTime *time = (SFTime *)getEventOut(cycleTimeFieldString);
	time->setValue(value);
}

double TimeSensorNode::getCycleTime() 
{
	SFTime *time = (SFTime *)getEventOut(cycleTimeFieldString);
	return time->getValue();
}

Field *TimeSensorNode::getCycleTimeField() 
{
	return getEventOut(cycleTimeFieldString);
}

////////////////////////////////////////////////
//	Time
////////////////////////////////////////////////
	
void TimeSensorNode::setTime(double value)
{
	SFTime *time = (SFTime *)getEventOut(timeFieldString);
	time->setValue(value);
}

double TimeSensorNode::getTime() 
{
	SFTime *time = (SFTime *)getEventOut(timeFieldString);
	return time->getValue();
}

Field *TimeSensorNode::getTimeField() 
{
	return getEventOut(timeFieldString);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

TimeSensorNode *TimeSensorNode::next() 
{
	return (TimeSensorNode *)Node::next(getType());
}

TimeSensorNode *TimeSensorNode::nextTraversal() 
{
	return (TimeSensorNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	Virtual functions
////////////////////////////////////////////////
	
bool TimeSensorNode::isChildNodeType(Node *node)
{
	return false;
}

void TimeSensorNode::initialize() 
{
	setCycleTime(-1.0f);
	setIsActive(false);
}

void TimeSensorNode::uninitialize() 
{
}

void TimeSensorNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	SFBool *loop = (SFBool *)getExposedField(loopFieldString);

	printStream << indentString << "\t" << "cycleInterval " << getCycleInterval() << endl;
	printStream << indentString << "\t" << "enabled " << bEnabled << endl;
	printStream << indentString << "\t" << "loop " << loop << endl;
	printStream << indentString << "\t" << "startTime " << getStartTime() << endl;
	printStream << indentString << "\t" << "stopTime " << getStopTime() << endl;
}

//////////////////////////////////////////////
//	AudioClip::update
////////////////////////////////////////////////

void TimeSensorNode::update() 
{
	static double currentTime = 0;

	double startTime = getStartTime();
	double stopTime = getStopTime();
	double cycleInterval = getCycleInterval();

	bool bActive	= isActive();
	bool bEnable	= isEnabled();
	bool bLoop		= isLoop();

	if (currentTime == 0)
		currentTime = GetCurrentSystemTime();

	// isActive 
	if (bEnable == false && bActive == true) {
		setIsActive(false);
		sendEvent(getIsActiveField());
		return;
	}

	if (bActive == false && bEnable == true) {
		if (startTime <= currentTime) {
			if (bLoop == true && stopTime <= startTime)
				bActive = true;
			else if (bLoop == false && stopTime <= startTime)
				bActive = true;
			else if (currentTime <= stopTime) {
				if (bLoop == true && startTime < stopTime)
					bActive = true;
				else if	(bLoop == false && startTime < (startTime + cycleInterval) && (startTime + cycleInterval) <= stopTime)
					bActive = true;
				else if (bLoop == false && startTime < stopTime && stopTime < (startTime + cycleInterval))
					bActive = true;
			}
		}
		if (bActive) {
			setIsActive(true);
			sendEvent(getIsActiveField());
			setCycleTime(currentTime);
			sendEvent(getCycleTimeField());
		}
	}

	currentTime = GetCurrentSystemTime();
	
	if (bActive == true && bEnable == true) {
		if (bLoop == true && startTime < stopTime) {
			if (stopTime < currentTime)
				bActive = false;
		}
		else if (bLoop == false && stopTime <= startTime) {
			if (startTime + cycleInterval < currentTime)
				bActive = false;
		}
		else if (bLoop == false && startTime < (startTime + cycleInterval) && (startTime + cycleInterval) <= stopTime) {
			if (startTime + cycleInterval < currentTime)
				bActive = false;
		}
		else if (bLoop == false && startTime < stopTime && stopTime < (startTime + cycleInterval)) {
			if (stopTime < currentTime)
				bActive = false;
		}

		if (bActive == false) {
			setIsActive(false);
			sendEvent(getIsActiveField());
		}
	}

	if (bEnable == false || isActive() == false)
		return;

	// fraction_changed 
	double	fraction = fmod(currentTime - startTime, cycleInterval);
	if (fraction == 0.0 && startTime < currentTime)
		fraction = 1.0;
	else
		fraction /= cycleInterval;
	setFractionChanged((float)fraction);
	sendEvent(getFractionChangedField());

	// cycleTime
	double	cycleTime		= getCycleTime();
	double	cycleEndTime	= cycleTime + cycleInterval;
	while (cycleEndTime < currentTime) {
		setCycleTime(cycleEndTime);
		cycleEndTime += cycleInterval;
		setCycleTime(currentTime);
		sendEvent(getCycleTimeField());
	}

	// time
	setTime(currentTime);
	sendEvent(getTimeField());
}

