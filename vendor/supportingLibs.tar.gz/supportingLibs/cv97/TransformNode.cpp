/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	Node.cpp
*
******************************************************************/

#include "TransformNode.h"

TransformNode::TransformNode() 
{
	setHeaderFlag(false);
	setType(transformNodeString);

	// translation exposed field
	SFVec3f *translation = new SFVec3f(0.0f, 0.0f, 0.0f);
	translation->setName(translationFieldString);
	addExposedField(translation);

	// scale exposed field
	SFVec3f *scale = new SFVec3f(1.0f, 1.0f, 1.0f);
	scale->setName(scaleFieldString);
	addExposedField(scale);

	// center exposed field
	SFVec3f *center = new SFVec3f(0.0f, 0.0f, 0.0f);
	center->setName(centerFieldString);
	addExposedField(center);

	// rotation exposed field
	SFRotation *rotation = new SFRotation(0.0f, 0.0f, 1.0f, 0.0f);
	rotation->setName(rotationFieldString);
	addExposedField(rotation);

	// scaleOrientation exposed field
	SFRotation *scaleOrientation = new SFRotation(0.0f, 0.0f, 1.0f, 0.0f);
	scaleOrientation->setName(scaleOrientationFieldString);
	addExposedField(scaleOrientation);
}

TransformNode::~TransformNode() 
{
}

////////////////////////////////////////////////
//	Translation
////////////////////////////////////////////////

void TransformNode::setTranslation(float value[]) 
{
	SFVec3f *translation = (SFVec3f *)getExposedField(translationFieldString);
	translation->setValue(value);
}

void TransformNode::setTranslation(float x, float y, float z) 
{
	SFVec3f *translation = (SFVec3f *)getExposedField(translationFieldString);
	translation->setValue(x, y, z);
}

void TransformNode::getTranslation(float value[]) 
{
	SFVec3f *translation = (SFVec3f *)getExposedField(translationFieldString);
	translation->getValue(value);
}

////////////////////////////////////////////////
//	Scale
////////////////////////////////////////////////

void TransformNode::setScale(float value[]) 
{
	SFVec3f *scale = (SFVec3f *)getExposedField(scaleFieldString);
	scale->setValue(value);
}

void TransformNode::setScale(float x, float y, float z) 
{
	SFVec3f *scale = (SFVec3f *)getExposedField(scaleFieldString);
	scale->setValue(x, y, z);
}

void TransformNode::getScale(float value[]) 
{
	SFVec3f *scale = (SFVec3f *)getExposedField(scaleFieldString);
	scale->getValue(value);
}

////////////////////////////////////////////////
//	Center
////////////////////////////////////////////////

void TransformNode::setCenter(float value[]) 
{
	SFVec3f *center = (SFVec3f *)getExposedField(centerFieldString);
	center->setValue(value);
}

void TransformNode::setCenter(float x, float y, float z) 
{
	SFVec3f *center = (SFVec3f *)getExposedField(centerFieldString);
	center->setValue(x, y, z);
}

void TransformNode::getCenter(float value[]) 
{
	SFVec3f *center = (SFVec3f *)getExposedField(centerFieldString);
	center->getValue(value);
}

////////////////////////////////////////////////
//	Rotation
////////////////////////////////////////////////

void TransformNode::setRotation(float value[]) 
{
	SFRotation *rotation = (SFRotation *)getExposedField(rotationFieldString);
	rotation->setValue(value);
}

void TransformNode::setRotation(float x, float y, float z, float w) 
{
	SFRotation *rotation = (SFRotation *)getExposedField(rotationFieldString);
	rotation->setValue(x, y, z, w);
}

void TransformNode::getRotation(float value[]) 
{
	SFRotation *rotation = (SFRotation *)getExposedField(rotationFieldString);
	rotation->getValue(value);
}

////////////////////////////////////////////////
//	ScaleOrientation
////////////////////////////////////////////////

void TransformNode::setScaleOrientation(float value[]) 
{
	SFRotation *scaleOrientation = (SFRotation *)getExposedField(scaleOrientationFieldString);
	scaleOrientation->setValue(value);
}

void TransformNode::setScaleOrientation(float x, float y, float z, float w) 
{
	SFRotation *scaleOrientation = (SFRotation *)getExposedField(scaleOrientationFieldString);
	scaleOrientation->setValue(x, y, z, w);
}

void TransformNode::getScaleOrientation(float value[]) 
{
	SFRotation *scaleOrientation = (SFRotation *)getExposedField(scaleOrientationFieldString);
	scaleOrientation->getValue(value);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

TransformNode *TransformNode::next() 
{
	return (TransformNode *)Node::next(getType());
}

TransformNode *TransformNode::nextTraversal() 
{
	return (TransformNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool TransformNode::isChildNodeType(Node *node)
{
	if (node->isCommonNode() || node->isBindableNode() ||node->isInterpolatorNode() || node->isSensorNode() || node->isGroupingNode() || node->isSpecialGroupNode())
		return true;
	else
		return false;
}

void TransformNode::initialize() 
{
	recomputeBoundingBox();
}

void TransformNode::uninitialize() 
{
}

void TransformNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void TransformNode::outputContext(ostream &printStream, String indentString) 
{
	float vec[3];
	float rot[4];
	getTranslation(vec);		printStream << indentString << "\t" << "translation " << vec[0] << " "<< vec[1] << " " << vec[2] << endl;
	getRotation(rot);			printStream << indentString << "\t" << "rotation " << rot[0] << " "<< rot[1] << " " << rot[2] << " " << rot[3] << endl;
	getScale(vec);				printStream << indentString << "\t" << "scale " << vec[0] << " "<< vec[1] << " " << vec[2] << endl;
	getScaleOrientation(rot);	printStream << indentString << "\t" << "scaleOrientation " << rot[0] << " "<< rot[1] << " " << rot[2] << " " << rot[3] << endl;
	getCenter(vec);				printStream << indentString << "\t" << "center " << vec[0] << " "<< vec[1] << " " << vec[2] << endl;
}

////////////////////////////////////////////////
//	Matrix
////////////////////////////////////////////////

void TransformNode::getSFMatrix(SFMatrix *mOut)
{
	float	center[3];
	float	rotation[4];
	float	scale[3];
	float	scaleOri[4];
	float	trans[3];
	SFMatrix	mSRI;
	SFMatrix	mSR;
	SFMatrix	mCI;
	SFMatrix	mC;
	SFMatrix	mT;
	SFMatrix	mR;
	SFMatrix	mS;

	getTranslation(trans); 
	mT.setTranslation(trans);

	getCenter(center); 
	mC.setTranslation(center);

	getRotation(rotation);
	mR.setRotation(rotation);

	getScaleOrientation(scaleOri); 
	mSR.setRotation(scaleOri);

	getScale(scale);
	mS.setScaling(scale);

	getScaleOrientation(scaleOri); 
	scaleOri[3] = -scaleOri[3]; 
	mSRI.setRotation(scaleOri);

	getCenter(center); 
	center[0] = -center[0]; 
	center[1] = -center[1]; 
	center[2] = -center[2]; 
	mCI.setTranslation(center);

	mOut->init();
	mOut->add(&mT);
	mOut->add(&mC);
	mOut->add(&mR);
	mOut->add(&mSR);
	mOut->add(&mS);
	mOut->add(&mSRI);
	mOut->add(&mCI);
}
