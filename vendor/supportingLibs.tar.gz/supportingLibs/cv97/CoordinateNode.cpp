/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	CoordinateNode.cpp
*
******************************************************************/

#include "CoordinateNode.h"

CoordinateNode::CoordinateNode() 
{
	setHeaderFlag(false);
	setType(coordinateNodeString);

	// point exposed field
	MFVec3f *mfpoint = new MFVec3f();
	mfpoint->setName(pointFieldString);
	addExposedField(mfpoint);
}

CoordinateNode::~CoordinateNode() {
}

////////////////////////////////////////////////
//	point 
////////////////////////////////////////////////

void CoordinateNode::addPoint(float point[]) 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	mfpoint->addValue(point);
}

void CoordinateNode::addPoint(float x, float y, float z) 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	mfpoint->addValue(x, y, z);
}

int CoordinateNode::getNPoints() 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	return mfpoint->getSize();
}

void CoordinateNode::getPoint(int index, float point[]) 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	mfpoint->get1Value(index, point);
}

void CoordinateNode::setPoint(int index, float point[]) 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	mfpoint->set1Value(index, point);
}

void CoordinateNode::setPoint(int index, float x, float y, float z) 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	mfpoint->set1Value(index, x, y, z);
}

void CoordinateNode::removePoint(int index) 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	mfpoint->remove(index);
}

void CoordinateNode::removeLastPoint() 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	mfpoint->removeLastObject();
}

void CoordinateNode::removeFirstPoint() 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	mfpoint->removeFirstObject();
}

void CoordinateNode::removeAllPoints() 
{
	MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
	mfpoint->clear();
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool CoordinateNode::isChildNodeType(Node *node)
{
	return false;
}

void CoordinateNode::initialize() 
{
}

void CoordinateNode::uninitialize() 
{
}

void CoordinateNode::update() 
{
}

////////////////////////////////////////////////
//	Output
////////////////////////////////////////////////

void CoordinateNode::outputContext(ostream &printStream, String indentString) 
{
	if (0 < getNPoints()) {
		MFVec3f *mfpoint = (MFVec3f *)getExposedField(pointFieldString);
		printStream <<  indentString << "\t" << "point ["  << endl;
		mfpoint->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

CoordinateNode *CoordinateNode::next() 
{
	return (CoordinateNode *)Node::next(getType());
}

CoordinateNode *CoordinateNode::nextTraversal() 
{
	return (CoordinateNode *)Node::nextTraversalByType(getType());
}
