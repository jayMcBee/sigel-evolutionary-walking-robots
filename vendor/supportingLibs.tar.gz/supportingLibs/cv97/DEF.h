/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	DEF.h
*
******************************************************************/

#ifndef _DEF_H_
#define _DEF_H_

#include "JString.h"
#include "CLinkedListNode.h"

class DEF : public CLinkedListNode<DEF> {

	JString		mName;
	JString		mString;

public:

	DEF (char *name, char *string);
	~DEF();

	////////////////////////////////////////////////
	//	Name
	////////////////////////////////////////////////

	void setName(char *name);
	char *getName();

	////////////////////////////////////////////////
	//	Name
	////////////////////////////////////////////////

	void setString(char *string);
	char *getString();
};

#endif


