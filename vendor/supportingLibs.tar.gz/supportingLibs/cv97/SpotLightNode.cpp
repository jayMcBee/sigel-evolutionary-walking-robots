/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	SpotLightNode.cpp
*
******************************************************************/

#include "SpotLightNode.h"

SpotLightNode::SpotLightNode() 
{
	setType(spotLightNodeString);

	// ambient intensity exposed field
	SFFloat *ambientIntensity = new SFFloat(0.0f);
	ambientIntensity->setName(ambientIntensityFieldString);
	addExposedField(ambientIntensity);

	// location exposed field
	SFVec3f *location = new SFVec3f(0.0f, 0.0f, 0.0f);
	location->setName(locationFieldString);
	addExposedField(location);

	// direction exposed field
	SFVec3f *direction = new SFVec3f(0.0f, 0.0f, -1.0f);
	direction->setName(directionFieldString);
	addExposedField(direction);

	// radius exposed field
	SFFloat *radius = new SFFloat(100.0f);
	radius->setName(radiusFieldString);
	addExposedField(radius);

	// attenuation exposed field
	SFVec3f *attenuation = new SFVec3f(1.0f, 0.0f, 0.0f);
	attenuation->setName(attenuationFieldString);
	addExposedField(attenuation);

	// beamWidth exposed field
	SFFloat *beamWidth = new SFFloat(1.570796f);
	beamWidth->setName(beamWidthFieldString);
	addExposedField(beamWidth);

	// cutOffAngle exposed field
	SFFloat *cutOffAngle = new SFFloat(0.785398f);
	cutOffAngle->setName(cutOffAngleFieldString);
	addExposedField(cutOffAngle);
}

SpotLightNode::~SpotLightNode() 
{
}

////////////////////////////////////////////////
//	AmbientIntensity
////////////////////////////////////////////////
	
void SpotLightNode::setAmbientIntensity(float value) 
{
	SFFloat *intensity = (SFFloat *)getExposedField(ambientIntensityFieldString);
	intensity->setValue(value);
}

float SpotLightNode::getAmbientIntensity() 
{
	SFFloat *intensity = (SFFloat *)getExposedField(ambientIntensityFieldString);
	return intensity->getValue();
}

////////////////////////////////////////////////
//	Location
////////////////////////////////////////////////

void SpotLightNode::setLocation(float value[]) 
{
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	location->setValue(value);
}

void SpotLightNode::setLocation(float x, float y, float z) 
{
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	location->setValue(x, y, z);
}

void SpotLightNode::getLocation(float value[]) 
{
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	location->getValue(value);
}

////////////////////////////////////////////////
//	Direction
////////////////////////////////////////////////

void SpotLightNode::setDirection(float value[]) 
{
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	direction->setValue(value);
}

void SpotLightNode::setDirection(float x, float y, float z) 
{
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	direction->setValue(x, y, z);
}

void SpotLightNode::getDirection(float value[]) 
{
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	direction->getValue(value);
}

////////////////////////////////////////////////
//	Radius
////////////////////////////////////////////////
	
void SpotLightNode::setRadius(float value) 
{
	SFFloat *radius = (SFFloat *)getExposedField(radiusFieldString);
	radius->setValue(value);
}

float SpotLightNode::getRadius() 
{
	SFFloat *radius = (SFFloat *)getExposedField(radiusFieldString);
	return radius->getValue();
}

////////////////////////////////////////////////
//	Attenuation
////////////////////////////////////////////////

void SpotLightNode::setAttenuation(float value[]) 
{
	SFVec3f *attenuation = (SFVec3f *)getExposedField(attenuationFieldString);
	attenuation->setValue(value);
}

void SpotLightNode::setAttenuation(float x, float y, float z) 
{
	SFVec3f *attenuation = (SFVec3f *)getExposedField(attenuationFieldString);
	attenuation->setValue(x, y, z);
}

void SpotLightNode::getAttenuation(float value[]) 
{
	SFVec3f *attenuation = (SFVec3f *)getExposedField(attenuationFieldString);
	attenuation->getValue(value);
}

////////////////////////////////////////////////
//	BeamWidth
////////////////////////////////////////////////
	
void SpotLightNode::setBeamWidth(float value) 
{
	SFFloat *bwidth = (SFFloat *)getExposedField(beamWidthFieldString);
	bwidth->setValue(value);
}

float SpotLightNode::getBeamWidth() 
{
	SFFloat *bwidth = (SFFloat *)getExposedField(beamWidthFieldString);
	return bwidth->getValue();
}

////////////////////////////////////////////////
//	CutOffAngle
////////////////////////////////////////////////
	
void SpotLightNode::setCutOffAngle(float value) 
{
	SFFloat *angle = (SFFloat *)getExposedField(cutOffAngleFieldString);
	angle->setValue(value);
}

float SpotLightNode::getCutOffAngle() 
{
	SFFloat *angle = (SFFloat *)getExposedField(cutOffAngleFieldString);
	return angle->getValue();
}

////////////////////////////////////////////////
//	Diffuse Color
////////////////////////////////////////////////

void SpotLightNode::getDiffuseColor(float value[]) 
{
	getColor(value);
	float	intensity = getIntensity();
	value[0] *= intensity;
	value[1] *= intensity;
	value[2] *= intensity;
}

////////////////////////////////////////////////
//	Ambient Color
////////////////////////////////////////////////

void SpotLightNode::getAmbientColor(float value[]) 
{
	getColor(value);
	float	intensity = getIntensity();
	float	ambientIntensity = getAmbientIntensity();
	value[0] *= intensity * ambientIntensity;
	value[1] *= intensity * ambientIntensity;
	value[2] *= intensity * ambientIntensity;
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

SpotLightNode *SpotLightNode::next() 
{
	return (SpotLightNode *)Node::next(getType());
}

SpotLightNode *SpotLightNode::nextTraversal() 
{
	return (SpotLightNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool SpotLightNode::isChildNodeType(Node *node)
{
	return false;
}

void SpotLightNode::initialize() 
{
}

void SpotLightNode::uninitialize() 
{
}

void SpotLightNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void SpotLightNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *bon = (SFBool *)getExposedField(onFieldString);
	SFColor *color = (SFColor *)getExposedField(colorFieldString);
	SFVec3f *direction = (SFVec3f *)getExposedField(directionFieldString);
	SFVec3f *location = (SFVec3f *)getExposedField(locationFieldString);
	SFVec3f *attenuation = (SFVec3f *)getExposedField(attenuationFieldString);

	printStream << indentString << "\t" << "on " << bon << endl;
	printStream << indentString << "\t" << "intensity " << getIntensity() << endl;
	printStream << indentString << "\t" << "ambientIntensity " << getAmbientIntensity() << endl;
	printStream << indentString << "\t" << "color " << color << endl;
	printStream << indentString << "\t" << "direction " << direction << endl;
	printStream << indentString << "\t" << "location " << location << endl;
	printStream << indentString << "\t" << "beamWidth " << getBeamWidth() << endl;
	printStream << indentString << "\t" << "cutOffAngle " << getCutOffAngle() << endl;
	printStream << indentString << "\t" << "radius " << getRadius() << endl;
	printStream << indentString << "\t" << "attenuation " << attenuation << endl;
}
