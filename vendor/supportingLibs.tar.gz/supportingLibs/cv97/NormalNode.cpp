/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	NormalNode.cpp
*
******************************************************************/

#include "NormalNode.h"

NormalNode::NormalNode () 
{
	setHeaderFlag(false);
	setType(normalNodeString);

	// vector exposed field
	MFVec3f *vector = new MFVec3f();
	vector->setName(vectorFieldString);
	addExposedField(vector);
}

NormalNode::~NormalNode () 
{
}

////////////////////////////////////////////////
//	vector
////////////////////////////////////////////////
	
void NormalNode::addVector(float value[]) 
{
	MFVec3f *vector = (MFVec3f *)getExposedField(vectorFieldString);
	vector->addValue(value);
}

int NormalNode::getNVectors() 
{
	MFVec3f *vector = (MFVec3f *)getExposedField(vectorFieldString);
	return vector->getSize();
}

void NormalNode::getVector(int index, float value[]) 
{
	MFVec3f *vector = (MFVec3f *)getExposedField(vectorFieldString);
	vector->get1Value(index, value);
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool NormalNode::isChildNodeType(Node *node)
{
	return false;
}

void NormalNode::initialize() 
{
}

void NormalNode::uninitialize() 
{
}

void NormalNode::update() 
{
}

////////////////////////////////////////////////
//	Output
////////////////////////////////////////////////

void NormalNode::outputContext(ostream &printStream, String indentString) 
{
	if (0 < getNVectors()) {
		MFVec3f *vector = (MFVec3f *)getExposedField(vectorFieldString);
		printStream <<  indentString << "\t" << "vector ["  << endl;
		vector->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

NormalNode *NormalNode::next() 
{
	return (NormalNode *)Node::next(getType());
}

NormalNode *NormalNode::nextTraversal() 
{
	return (NormalNode *)Node::nextTraversalByType(getType());
}

