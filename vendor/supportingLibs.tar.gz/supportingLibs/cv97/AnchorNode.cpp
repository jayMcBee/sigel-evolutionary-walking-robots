/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1999
*
*	File:	AnchorNode.cpp
*
******************************************************************/

#include "AnchorNode.h"

AnchorNode::AnchorNode() 
{
	setHeaderFlag(false);
	setType(anchorNodeString);

	///////////////////////////
	// Exposed Field 
	///////////////////////////

	// description exposed field
	SFString *description = new SFString("");
	addExposedField(descriptionFieldString, description);

	// parameter exposed field
	MFString *parameter = new MFString();
	addExposedField(parameterFieldString, parameter);

	// url exposed field
	MFString *url = new MFString();
	addExposedField(urlFieldString, url);
}

AnchorNode::~AnchorNode() 
{
}

////////////////////////////////////////////////
//	Description
////////////////////////////////////////////////

void AnchorNode::setDescription(String value) 
{
	SFString *description = (SFString *)getExposedField(descriptionFieldString);
	description->setValue(value);
}

String AnchorNode::getDescription() 
{
	SFString *description = (SFString *)getExposedField(descriptionFieldString);
	return description->getValue();
}

////////////////////////////////////////////////
// Parameter
////////////////////////////////////////////////

void AnchorNode::addParameter(String value) 
{
	MFString *parameter = (MFString *)getExposedField(parameterFieldString);
	parameter->addValue(value);
}

int AnchorNode::getNParameters() 
{
	MFString *parameter = (MFString *)getExposedField(parameterFieldString);
	return parameter->getSize();
}

String AnchorNode::getParameter(int index) 
{
	MFString *parameter = (MFString *)getExposedField(parameterFieldString);
	return parameter->get1Value(index);
}

////////////////////////////////////////////////
// Url
////////////////////////////////////////////////

void AnchorNode::addUrl(String value) 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	url->addValue(value);
}

int AnchorNode::getNUrls() 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	return url->getSize();
}

String AnchorNode::getUrl(int index) 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	return url->get1Value(index);
}

void AnchorNode::setUrl(int index, char *urlString) 
{
	MFString *url = (MFString *)getExposedField(urlFieldString);
	url->set1Value(index, urlString);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

AnchorNode *AnchorNode::next() 
{
	return (AnchorNode *)Node::next(getType());
}

AnchorNode *AnchorNode::nextTraversal() 
{
	return (AnchorNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	virtual functions
////////////////////////////////////////////////

bool AnchorNode::isChildNodeType(Node *node)
{
	if (node->isCommonNode() || node->isBindableNode() ||node->isInterpolatorNode() || node->isSensorNode() || node->isGroupingNode() || node->isSpecialGroupNode())
		return true;
	else
		return false;
}

void AnchorNode::initialize() 
{
	recomputeBoundingBox();
}

void AnchorNode::uninitialize() {
}

void AnchorNode::update() 
{
}

void AnchorNode::outputContext(ostream &printStream, String indentString) 
{
	SFString *description = (SFString *)getExposedField(descriptionFieldString);
	printStream << indentString << "\t" << "description " << description << endl;
	
	if (0 < getNParameters()) {
		MFString *parameter = (MFString *)getExposedField(parameterFieldString);
		printStream << indentString << "\t" << "parameter ["  << endl;
		parameter->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}

	if (0 < getNUrls()) {
		MFString *url = (MFString *)getExposedField(urlFieldString);
		printStream << indentString << "\t" << "url [" << endl;
		url->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}
