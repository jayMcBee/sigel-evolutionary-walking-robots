/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	NodeList.cpp
*
******************************************************************/

#include "NodeList.h"

NodeList::NodeList() 
{
	RootNode *rootNode = new RootNode();
	setRootNode(rootNode);
}

NodeList::~NodeList() 
{
}
