/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	RouteNode.h
*
******************************************************************/

#ifndef _ROOTNODE_H_
#define _ROOTNODE_H_

#include "vrmlfields.h"
#include "Node.h"

class RootNode : public Node {

public:

	RootNode();
	~RootNode();

	////////////////////////////////////////////////
	//	functions
	////////////////////////////////////////////////
	
	bool isChildNodeType(Node *node);
	void initialize();
	void uninitialize();
	void update();

	////////////////////////////////////////////////
	//	infomation
	////////////////////////////////////////////////

	void outputContext(ostream& printStream, char * indentString);
};

#endif
