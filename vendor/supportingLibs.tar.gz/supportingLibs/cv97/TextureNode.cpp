/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	TextureNode.cpp
*
******************************************************************/
#ifdef SUPPORT_OPENGL
#ifdef WIN32
#include <windows.h>
#endif
#include <GL/gl.h>
#endif

#include "SceneGraph.h"
#include "TextureNode.h"

////////////////////////////////////////////////
//	GetTextureSize
////////////////////////////////////////////////

////////////////////////////////////////////////
//	TextureNode::TextureNode
////////////////////////////////////////////////

TextureNode::TextureNode() 
{
#ifdef SUPPORT_OPENGL
	///////////////////////////
	// Private Field 
	///////////////////////////

	// texture name field
	SFInt32 *texName = new SFInt32(0);
	texName->setName(textureNamePrivateFieldString);
	addPrivateField(texName);

	// texture name field
	SFBool *hasTransColor = new SFBool(false);
	hasTransColor->setName(hasTransparencyColorPrivateFieldString);
	addPrivateField(hasTransColor);

#endif
}

////////////////////////////////////////////////
//	TextureNode::~TextureNode
////////////////////////////////////////////////

TextureNode::~TextureNode() 
{
}

////////////////////////////////////////////////
//	TextureNode::getTextureSize
////////////////////////////////////////////////

#ifdef SUPPORT_OPENGL
int GetOpenGLTextureSize(int size) 
{
	int n = 1;
	while ((1 << n) <= size)
		n++;

	return (1 << (n-1));
}
#endif
