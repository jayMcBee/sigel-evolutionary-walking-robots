/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	FogNode.cpp
*
******************************************************************/

#include "FogNode.h"

FogNode::FogNode() 
{
	setHeaderFlag(false);
	setType(fogNodeString);

	///////////////////////////
	// Exposed Field 
	///////////////////////////
		
	// color exposed field
	SFColor *color = new SFColor(1.0f, 1.0f, 1.0f);
	addExposedField(colorFieldString, color);

	// fogType exposed field
	SFString *fogType = new SFString("LINEAR");
	addExposedField(fogTypeFieldString, fogType);

	// visibilityRange exposed field
	SFFloat *visibilityRange = new SFFloat(0.0f);
	addExposedField(visibilityRangeFieldString, visibilityRange);
}

FogNode::~FogNode() 
{
}

////////////////////////////////////////////////
//	Color
////////////////////////////////////////////////

void FogNode::setColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(colorFieldString);
	color->setValue(value);
}

void FogNode::setColor(float r, float g, float b) 
{
	SFColor *color = (SFColor *)getExposedField(colorFieldString);
	color->setValue(r, g, b);
}

void FogNode::getColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(colorFieldString);
	color->getValue(value);
}

////////////////////////////////////////////////
//	FogType
////////////////////////////////////////////////

void FogNode::setFogType(String value) 
{
	SFString *fogType = (SFString *)getExposedField(fogTypeFieldString);
	fogType->setValue(value);
}

String FogNode::getFogType() 
{
	SFString *fogType = (SFString *)getExposedField(fogTypeFieldString);
	return fogType->getValue();
}

////////////////////////////////////////////////
//	VisibilityRange
////////////////////////////////////////////////

void FogNode::setVisibilityRange(float value) 
{
	SFFloat *visibilityRange = (SFFloat *)getExposedField(visibilityRangeFieldString);
	visibilityRange->setValue(value);
}

float FogNode::getVisibilityRange() 
{
	SFFloat *visibilityRange = (SFFloat *)getExposedField(visibilityRangeFieldString);
	return visibilityRange->getValue();
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

FogNode *FogNode::next() 
{
	return (FogNode *)Node::next(getType());
}

FogNode *FogNode::nextTraversal() 
{
	return (FogNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool FogNode::isChildNodeType(Node *node)
{
	return false;
}

void FogNode::initialize() 
{
}

void FogNode::uninitialize() 
{
}

void FogNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void FogNode::outputContext(ostream &printStream, String indentString) 
{
	SFColor *color = (SFColor *)getExposedField(colorFieldString);
	SFString *fogType = (SFString *)getExposedField(fogTypeFieldString);

	printStream << indentString << "\t" << "color " << color << endl;
	printStream << indentString << "\t" << "fogType " << fogType << endl;
	printStream << indentString << "\t" << "visibilityRange " << getVisibilityRange() << endl;
}
