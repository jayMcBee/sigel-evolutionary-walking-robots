/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	NodeList.h
*
******************************************************************/

#ifndef _NODELIST_H_
#define _NODELIST_H_

#include "CLinkedList.h"
#include "RootNode.h"

class NodeList : public CLinkedList<Node> {

public:

	NodeList();
	~NodeList();
};

#endif
