/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	CylinderSensorNode.cpp
*
******************************************************************/

#include "vrmlfields.h"
#include "CylinderSensorNode.h"

CylinderSensorNode::CylinderSensorNode() 
{
	setHeaderFlag(false);
	setType(cylinderSensorNodeString);

	// enabled exposed field
	SFBool *enabled = new SFBool(true);
	addExposedField(enabledFieldString, enabled);

	// autoOffset exposed field
	SFBool *autoOffset = new SFBool(true);
	addExposedField(autoOffsetFieldString, autoOffset);

	// diskAngle exposed field
	SFFloat *diskAngle = new SFFloat(0.262f);
	addExposedField(diskAngleFieldString, diskAngle);

	// minAngle exposed field
	SFFloat *minAngle = new SFFloat(0.0f);
	addExposedField(minAngleFieldString, minAngle);

	// maxAngle exposed field
	SFFloat *maxAngle = new SFFloat(-1.0f);
	addExposedField(maxAngleFieldString, maxAngle);

	// offset exposed field
	SFFloat *offset = new SFFloat(0.0f);
	addExposedField(offsetFieldString, offset);

	
	// isActive eventOut field
	SFBool *isActive = new SFBool(false);
	addEventOut(isActiveFieldString, isActive);

	// rotation eventOut field
	SFRotation *rotation = new SFRotation(0.0f, 0.0f, 1.0f, 0.0f);
	addEventOut(rotationFieldString, rotation);

	// trackPoint eventOut field
	SFVec3f *trackPoint = new SFVec3f(0.0f, 0.0f, 0.0f);
	addEventOut(trackPointFieldString, trackPoint);
}


CylinderSensorNode::~CylinderSensorNode() 
{
}

////////////////////////////////////////////////
//	Enabled
////////////////////////////////////////////////
	
void CylinderSensorNode::setEnabled(bool  value) 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	bEnabled->setValue(value);
}

void CylinderSensorNode::setEnabled(int value) 
{
	setEnabled(value ? true : false);
}

bool  CylinderSensorNode::getEnabled() 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	return bEnabled->getValue();
}

bool  CylinderSensorNode::isEnabled() 
{
	return getEnabled();
}

////////////////////////////////////////////////
//	AutoOffset
////////////////////////////////////////////////
	
void CylinderSensorNode::setAutoOffset(bool  value) 
{
	SFBool *sfbool = (SFBool *)getExposedField(autoOffsetFieldString);
	sfbool->setValue(value);
}

void CylinderSensorNode::setAutoOffset(int value) 
{
	setAutoOffset(value ? true : false);
}

bool  CylinderSensorNode::getAutoOffset()
{
	SFBool *sfbool = (SFBool *)getExposedField(autoOffsetFieldString);
	return sfbool->getValue();
}

bool  CylinderSensorNode::isAutoOffset() 
{
	return getAutoOffset();
}

////////////////////////////////////////////////
//	DiskAngle
////////////////////////////////////////////////
	
void CylinderSensorNode::setDiskAngle(float value)
{
	SFFloat *sffloat = (SFFloat *)getExposedField(diskAngleFieldString);
	sffloat->setValue(value);
}

float CylinderSensorNode::getDiskAngle() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(diskAngleFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	MinAngle
////////////////////////////////////////////////
	
void CylinderSensorNode::setMinAngle(float value) 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(minAngleFieldString);
	sffloat->setValue(value);
}

float CylinderSensorNode::getMinAngle() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(minAngleFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	MaxAngle
////////////////////////////////////////////////
	
void CylinderSensorNode::setMaxAngle(float value) 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(maxAngleFieldString);
	sffloat->setValue(value);
}

float CylinderSensorNode::getMaxAngle() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(maxAngleFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	Offset
////////////////////////////////////////////////
	
void CylinderSensorNode::setOffset(float value) 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(offsetFieldString);
	sffloat->setValue(value);
}

float CylinderSensorNode::getOffset() 
{
	SFFloat *sffloat = (SFFloat *)getExposedField(offsetFieldString);
	return sffloat->getValue();
}

////////////////////////////////////////////////
//	isActive
////////////////////////////////////////////////
	
void CylinderSensorNode::setIsActive(bool  value) 
{
	SFBool *sfbool = (SFBool *)getEventOut(isActiveFieldString);
	sfbool->setValue(value);
}

void CylinderSensorNode::setIsActive(int value) 
{
	setIsActive(value ? true : false);
}

bool  CylinderSensorNode::getIsActive() 
{
	SFBool *sfbool = (SFBool *)getEventOut(isActiveFieldString);
	return sfbool->getValue();
}

bool CylinderSensorNode::isActive() 
{
	return getIsActive();
}

////////////////////////////////////////////////
//	Rotation
////////////////////////////////////////////////
	
void CylinderSensorNode::setRotationChanged(float value[]) 
{
	SFRotation *time = (SFRotation *)getEventOut(rotationFieldString);
	time->setValue(value);
}

void CylinderSensorNode::setRotationChanged(float x, float y, float z, float rot) 
{
	SFRotation *time = (SFRotation *)getEventOut(rotationFieldString);
	time->setValue(x, y, z, rot);
}

void CylinderSensorNode::getRotationChanged(float value[]) 
{
	SFRotation *time = (SFRotation *)getEventOut(rotationFieldString);
	time->getValue(value);
}

////////////////////////////////////////////////
//	TrackPoint
////////////////////////////////////////////////
	
void CylinderSensorNode::setTrackPointChanged(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getEventOut(trackPointFieldString);
	sfvec3f->setValue(value);
}

void CylinderSensorNode::setTrackPointChanged(float x, float y, float z) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getEventOut(trackPointFieldString);
	sfvec3f->setValue(x, y, z);
}

void CylinderSensorNode::getTrackPointChanged(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getEventOut(trackPointFieldString);
	sfvec3f->getValue(value);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

CylinderSensorNode *CylinderSensorNode::next() 
{
	return (CylinderSensorNode *)Node::next(getType());
}

CylinderSensorNode *CylinderSensorNode::nextTraversal() 
{
	return (CylinderSensorNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool CylinderSensorNode::isChildNodeType(Node *node)
{
	return false;
}

void CylinderSensorNode::initialize() 
{
	setIsActive(false);
}

void CylinderSensorNode::uninitialize()
{
}

void CylinderSensorNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void CylinderSensorNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *autoOffset = (SFBool *)getExposedField(autoOffsetFieldString);
	SFBool *enabled = (SFBool *)getExposedField(enabledFieldString);

	printStream << indentString << "\t" << "autoOffset " << autoOffset << endl;
	printStream << indentString << "\t" << "diskAngle " << getDiskAngle() << endl;
	printStream << indentString << "\t" << "enabled " << enabled << endl;
	printStream << indentString << "\t" << "maxAngle " << getMaxAngle() << endl;
	printStream << indentString << "\t" << "minAngle " << getMinAngle() << endl;
	printStream << indentString << "\t" << "offset " << getOffset() << endl;
}
