/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	SphereSensorNode.cpp
*
******************************************************************/

#include "SphereSensorNode.h"

SphereSensorNode::SphereSensorNode() 
{
	setHeaderFlag(false);
	setType(sphereSensorNodeString);

	// enabled exposed field
	SFBool *enabled = new SFBool(true);
	addExposedField(enabledFieldString, enabled);

	// autoOffset exposed field
	SFBool *autoOffset = new SFBool(true);
	addExposedField(autoOffsetFieldString, autoOffset);

	// offset exposed field
	SFRotation *offset = new SFRotation(0.0f, 0.0f, 1.0f, 0.0f);
	addExposedField(offsetFieldString, offset);


	// isActive eventOut field
	SFBool *isActive = new SFBool(false);
	addEventOut(isActiveFieldString, isActive);

	// rotation eventOut field
	SFRotation *rotation = new SFRotation(0.0f, 0.0f, 1.0f, 0.0f);
	addEventOut(rotationFieldString, rotation);

	// trackPoint eventOut field
	SFVec3f *trackPoint = new SFVec3f(0.0f, 0.0f, 0.0f);
	addEventOut(trackPointFieldString, trackPoint);
}

SphereSensorNode::~SphereSensorNode() 
{
}

////////////////////////////////////////////////
//	Enabled
////////////////////////////////////////////////
	
void SphereSensorNode::setEnabled(bool value) 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	bEnabled->setValue(value);
}

void SphereSensorNode::setEnabled(int value) 
{
	setEnabled(value ? true : false);
}

bool SphereSensorNode::getEnabled() 
{
	SFBool *bEnabled = (SFBool *)getExposedField(enabledFieldString);
	return bEnabled->getValue();
}

bool SphereSensorNode::isEnabled() 
{
	return getEnabled();
}

////////////////////////////////////////////////
//	AutoOffset
////////////////////////////////////////////////
	
void SphereSensorNode::setAutoOffset(bool value) 
{
	SFBool *sfbool = (SFBool *)getExposedField(autoOffsetFieldString);
	sfbool->setValue(value);
}

void SphereSensorNode::setAutoOffset(int value) 
{
	setAutoOffset(value ? true : false);
}

bool SphereSensorNode::getAutoOffset() 
{
	SFBool *sfbool = (SFBool *)getExposedField(autoOffsetFieldString);
	return sfbool->getValue();
}

bool  SphereSensorNode::isAutoOffset() 
{
	return getAutoOffset();
}

////////////////////////////////////////////////
//	Offset
////////////////////////////////////////////////
	
void SphereSensorNode::setOffset(float value[]) 
{
	SFRotation *sfrotation = (SFRotation *)getExposedField(offsetFieldString);
	sfrotation->setValue(value);
}

void SphereSensorNode::getOffset(float value[]) 
{
	SFRotation *sfrotation = (SFRotation *)getExposedField(offsetFieldString);
	sfrotation->getValue(value);
}

////////////////////////////////////////////////
//	isActive
////////////////////////////////////////////////
	
void SphereSensorNode::setIsActive(bool  value) 
{
	SFBool *sfbool = (SFBool *)getExposedField(isActiveFieldString);
	sfbool->setValue(value);
}

void SphereSensorNode::setIsActive(int value) 
{
	setIsActive(value ? true : false);
}

bool SphereSensorNode::getIsActive() 
{
	SFBool *sfbool = (SFBool *)getExposedField(isActiveFieldString);
	return sfbool->getValue();
}

bool SphereSensorNode::isActive() 
{
	return getAutoOffset();
}

////////////////////////////////////////////////
//	Rotation
////////////////////////////////////////////////
	
void SphereSensorNode::setRotationChanged(float value[]) 
{
	SFRotation *time = (SFRotation *)getEventOut(rotationFieldString);
	time->setValue(value);
}

void SphereSensorNode::setRotationChanged(float x, float y, float z, float rot) 
{
	SFRotation *time = (SFRotation *)getEventOut(rotationFieldString);
	time->setValue(x, y, z, rot);
}

void SphereSensorNode::getRotationChanged(float value[]) 
{
	SFRotation *time = (SFRotation *)getEventOut(rotationFieldString);
	time->getValue(value);
}

////////////////////////////////////////////////
//	TrackPoint
////////////////////////////////////////////////
	
void SphereSensorNode::setTrackPointChanged(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getEventOut(trackPointFieldString);
	sfvec3f->setValue(value);
}

void SphereSensorNode::setTrackPointChanged(float x, float y, float z) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getEventOut(trackPointFieldString);
	sfvec3f->setValue(x, y, z);
}

void SphereSensorNode::getTrackPointChanged(float value[]) 
{
	SFVec3f *sfvec3f = (SFVec3f *)getEventOut(trackPointFieldString);
	sfvec3f->getValue(value);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

SphereSensorNode *SphereSensorNode::next() 
{
	return (SphereSensorNode *)Node::next(getType());
}

SphereSensorNode *SphereSensorNode::nextTraversal() 
{
	return (SphereSensorNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool SphereSensorNode::isChildNodeType(Node *node)
{
	return false;
}

void SphereSensorNode::initialize() 
{
	setIsActive(false);
}

void SphereSensorNode::uninitialize() 
{
}

void SphereSensorNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void SphereSensorNode::outputContext(ostream &printStream, String indentString) 
{
	SFBool *autoOffset = (SFBool *)getExposedField(autoOffsetFieldString);
	SFBool *enabled = (SFBool *)getExposedField(enabledFieldString);
	SFRotation *offset = (SFRotation *)getExposedField(offsetFieldString);

	printStream << indentString << "\t" << "autoOffset " << autoOffset << endl;
	printStream << indentString << "\t" << "enabled " << enabled << endl;
	printStream << indentString << "\t" << "offset " << offset << endl;
}
