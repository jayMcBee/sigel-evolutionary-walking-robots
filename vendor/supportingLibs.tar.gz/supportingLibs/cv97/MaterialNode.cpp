/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	MaterialNode.h
*
******************************************************************/

#include "MaterialNode.h"

MaterialNode::MaterialNode() 
{
	setHeaderFlag(false);
	setType(materialNodeString);

	// tranparency exposed field
	SFFloat *transparency = new SFFloat(0.0f);
	transparency->setName(transparencyFieldString);
	addExposedField(transparency);

	// ambientIntesity exposed field
	SFFloat *ambientIntensity = new SFFloat(0.2f);
	ambientIntensity->setName(ambientIntensityFieldString);
	addExposedField(ambientIntensity);

	// shininess exposed field
	SFFloat *shininess = new SFFloat(0.2f);
	shininess->setName(shininessFieldString);
	addExposedField(shininess);

	// diffuseColor exposed field
	SFColor *diffuseColor = new SFColor(0.8f, 0.8f, 0.8f);
	diffuseColor->setName(diffuseColorFieldString);
	addExposedField(diffuseColor);

	// specularColor exposed field
	SFColor *specularColor = new SFColor(0.0f, 0.0f, 0.0f);
	specularColor->setName(specularColorFieldString);
	addExposedField(specularColor);

	// emissiveColor exposed field
	SFColor *emissiveColor = new SFColor(0.0f, 0.0f, 0.0f);
	emissiveColor->setName(emissiveColorFieldString);
	addExposedField(emissiveColor);
}

MaterialNode::~MaterialNode() 
{
}

////////////////////////////////////////////////
//	Transparency
////////////////////////////////////////////////
	
void MaterialNode::setTransparency(float value) 
{
	SFFloat *transparency = (SFFloat *)getExposedField(transparencyFieldString);
	transparency->setValue(value);
}

float MaterialNode::getTransparency() 
{
	SFFloat *transparency = (SFFloat *)getExposedField(transparencyFieldString);
	return transparency->getValue();
}

////////////////////////////////////////////////
//	AmbientIntensity
////////////////////////////////////////////////
	
void MaterialNode::setAmbientIntensity(float intensity) 
{
	SFFloat *ambientIntensity = (SFFloat *)getExposedField(ambientIntensityFieldString);
	ambientIntensity->setValue(intensity);
}

float MaterialNode::getAmbientIntensity() 
{
	SFFloat *ambientIntensity = (SFFloat *)getExposedField(ambientIntensityFieldString);
	return ambientIntensity->getValue();
}

////////////////////////////////////////////////
//	Shininess
////////////////////////////////////////////////
	
void MaterialNode::setShininess(float value) 
{
	SFFloat *shininess = (SFFloat *)getExposedField(shininessFieldString);
	shininess->setValue(value);
}

float MaterialNode::getShininess() 
{
	SFFloat *shininess = (SFFloat *)getExposedField(shininessFieldString);
	return shininess->getValue();
}

////////////////////////////////////////////////
//	DiffuseColor
////////////////////////////////////////////////

void MaterialNode::setDiffuseColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(diffuseColorFieldString);
	color->setValue(value);
}

void MaterialNode::setDiffuseColor(float r, float g, float b) 
{
	SFColor *color = (SFColor *)getExposedField(diffuseColorFieldString);
	color->setValue(r, g, b);
}

void MaterialNode::getDiffuseColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(diffuseColorFieldString);
	color->getValue(value);
}

////////////////////////////////////////////////
//	SpecularColor
////////////////////////////////////////////////

void MaterialNode::setSpecularColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(specularColorFieldString);
	color->setValue(value);
}

void MaterialNode::setSpecularColor(float r, float g, float b) 
{
	SFColor *color = (SFColor *)getExposedField(specularColorFieldString);
	color->setValue(r, g, b);
}

void MaterialNode::getSpecularColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(specularColorFieldString);
	color->getValue(value);
}

////////////////////////////////////////////////
//	EmissiveColor
////////////////////////////////////////////////

void MaterialNode::setEmissiveColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(emissiveColorFieldString);
	color->setValue(value);
}

void MaterialNode::setEmissiveColor(float r, float g, float b) 
{
	SFColor *color = (SFColor *)getExposedField(emissiveColorFieldString);
	color->setValue(r, g, b);
}

void MaterialNode::getEmissiveColor(float value[]) 
{
	SFColor *color = (SFColor *)getExposedField(emissiveColorFieldString);
	color->getValue(value);
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

MaterialNode *MaterialNode::next() 
{
	return (MaterialNode *)Node::next(getType());
}

MaterialNode *MaterialNode::nextTraversal() 
{
	return (MaterialNode *)Node::nextTraversalByType(getType());
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool MaterialNode::isChildNodeType(Node *node)
{
	return false;
}

void MaterialNode::initialize() 
{
}

void MaterialNode::uninitialize() 
{
}

void MaterialNode::update() 
{
}

////////////////////////////////////////////////
//	Infomation
////////////////////////////////////////////////

void MaterialNode::outputContext(ostream &printStream, String indentString) 
{
	SFColor *dcolor = (SFColor *)getExposedField(diffuseColorFieldString);
	SFColor *scolor = (SFColor *)getExposedField(specularColorFieldString);
	SFColor *ecolor = (SFColor *)getExposedField(emissiveColorFieldString);
	printStream << indentString << "\t" << "diffuseColor " << dcolor << endl;
	printStream << indentString << "\t" << "ambientIntensity " << getAmbientIntensity() << endl;
	printStream << indentString << "\t" << "specularColor " << scolor << endl;
	printStream << indentString << "\t" << "emissiveColor " << ecolor << endl;
	printStream << indentString << "\t" << "shininess " << getShininess() << endl;
	printStream << indentString << "\t" << "transparency " << getTransparency() << endl;
}
