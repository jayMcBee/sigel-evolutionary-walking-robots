/******************************************************************
*
*	VRML library for C++
*
*	Copyright (C) Satoshi Konno 1996-1997
*
*	File:	ColorNode.cpp
*
******************************************************************/

#include "vrmlfields.h"
#include "ColorNode.h"

ColorNode::ColorNode() 
{
	setHeaderFlag(false);
	setType(colorNodeString);

	// color exposed field
	MFColor *mfcolor = new MFColor();
	mfcolor->setName(colorFieldString);
	addExposedField(mfcolor);
}

ColorNode::~ColorNode() 
{
}

////////////////////////////////////////////////
//	color
////////////////////////////////////////////////
	
void ColorNode::addColor(float color[]) 
{
	MFColor *mfcolor = (MFColor *)getExposedField(colorFieldString);
	mfcolor->addValue(color);
}

int ColorNode::getNColors() 
{
	MFColor *mfcolor = (MFColor *)getExposedField(colorFieldString);
	return mfcolor->getSize();
}

void ColorNode::getColor(int index, float color[]) 
{
	MFColor *mfcolor = (MFColor *)getExposedField(colorFieldString);
	mfcolor->get1Value(index, color);
}

////////////////////////////////////////////////
//	functions
////////////////////////////////////////////////
	
bool ColorNode::isChildNodeType(Node *node)
{
	return false;
}

void ColorNode::initialize() 
{
}

void ColorNode::uninitialize() 
{
}

void ColorNode::update() 
{
}

////////////////////////////////////////////////
//	Output
////////////////////////////////////////////////

void ColorNode::outputContext(ostream &printStream, String indentString) 
{
	if (0 < getNColors()) { 
		MFColor *mfcolor = (MFColor *)getExposedField(colorFieldString);
		printStream <<  indentString << "\t" << "color ["  << endl;
		mfcolor->MField::outputContext(printStream, indentString, "\t\t");
		printStream << indentString << "\t" << "]" << endl;
	}
}

////////////////////////////////////////////////
//	List
////////////////////////////////////////////////

ColorNode *ColorNode::next() 
{
	return (ColorNode *)Node::next(getType());
}

ColorNode *ColorNode::nextTraversal() 
{
	return (ColorNode *)Node::nextTraversalByType(getType());
}

